#include "mcp.h"
#include "util.h"
#include "cJSON.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/select.h>
#include <signal.h>
#include <errno.h>
#include <fcntl.h>

#define MCP_PROTOCOL_VERSION "2024-11-05"
#define MCP_READ_TIMEOUT     60  /* seconds */

/* ---------- helpers ---------- */

static char *read_file_contents(const char *path)
{
    FILE *fp = fopen(path, "r");
    if (!fp) return NULL;
    fseek(fp, 0, SEEK_END);
    long sz = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    if (sz <= 0 || sz > 1000000) { fclose(fp); return NULL; }
    char *buf = xmalloc((size_t)sz + 1);
    size_t rd = fread(buf, 1, (size_t)sz, fp);
    buf[rd] = '\0';
    fclose(fp);
    return buf;
}

/* Read one newline-terminated line from fd with timeout.
 * Returns malloc'd string (without newline) or NULL on error/timeout. */
static char *read_line(int fd, int timeout_sec)
{
    StrBuf line;
    strbuf_init(&line);

    fd_set fds;
    struct timeval tv;

    while (1) {
        FD_ZERO(&fds);
        FD_SET(fd, &fds);
        tv.tv_sec = timeout_sec;
        tv.tv_usec = 0;

        int ret = select(fd + 1, &fds, NULL, NULL, &tv);
        if (ret <= 0) {
            strbuf_free(&line);
            return NULL;
        }

        char c;
        ssize_t n = read(fd, &c, 1);
        if (n <= 0) {
            strbuf_free(&line);
            return NULL;
        }

        if (c == '\n') break;
        if (c == '\r') continue;  /* skip CR */
        strbuf_append(&line, &c, 1);

        if (line.len > 1024 * 1024) {
            strbuf_free(&line);
            return NULL;
        }
    }

    return strbuf_detach(&line);
}

/* ---------- config parsing ---------- */

static void free_server_config(McpServer *s)
{
    free(s->command);
    s->command = NULL;
    for (int i = 0; i < s->n_args; i++) free(s->args[i]);
    free(s->args);
    s->args = NULL;
    s->n_args = 0;
    for (int i = 0; i < s->n_env; i++) {
        free(s->env_keys[i]);
        free(s->env_vals[i]);
    }
    free(s->env_keys);
    free(s->env_vals);
    s->env_keys = NULL;
    s->env_vals = NULL;
    s->n_env = 0;
}

static void parse_mcp_config(McpManager *mgr, cJSON *root)
{
    cJSON *servers = cJSON_GetObjectItem(root, "mcpServers");
    if (!servers || !cJSON_IsObject(servers)) return;

    cJSON *srv = NULL;
    cJSON_ArrayForEach(srv, servers) {
        const char *name = srv->string;
        cJSON *cmd = cJSON_GetObjectItem(srv, "command");
        if (!cmd || !cJSON_IsString(cmd)) continue;

        /* check if server already exists (workspace overrides global) */
        int idx = -1;
        for (int i = 0; i < mgr->n_servers; i++) {
            if (strcmp(mgr->servers[i].name, name) == 0) {
                idx = i;
                break;
            }
        }

        McpServer *s;
        if (idx >= 0) {
            s = &mgr->servers[idx];
            free_server_config(s);
        } else {
            mgr->servers = xrealloc(mgr->servers,
                sizeof(McpServer) * (size_t)(mgr->n_servers + 1));
            s = &mgr->servers[mgr->n_servers++];
            memset(s, 0, sizeof(*s));
            s->name = xstrdup(name);
            s->pid = -1;
            s->fd_write = -1;
            s->fd_read = -1;
        }

        s->command = xstrdup(cmd->valuestring);

        /* parse args array */
        cJSON *args_j = cJSON_GetObjectItem(srv, "args");
        if (args_j && cJSON_IsArray(args_j)) {
            s->n_args = cJSON_GetArraySize(args_j);
            s->args = xmalloc(sizeof(char *) * (size_t)s->n_args);
            for (int i = 0; i < s->n_args; i++) {
                cJSON *a = cJSON_GetArrayItem(args_j, i);
                s->args[i] = xstrdup(
                    cJSON_IsString(a) ? a->valuestring : "");
            }
        }

        /* parse env object */
        cJSON *env_j = cJSON_GetObjectItem(srv, "env");
        if (env_j && cJSON_IsObject(env_j)) {
            s->n_env = cJSON_GetArraySize(env_j);
            s->env_keys = xmalloc(sizeof(char *) * (size_t)s->n_env);
            s->env_vals = xmalloc(sizeof(char *) * (size_t)s->n_env);
            int ei = 0;
            cJSON *e = NULL;
            cJSON_ArrayForEach(e, env_j) {
                s->env_keys[ei] = xstrdup(e->string);
                s->env_vals[ei] = xstrdup(
                    cJSON_IsString(e) ? e->valuestring : "");
                ei++;
            }
        }
    }
}

/* ---------- server process management ---------- */

static bool mcp_start_server(McpServer *server)
{
    int pipe_in[2];   /* parent writes → child stdin */
    int pipe_out[2];  /* child stdout → parent reads */

    if (pipe(pipe_in) < 0) return false;
    if (pipe(pipe_out) < 0) {
        close(pipe_in[0]); close(pipe_in[1]);
        return false;
    }

    pid_t pid = fork();
    if (pid < 0) {
        close(pipe_in[0]); close(pipe_in[1]);
        close(pipe_out[0]); close(pipe_out[1]);
        return false;
    }

    if (pid == 0) {
        /* child */
        close(pipe_in[1]);
        close(pipe_out[0]);
        dup2(pipe_in[0], STDIN_FILENO);
        dup2(pipe_out[1], STDOUT_FILENO);
        close(pipe_in[0]);
        close(pipe_out[1]);

        /* redirect stderr to /dev/null */
        int devnull = open("/dev/null", O_WRONLY);
        if (devnull >= 0) {
            dup2(devnull, STDERR_FILENO);
            close(devnull);
        }

        /* set environment variables */
        for (int i = 0; i < server->n_env; i++)
            setenv(server->env_keys[i], server->env_vals[i], 1);

        /* build argv: command + args + NULL */
        int argc = 1 + server->n_args;
        char **argv = malloc(sizeof(char *) * (size_t)(argc + 1));
        if (!argv) _exit(127);
        argv[0] = (char *)server->command;
        for (int i = 0; i < server->n_args; i++)
            argv[i + 1] = server->args[i];
        argv[argc] = NULL;

        execvp(server->command, argv);
        _exit(127);
    }

    /* parent */
    close(pipe_in[0]);
    close(pipe_out[1]);

    server->pid = pid;
    server->fd_write = pipe_in[1];
    server->fd_read = pipe_out[0];
    server->next_id = 1;

    return true;
}

static void mcp_stop_server(McpServer *server)
{
    if (server->pid > 0) {
        kill(server->pid, SIGTERM);
        usleep(200000); /* 200ms grace period */
        int status;
        pid_t w = waitpid(server->pid, &status, WNOHANG);
        if (w == 0) {
            kill(server->pid, SIGKILL);
            waitpid(server->pid, &status, 0);
        }
        server->pid = -1;
    }
    if (server->fd_write >= 0) { close(server->fd_write); server->fd_write = -1; }
    if (server->fd_read >= 0) { close(server->fd_read); server->fd_read = -1; }
    server->initialized = false;
}

/* ---------- JSON-RPC communication ---------- */

/* Send a JSON-RPC request and read the matching response.
 * Returns the full response object (caller must cJSON_Delete). */
static cJSON *mcp_send_request(McpServer *server,
                               const char *method, cJSON *params)
{
    int id = server->next_id++;

    cJSON *req = cJSON_CreateObject();
    cJSON_AddStringToObject(req, "jsonrpc", "2.0");
    cJSON_AddNumberToObject(req, "id", id);
    cJSON_AddStringToObject(req, "method", method);
    if (params)
        cJSON_AddItemToObject(req, "params", cJSON_Duplicate(params, 1));
    else
        cJSON_AddItemToObject(req, "params", cJSON_CreateObject());

    char *json_str = cJSON_PrintUnformatted(req);
    cJSON_Delete(req);

    /* write request + newline */
    size_t len = strlen(json_str);
    ssize_t w1 = write(server->fd_write, json_str, len);
    ssize_t w2 = write(server->fd_write, "\n", 1);
    free(json_str);

    if (w1 < 0 || w2 < 0) return NULL;

    /* read response lines until we find one with matching id */
    for (int attempts = 0; attempts < 200; attempts++) {
        char *line = read_line(server->fd_read, MCP_READ_TIMEOUT);
        if (!line) return NULL;

        if (line[0] == '\0') {
            free(line);
            continue;  /* skip empty lines */
        }

        cJSON *msg = cJSON_Parse(line);
        free(line);

        if (!msg) continue;

        cJSON *msg_id = cJSON_GetObjectItem(msg, "id");
        if (msg_id && cJSON_IsNumber(msg_id) && msg_id->valueint == id) {
            return msg;
        }

        /* not our response (notification or different id), discard */
        cJSON_Delete(msg);
    }

    return NULL;
}

/* Send a JSON-RPC notification (no id, no response expected). */
static bool mcp_send_notification(McpServer *server,
                                  const char *method, cJSON *params)
{
    cJSON *notif = cJSON_CreateObject();
    cJSON_AddStringToObject(notif, "jsonrpc", "2.0");
    cJSON_AddStringToObject(notif, "method", method);
    if (params)
        cJSON_AddItemToObject(notif, "params", cJSON_Duplicate(params, 1));

    char *json_str = cJSON_PrintUnformatted(notif);
    cJSON_Delete(notif);

    size_t len = strlen(json_str);
    ssize_t w1 = write(server->fd_write, json_str, len);
    ssize_t w2 = write(server->fd_write, "\n", 1);
    free(json_str);

    return (w1 >= 0 && w2 >= 0);
}

/* ---------- MCP protocol lifecycle ---------- */

static bool mcp_initialize(McpServer *server)
{
    cJSON *params = cJSON_CreateObject();
    cJSON_AddStringToObject(params, "protocolVersion", MCP_PROTOCOL_VERSION);

    cJSON *caps = cJSON_CreateObject();
    cJSON_AddItemToObject(params, "capabilities", caps);

    cJSON *client_info = cJSON_CreateObject();
    cJSON_AddStringToObject(client_info, "name", "c-agent");
    cJSON_AddStringToObject(client_info, "version", "0.1.0");
    cJSON_AddItemToObject(params, "clientInfo", client_info);

    cJSON *resp = mcp_send_request(server, "initialize", params);
    cJSON_Delete(params);

    if (!resp) {
        LOG_ERROR("MCP server '%s': initialize failed (no response)",
                  server->name);
        return false;
    }

    /* check for error */
    cJSON *err = cJSON_GetObjectItem(resp, "error");
    if (err) {
        cJSON *msg = cJSON_GetObjectItem(err, "message");
        LOG_ERROR("MCP server '%s': initialize error: %s",
                  server->name,
                  (msg && cJSON_IsString(msg)) ? msg->valuestring : "unknown");
        cJSON_Delete(resp);
        return false;
    }

    cJSON_Delete(resp);

    /* send initialized notification */
    mcp_send_notification(server, "notifications/initialized", NULL);

    server->initialized = true;
    return true;
}

static bool mcp_list_tools(McpServer *server)
{
    cJSON *resp = mcp_send_request(server, "tools/list", NULL);
    if (!resp) {
        LOG_ERROR("MCP server '%s': tools/list failed", server->name);
        return false;
    }

    cJSON *err = cJSON_GetObjectItem(resp, "error");
    if (err) {
        cJSON *msg = cJSON_GetObjectItem(err, "message");
        LOG_ERROR("MCP server '%s': tools/list error: %s",
                  server->name,
                  (msg && cJSON_IsString(msg)) ? msg->valuestring : "unknown");
        cJSON_Delete(resp);
        return false;
    }

    cJSON *result = cJSON_GetObjectItem(resp, "result");
    cJSON *tools_arr = result ? cJSON_GetObjectItem(result, "tools") : NULL;

    if (!tools_arr || !cJSON_IsArray(tools_arr)) {
        cJSON_Delete(resp);
        return true;  /* no tools is not an error */
    }

    int n = cJSON_GetArraySize(tools_arr);
    if (n > 0) {
        server->tools = xmalloc(sizeof(McpTool) * (size_t)n);
        server->n_tools = 0;

        for (int i = 0; i < n; i++) {
            cJSON *t = cJSON_GetArrayItem(tools_arr, i);

            cJSON *name_j = cJSON_GetObjectItem(t, "name");
            if (!name_j || !cJSON_IsString(name_j)) continue;

            McpTool *mt = &server->tools[server->n_tools++];
            mt->name = xstrdup(name_j->valuestring);

            cJSON *desc_j = cJSON_GetObjectItem(t, "description");
            mt->description = (desc_j && cJSON_IsString(desc_j))
                ? xstrdup(desc_j->valuestring)
                : xstrdup("");

            cJSON *schema_j = cJSON_GetObjectItem(t, "inputSchema");
            mt->input_schema = schema_j
                ? cJSON_Duplicate(schema_j, 1)
                : NULL;
        }
    }

    cJSON_Delete(resp);
    return true;
}

static char *mcp_call_tool(McpServer *server, const char *tool_name,
                           cJSON *arguments)
{
    cJSON *params = cJSON_CreateObject();
    cJSON_AddStringToObject(params, "name", tool_name);
    cJSON_AddItemToObject(params, "arguments",
                          arguments ? cJSON_Duplicate(arguments, 1)
                                    : cJSON_CreateObject());

    cJSON *resp = mcp_send_request(server, "tools/call", params);
    cJSON_Delete(params);

    if (!resp) return xstrdup("Error: no response from MCP server");

    /* check JSON-RPC level error */
    cJSON *err = cJSON_GetObjectItem(resp, "error");
    if (err) {
        cJSON *msg = cJSON_GetObjectItem(err, "message");
        StrBuf sb;
        strbuf_init(&sb);
        strbuf_appendf(&sb, "Error: %s",
            (msg && cJSON_IsString(msg)) ? msg->valuestring : "unknown error");
        cJSON_Delete(resp);
        return strbuf_detach(&sb);
    }

    /* extract result content */
    cJSON *result = cJSON_GetObjectItem(resp, "result");
    if (!result) {
        cJSON_Delete(resp);
        return xstrdup("Error: empty result from MCP server");
    }

    /* check MCP-level error */
    cJSON *is_error = cJSON_GetObjectItem(result, "isError");
    bool has_error = (is_error && cJSON_IsTrue(is_error));

    /* extract text/image from content array */
    cJSON *content = cJSON_GetObjectItem(result, "content");
    if (content && cJSON_IsArray(content)) {
        StrBuf sb;
        strbuf_init(&sb);
        if (has_error) strbuf_appends(&sb, "Error: ");
        int cn = cJSON_GetArraySize(content);
        for (int i = 0; i < cn; i++) {
            cJSON *item = cJSON_GetArrayItem(content, i);
            cJSON *type_j = cJSON_GetObjectItem(item, "type");
            const char *ctype = (type_j && cJSON_IsString(type_j))
                ? type_j->valuestring : "";

            if (strcmp(ctype, "text") == 0) {
                cJSON *text = cJSON_GetObjectItem(item, "text");
                if (text && cJSON_IsString(text)) {
                    if (sb.len > (has_error ? 7u : 0u))
                        strbuf_appends(&sb, "\n");
                    strbuf_appends(&sb, text->valuestring);
                }
            } else if (strcmp(ctype, "image") == 0) {
                cJSON *data_j = cJSON_GetObjectItem(item, "data");
                cJSON *mime_j = cJSON_GetObjectItem(item, "mimeType");
                size_t data_len = (data_j && cJSON_IsString(data_j))
                    ? strlen(data_j->valuestring) : 0;
                const char *mime = (mime_j && cJSON_IsString(mime_j))
                    ? mime_j->valuestring : "image/png";
                if (sb.len > (has_error ? 7u : 0u))
                    strbuf_appends(&sb, "\n");
                strbuf_appendf(&sb,
                    "[image: %s, %zu bytes base64 data]",
                    mime, data_len);
            } else {
                /* fallback: try "text" field for untyped content */
                cJSON *text = cJSON_GetObjectItem(item, "text");
                if (text && cJSON_IsString(text)) {
                    if (sb.len > (has_error ? 7u : 0u))
                        strbuf_appends(&sb, "\n");
                    strbuf_appends(&sb, text->valuestring);
                }
            }
        }
        cJSON_Delete(resp);
        if (sb.len == 0) {
            strbuf_free(&sb);
            return xstrdup("(empty result)");
        }
        return strbuf_detach(&sb);
    }

    /* fallback: return raw result JSON */
    char *str = cJSON_PrintUnformatted(result);
    cJSON_Delete(resp);
    return str;
}

/* ---------- free helpers ---------- */

static void free_mcp_tools(McpServer *server)
{
    for (int i = 0; i < server->n_tools; i++) {
        free(server->tools[i].name);
        free(server->tools[i].description);
        cJSON_Delete(server->tools[i].input_schema);
    }
    free(server->tools);
    server->tools = NULL;
    server->n_tools = 0;
}

/* ---------- public API ---------- */

void mcp_init(McpManager *mgr)
{
    memset(mgr, 0, sizeof(*mgr));
}

void mcp_load_config(McpManager *mgr, const char *workspace)
{
    /* 1. Global config: ~/.c-agent/mcp.json */
    const char *home = getenv("HOME");
    if (home) {
        char path[512];
        snprintf(path, sizeof(path), "%s/.c-agent/mcp.json", home);
        char *data = read_file_contents(path);
        if (data) {
            cJSON *root = cJSON_Parse(data);
            if (root) {
                parse_mcp_config(mgr, root);
                cJSON_Delete(root);
            }
            free(data);
        }
    }

    /* 2. Workspace config: {workspace}/.c-agent/mcp.json */
    if (workspace) {
        char path[512];
        snprintf(path, sizeof(path), "%s/.c-agent/mcp.json", workspace);
        char *data = read_file_contents(path);
        if (data) {
            cJSON *root = cJSON_Parse(data);
            if (root) {
                parse_mcp_config(mgr, root);
                cJSON_Delete(root);
            }
            free(data);
        }
    }
}

bool mcp_start_all(McpManager *mgr)
{
    bool any_ok = false;
    for (int i = 0; i < mgr->n_servers; i++) {
        McpServer *s = &mgr->servers[i];
        LOG_INFO("MCP: starting server '%s' (%s)...", s->name, s->command);

        if (!mcp_start_server(s)) {
            LOG_ERROR("MCP: failed to start server '%s'", s->name);
            continue;
        }

        if (!mcp_initialize(s)) {
            LOG_ERROR("MCP: failed to initialize server '%s'", s->name);
            mcp_stop_server(s);
            continue;
        }

        if (!mcp_list_tools(s)) {
            LOG_ERROR("MCP: failed to list tools for server '%s'", s->name);
            mcp_stop_server(s);
            continue;
        }

        LOG_INFO("MCP: server '%s' ready (%d tools)", s->name, s->n_tools);
        any_ok = true;
    }
    return any_ok;
}

void mcp_stop_all(McpManager *mgr)
{
    for (int i = 0; i < mgr->n_servers; i++)
        mcp_stop_server(&mgr->servers[i]);
}

void mcp_register_tools(McpManager *mgr, ToolRegistry *reg)
{
    /* count total tools across all servers */
    int total = 0;
    for (int i = 0; i < mgr->n_servers; i++) {
        if (mgr->servers[i].initialized)
            total += mgr->servers[i].n_tools;
    }
    if (total == 0) return;

    mgr->tool_contexts = xmalloc(sizeof(McpToolContext) * (size_t)total);
    mgr->n_tool_contexts = 0;

    for (int si = 0; si < mgr->n_servers; si++) {
        McpServer *srv = &mgr->servers[si];
        if (!srv->initialized) continue;

        for (int ti = 0; ti < srv->n_tools; ti++) {
            McpTool *tool = &srv->tools[ti];

            McpToolContext *ctx =
                &mgr->tool_contexts[mgr->n_tool_contexts++];
            ctx->mgr = mgr;
            ctx->server_idx = si;
            ctx->tool_idx = ti;

            /* build tool name: mcp__{server}__{tool} */
            StrBuf name;
            strbuf_init(&name);
            strbuf_appendf(&name, "mcp__%s__%s", srv->name, tool->name);

            /* build description with source tag */
            StrBuf desc;
            strbuf_init(&desc);
            strbuf_appendf(&desc, "[MCP: %s] %s",
                           srv->name, tool->description);

            /* serialize input schema */
            char *schema_str;
            if (tool->input_schema) {
                schema_str = cJSON_PrintUnformatted(tool->input_schema);
            } else {
                schema_str = xstrdup(
                    "{\"type\":\"object\",\"properties\":{}}");
            }

            tools_register(reg, name.data, desc.data, schema_str,
                           mcp_tool_exec, ctx);

            strbuf_free(&name);
            strbuf_free(&desc);
            free(schema_str);
        }
    }
}

char *mcp_tool_exec(const char *args_json, void *userdata)
{
    McpToolContext *ctx = (McpToolContext *)userdata;
    McpServer *server = &ctx->mgr->servers[ctx->server_idx];
    McpTool *tool = &server->tools[ctx->tool_idx];

    if (!server->initialized || server->pid <= 0) {
        StrBuf sb;
        strbuf_init(&sb);
        strbuf_appendf(&sb, "Error: MCP server '%s' is not connected",
                        server->name);
        return strbuf_detach(&sb);
    }

    cJSON *args = cJSON_Parse(args_json);
    if (!args) args = cJSON_CreateObject();

    char *result = mcp_call_tool(server, tool->name, args);
    cJSON_Delete(args);

    return result;
}

void mcp_free(McpManager *mgr)
{
    mcp_stop_all(mgr);

    for (int i = 0; i < mgr->n_servers; i++) {
        McpServer *s = &mgr->servers[i];
        free(s->name);
        free_server_config(s);
        free_mcp_tools(s);
    }
    free(mgr->servers);
    free(mgr->tool_contexts);

    memset(mgr, 0, sizeof(*mgr));
}

void mcp_print_status(const McpManager *mgr)
{
    if (mgr->n_servers == 0) {
        fprintf(stdout, "\n  (no MCP servers configured)\n\n");
        return;
    }

    fprintf(stdout, "\n");
    for (int i = 0; i < mgr->n_servers; i++) {
        const McpServer *s = &mgr->servers[i];
        const char *status = s->initialized ? "running" : "stopped";
        const char *color = s->initialized ? "\033[32m" : "\033[31m";

        fprintf(stdout, "  %s%-12s%s  %s%s%s  %d tools\n",
                "\033[1m", s->name, "\033[0m",
                color, status, "\033[0m",
                s->n_tools);

        if (s->n_tools > 0) {
            fprintf(stdout, "    ");
            for (int j = 0; j < s->n_tools; j++) {
                if (j > 0) fprintf(stdout, ", ");
                fprintf(stdout, "%s", s->tools[j].name);
            }
            fprintf(stdout, "\n");
        }
    }
    fprintf(stdout, "\n");
}
