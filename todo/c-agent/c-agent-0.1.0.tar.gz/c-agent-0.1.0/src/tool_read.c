#include "tools.h"
#include "util.h"
#include "cJSON.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

char *tool_read_exec(const char *args_json, void *userdata)
{
    (void)userdata;
    cJSON *args = cJSON_Parse(args_json);
    if (!args) return xstrdup("Error: invalid JSON arguments");

    cJSON *path_j = cJSON_GetObjectItem(args, "file_path");
    if (!path_j || !cJSON_IsString(path_j)) {
        cJSON_Delete(args);
        return xstrdup("Error: missing 'file_path' parameter");
    }

    int offset = 1;
    cJSON *off_j = cJSON_GetObjectItem(args, "offset");
    if (off_j && cJSON_IsNumber(off_j))
        offset = off_j->valueint;
    if (offset < 1) offset = 1;

    int limit = 2000;
    cJSON *lim_j = cJSON_GetObjectItem(args, "limit");
    if (lim_j && cJSON_IsNumber(lim_j))
        limit = lim_j->valueint;
    if (limit < 1) limit = 1;
    if (limit > 10000) limit = 10000;

    FILE *fp = fopen(path_j->valuestring, "r");
    if (!fp) {
        StrBuf sb;
        strbuf_init(&sb);
        strbuf_appendf(&sb, "Error: cannot open '%s': %s",
                        path_j->valuestring, strerror(errno));
        cJSON_Delete(args);
        return strbuf_detach(&sb);
    }

    StrBuf result;
    strbuf_init(&result);

    char line[4096];
    int lineno = 0;
    int lines_read = 0;

    while (fgets(line, sizeof(line), fp)) {
        lineno++;
        if (lineno < offset) continue;
        if (lines_read >= limit) break;

        /* truncate long lines */
        size_t len = strlen(line);
        if (len > 2000) {
            line[2000] = '\0';
            strbuf_appendf(&result, "%6d\t%s...\n", lineno, line);
        } else {
            /* remove trailing newline for consistent formatting */
            if (len > 0 && line[len - 1] == '\n')
                line[--len] = '\0';
            strbuf_appendf(&result, "%6d\t%s\n", lineno, line);
        }
        lines_read++;
    }

    fclose(fp);

    if (lines_read == 0)
        strbuf_appends(&result, "(empty file or offset beyond end)");

    cJSON_Delete(args);
    return strbuf_detach(&result);
}
