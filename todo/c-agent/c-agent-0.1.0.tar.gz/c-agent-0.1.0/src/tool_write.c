#include "tools.h"
#include "util.h"
#include "cJSON.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <libgen.h>

/* recursively create directories */
static int mkdirp(const char *path)
{
    char *tmp = xstrdup(path);
    size_t len = strlen(tmp);
    if (len == 0) { free(tmp); return 0; }

    /* remove trailing slash */
    if (tmp[len - 1] == '/') tmp[len - 1] = '\0';

    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = '\0';
            mkdir(tmp, 0755);
            *p = '/';
        }
    }
    int rc = mkdir(tmp, 0755);
    free(tmp);
    return (rc == 0 || errno == EEXIST) ? 0 : -1;
}

char *tool_write_exec(const char *args_json, void *userdata)
{
    (void)userdata;
    cJSON *args = cJSON_Parse(args_json);
    if (!args) return xstrdup("Error: invalid JSON arguments");

    cJSON *path_j = cJSON_GetObjectItem(args, "file_path");
    cJSON *cont_j = cJSON_GetObjectItem(args, "content");

    if (!path_j || !cJSON_IsString(path_j)) {
        cJSON_Delete(args);
        return xstrdup("Error: missing 'file_path' parameter");
    }
    if (!cont_j || !cJSON_IsString(cont_j)) {
        cJSON_Delete(args);
        return xstrdup("Error: missing 'content' parameter");
    }

    /* ensure parent directory exists */
    char *pathcopy = xstrdup(path_j->valuestring);
    char *dir = dirname(pathcopy);
    if (dir && strcmp(dir, ".") != 0 && strcmp(dir, "/") != 0) {
        mkdirp(dir);
    }
    free(pathcopy);

    FILE *fp = fopen(path_j->valuestring, "w");
    if (!fp) {
        StrBuf sb;
        strbuf_init(&sb);
        strbuf_appendf(&sb, "Error: cannot open '%s' for writing: %s",
                        path_j->valuestring, strerror(errno));
        cJSON_Delete(args);
        return strbuf_detach(&sb);
    }

    fputs(cont_j->valuestring, fp);
    fclose(fp);

    StrBuf result;
    strbuf_init(&result);
    strbuf_appendf(&result, "Successfully wrote %zu bytes to '%s'",
                    strlen(cont_j->valuestring), path_j->valuestring);

    cJSON_Delete(args);
    return strbuf_detach(&result);
}
