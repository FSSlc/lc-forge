#include "context.h"
#include "util.h"
#include <stdlib.h>
#include <string.h>

/* forward declarations for token estimation */
static int estimate_str_tokens(const char *s);
static int msg_estimate_tokens(const Message *m);

/* ---------- ToolCall helpers ---------- */
ToolCall toolcall_dup(const ToolCall *tc)
{
    ToolCall out;
    out.id        = xstrdup(tc->id);
    out.name      = xstrdup(tc->name);
    out.arguments = xstrdup(tc->arguments);
    return out;
}

void toolcall_free(ToolCall *tc)
{
    free(tc->id);
    free(tc->name);
    free(tc->arguments);
}

/* ---------- Message helpers ---------- */
static void msg_free(Message *m)
{
    free(m->content);
    free(m->reasoning_content);
    for (int i = 0; i < m->n_tool_calls; i++)
        toolcall_free(&m->tool_calls[i]);
    free(m->tool_calls);
    free(m->tool_call_id);
    memset(m, 0, sizeof(*m));
}

/* ---------- Context ---------- */
void ctx_init(Context *ctx, int max_tokens)
{
    ctx->msgs          = NULL;
    ctx->n_msgs        = 0;
    ctx->cap_msgs      = 0;
    ctx->max_tokens    = max_tokens;
    ctx->cached_tokens = 0;
}

void ctx_free(Context *ctx)
{
    for (int i = 0; i < ctx->n_msgs; i++)
        msg_free(&ctx->msgs[i]);
    free(ctx->msgs);
    ctx->msgs = NULL;
    ctx->n_msgs = ctx->cap_msgs = 0;
}

static Message *ctx_alloc_msg(Context *ctx)
{
    if (ctx->n_msgs >= ctx->cap_msgs) {
        ctx->cap_msgs = ctx->cap_msgs ? ctx->cap_msgs * 2 : 16;
        ctx->msgs = xrealloc(ctx->msgs,
                             (size_t)ctx->cap_msgs * sizeof(Message));
    }
    Message *m = &ctx->msgs[ctx->n_msgs++];
    memset(m, 0, sizeof(*m));
    return m;
}

void ctx_add_system(Context *ctx, const char *content)
{
    Message *m = ctx_alloc_msg(ctx);
    m->role    = ROLE_SYSTEM;
    m->content = xstrdup(content);
    ctx->cached_tokens += msg_estimate_tokens(m);
}

void ctx_add_user(Context *ctx, const char *content)
{
    Message *m = ctx_alloc_msg(ctx);
    m->role    = ROLE_USER;
    m->content = xstrdup(content);
    ctx->cached_tokens += msg_estimate_tokens(m);
}

void ctx_add_assistant(Context *ctx, const char *content,
                       const char *reasoning_content,
                       ToolCall *tcs, int n_tcs)
{
    Message *m = ctx_alloc_msg(ctx);
    m->role    = ROLE_ASSISTANT;
    m->content = content ? xstrdup(content) : NULL;
    m->reasoning_content = reasoning_content ? xstrdup(reasoning_content) : NULL;
    if (n_tcs > 0) {
        m->tool_calls   = xmalloc((size_t)n_tcs * sizeof(ToolCall));
        m->n_tool_calls = n_tcs;
        for (int i = 0; i < n_tcs; i++)
            m->tool_calls[i] = toolcall_dup(&tcs[i]);
    }
    ctx->cached_tokens += msg_estimate_tokens(m);
}

void ctx_add_tool(Context *ctx, const char *tool_call_id,
                  const char *content)
{
    Message *m = ctx_alloc_msg(ctx);
    m->role         = ROLE_TOOL;
    m->content      = xstrdup(content);
    m->tool_call_id = xstrdup(tool_call_id);
    ctx->cached_tokens += msg_estimate_tokens(m);
}

void ctx_clear(Context *ctx)
{
    /* preserve the first message if it's the system prompt */
    int start = 0;
    if (ctx->n_msgs > 0 && ctx->msgs[0].role == ROLE_SYSTEM)
        start = 1;
    for (int i = start; i < ctx->n_msgs; i++) {
        ctx->cached_tokens -= msg_estimate_tokens(&ctx->msgs[i]);
        msg_free(&ctx->msgs[i]);
    }
    ctx->n_msgs = start;
}

int ctx_msg_count(const Context *ctx) { return ctx->n_msgs; }

/* ---------- JSON serialization ---------- */
static const char *role_str(Role r)
{
    switch (r) {
    case ROLE_SYSTEM:    return "system";
    case ROLE_USER:      return "user";
    case ROLE_ASSISTANT: return "assistant";
    case ROLE_TOOL:      return "tool";
    }
    return "user";
}

cJSON *ctx_to_json(const Context *ctx)
{
    cJSON *arr = cJSON_CreateArray();
    for (int i = 0; i < ctx->n_msgs; i++) {
        const Message *m = &ctx->msgs[i];
        cJSON *obj = cJSON_CreateObject();
        cJSON_AddStringToObject(obj, "role", role_str(m->role));
        if (m->content)
            cJSON_AddStringToObject(obj, "content", m->content);

        /* assistant: include reasoning_content if present (required by DeepSeek V4) */
        if (m->role == ROLE_ASSISTANT && m->reasoning_content)
            cJSON_AddStringToObject(obj, "reasoning_content",
                                    m->reasoning_content);

        /* assistant with tool_calls */
        if (m->role == ROLE_ASSISTANT && m->n_tool_calls > 0) {
            if (!m->content)
                cJSON_AddNullToObject(obj, "content");
            cJSON *tcs = cJSON_CreateArray();
            for (int j = 0; j < m->n_tool_calls; j++) {
                cJSON *tc = cJSON_CreateObject();
                cJSON_AddStringToObject(tc, "id", m->tool_calls[j].id);
                cJSON_AddStringToObject(tc, "type", "function");
                cJSON *fn = cJSON_CreateObject();
                cJSON_AddStringToObject(fn, "name", m->tool_calls[j].name);
                cJSON_AddStringToObject(fn, "arguments",
                                        m->tool_calls[j].arguments);
                cJSON_AddItemToObject(tc, "function", fn);
                cJSON_AddItemToArray(tcs, tc);
            }
            cJSON_AddItemToObject(obj, "tool_calls", tcs);
        }

        /* tool message */
        if (m->role == ROLE_TOOL && m->tool_call_id)
            cJSON_AddStringToObject(obj, "tool_call_id", m->tool_call_id);

        cJSON_AddItemToArray(arr, obj);
    }
    return arr;
}

/* ---------- token estimation ---------- */
static int estimate_str_tokens(const char *s)
{
    if (!s) return 0;
    /* Use strlen/3 instead of strlen/4 for better CJK accuracy.
     * Chinese UTF-8: 3 bytes/char, ~1 token/char → 3/3 = 1 (accurate).
     * English: 1 byte/char, ~0.25 token/char → 1/3 = 0.33 (slightly over,
     *   but being conservative is safer — triggers truncation earlier). */
    return (int)(strlen(s) / 3) + 1;
}

static int msg_estimate_tokens(const Message *m)
{
    int t = 4; /* message overhead */
    t += estimate_str_tokens(m->content);
    for (int j = 0; j < m->n_tool_calls; j++) {
        t += estimate_str_tokens(m->tool_calls[j].name);
        t += estimate_str_tokens(m->tool_calls[j].arguments);
    }
    return t;
}

int ctx_estimate_tokens(const Context *ctx)
{
    return ctx->cached_tokens;
}

/* ---------- truncation ---------- */

/*
 * Remove `count` messages starting at `idx`, shifting the rest down.
 */
static void ctx_remove_range(Context *ctx, int idx, int count)
{
    for (int i = idx; i < idx + count; i++) {
        ctx->cached_tokens -= msg_estimate_tokens(&ctx->msgs[i]);
        msg_free(&ctx->msgs[i]);
    }
    for (int i = idx; i < ctx->n_msgs - count; i++)
        ctx->msgs[i] = ctx->msgs[i + count];
    ctx->n_msgs -= count;
}

void ctx_truncate(Context *ctx)
{
    int limit = (int)(ctx->max_tokens * 0.8);
    while (ctx_estimate_tokens(ctx) > limit && ctx->n_msgs > 2) {
        /* find first non-system message to remove */
        int idx = (ctx->msgs[0].role == ROLE_SYSTEM) ? 1 : 0;
        if (idx >= ctx->n_msgs) break;

        Message *m = &ctx->msgs[idx];

        if (m->role == ROLE_ASSISTANT && m->n_tool_calls > 0) {
            /* Remove this ASSISTANT together with its subsequent TOOL
             * result messages to keep the pairing intact.  The API
             * requires every TOOL message to have a matching
             * ASSISTANT tool_call; orphaning either side causes
             * errors or confused continuations. */
            int end = idx + 1;
            while (end < ctx->n_msgs &&
                   ctx->msgs[end].role == ROLE_TOOL)
                end++;
            ctx_remove_range(ctx, idx, end - idx);
        } else if (m->role == ROLE_TOOL) {
            /* Orphaned TOOL message (its ASSISTANT was already gone).
             * Remove all consecutive TOOL messages at this position. */
            int end = idx;
            while (end < ctx->n_msgs &&
                   ctx->msgs[end].role == ROLE_TOOL)
                end++;
            ctx_remove_range(ctx, idx, end - idx);
        } else {
            /* USER or plain ASSISTANT — safe to remove individually */
            ctx_remove_range(ctx, idx, 1);
        }
    }
}

bool ctx_drop_incomplete_tool_turn(Context *ctx)
{
    if (!ctx || ctx->n_msgs <= 0) return false;

    for (int i = 0; i < ctx->n_msgs; i++) {
        Message *m = &ctx->msgs[i];
        if (m->role != ROLE_ASSISTANT || m->n_tool_calls <= 0)
            continue;

        int end = i + 1;
        while (end < ctx->n_msgs && ctx->msgs[end].role == ROLE_TOOL)
            end++;
        int n_tools = end - (i + 1);

        if (n_tools < m->n_tool_calls) {
            /* Incomplete tool turn (often caused by Ctrl+C in the middle
             * of tool execution). Remove this assistant+tool block to keep
             * request history valid for the API. */
            ctx_remove_range(ctx, i, end - i);
            return true;
        }
    }
    return false;
}
