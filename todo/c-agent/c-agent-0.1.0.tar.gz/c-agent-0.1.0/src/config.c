#include "config.h"
#include "util.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <errno.h>

static char g_config_path[512];

const char *config_path(void)
{
    if (g_config_path[0]) return g_config_path;

    const char *home = getenv("HOME");
    if (!home) home = "/tmp";
    snprintf(g_config_path, sizeof(g_config_path),
             "%s/.c-agent/config.json", home);
    return g_config_path;
}

static void ensure_config_dir(void)
{
    const char *home = getenv("HOME");
    if (!home) home = "/tmp";
    char dir[512];
    snprintf(dir, sizeof(dir), "%s/.c-agent", home);
    mkdir(dir, 0755);
}

void config_load(Config *cfg)
{
    /* defaults */
    cfg->api_key            = NULL;
    cfg->base_url           = xstrdup("https://api.deepseek.com");
    cfg->model              = xstrdup("deepseek-v4-flash");
    cfg->reasoning_model    = xstrdup("deepseek-v4-pro");
    cfg->fast_model         = xstrdup("deepseek-v4-flash");
    cfg->max_tokens         = 16384;
    cfg->temperature        = 0.0;
    cfg->max_context_tokens = 1000000;
    cfg->max_tool_rounds    = 25;
    cfg->planner_max_rounds      = 15;
    cfg->explorer_max_rounds     = 10;
    cfg->tool_result_max_chars   = 16000;
    cfg->sub_agent_result_max_chars = 4000;

    /* track which fields were explicitly set */
    bool has_max_tokens = false;
    bool has_max_context = false;
    bool has_max_rounds = false;

    /* read config file */
    FILE *fp = fopen(config_path(), "r");
    if (fp) {
        fseek(fp, 0, SEEK_END);
        long sz = ftell(fp);
        fseek(fp, 0, SEEK_SET);
        if (sz > 0 && sz < 100000) {
            char *buf = xmalloc((size_t)sz + 1);
            size_t rd = fread(buf, 1, (size_t)sz, fp);
            buf[rd] = '\0';

            cJSON *root = cJSON_Parse(buf);
            if (root) {
                cJSON *v;
                v = cJSON_GetObjectItem(root, "api_key");
                if (v && cJSON_IsString(v))
                    cfg->api_key = xstrdup(v->valuestring);

                v = cJSON_GetObjectItem(root, "base_url");
                if (v && cJSON_IsString(v)) {
                    free(cfg->base_url);
                    cfg->base_url = xstrdup(v->valuestring);
                }

                v = cJSON_GetObjectItem(root, "model");
                if (v && cJSON_IsString(v)) {
                    free(cfg->model);
                    cfg->model = xstrdup(v->valuestring);
                }

                v = cJSON_GetObjectItem(root, "reasoning_model");
                if (v && cJSON_IsString(v)) {
                    free(cfg->reasoning_model);
                    cfg->reasoning_model = xstrdup(v->valuestring);
                }

                v = cJSON_GetObjectItem(root, "fast_model");
                if (v && cJSON_IsString(v)) {
                    free(cfg->fast_model);
                    cfg->fast_model = xstrdup(v->valuestring);
                }

                v = cJSON_GetObjectItem(root, "max_tokens");
                if (v && cJSON_IsNumber(v)) {
                    cfg->max_tokens = v->valueint;
                    has_max_tokens = true;
                }

                v = cJSON_GetObjectItem(root, "temperature");
                if (v && cJSON_IsNumber(v))
                    cfg->temperature = v->valuedouble;

                v = cJSON_GetObjectItem(root, "max_context_tokens");
                if (v && cJSON_IsNumber(v)) {
                    cfg->max_context_tokens = v->valueint;
                    has_max_context = true;
                }

                v = cJSON_GetObjectItem(root, "max_tool_rounds");
                if (v && cJSON_IsNumber(v)) {
                    cfg->max_tool_rounds = v->valueint;
                    has_max_rounds = true;
                }

                v = cJSON_GetObjectItem(root, "planner_max_rounds");
                if (v && cJSON_IsNumber(v))
                    cfg->planner_max_rounds = v->valueint;

                v = cJSON_GetObjectItem(root, "explorer_max_rounds");
                if (v && cJSON_IsNumber(v))
                    cfg->explorer_max_rounds = v->valueint;

                v = cJSON_GetObjectItem(root, "tool_result_max_chars");
                if (v && cJSON_IsNumber(v))
                    cfg->tool_result_max_chars = v->valueint;

                v = cJSON_GetObjectItem(root, "sub_agent_result_max_chars");
                if (v && cJSON_IsNumber(v))
                    cfg->sub_agent_result_max_chars = v->valueint;

                cJSON_Delete(root);
            }
            free(buf);
        }
        fclose(fp);
    }

    /* env vars override config file */
    const char *env;
    env = getenv("DEEPSEEK_API_KEY");
    if (env && env[0]) {
        free(cfg->api_key);
        cfg->api_key = xstrdup(env);
    }

    env = getenv("DEEPSEEK_BASE_URL");
    if (env && env[0]) {
        free(cfg->base_url);
        cfg->base_url = xstrdup(env);
    }

    env = getenv("DEEPSEEK_MODEL");
    if (env && env[0]) {
        free(cfg->model);
        cfg->model = xstrdup(env);
    }

    /* Termux/Android: apply mobile-optimized defaults for fields not
     * explicitly set by the user in config.json. */
    if (is_termux()) {
        if (!has_max_context)
            cfg->max_context_tokens = 32000;
        if (!has_max_tokens)
            cfg->max_tokens = 4096;
        if (!has_max_rounds)
            cfg->max_tool_rounds = 15;
        cfg->tool_result_max_chars = 8000;
        cfg->sub_agent_result_max_chars = 2000;
    }
}

bool config_save(const Config *cfg)
{
    ensure_config_dir();

    cJSON *root = cJSON_CreateObject();
    if (cfg->api_key)
        cJSON_AddStringToObject(root, "api_key", cfg->api_key);
    cJSON_AddStringToObject(root, "base_url", cfg->base_url);
    cJSON_AddStringToObject(root, "model", cfg->model);
    cJSON_AddStringToObject(root, "reasoning_model", cfg->reasoning_model);
    cJSON_AddStringToObject(root, "fast_model", cfg->fast_model);
    cJSON_AddNumberToObject(root, "max_tokens", cfg->max_tokens);
    cJSON_AddNumberToObject(root, "temperature", cfg->temperature);
    cJSON_AddNumberToObject(root, "max_context_tokens",
                            cfg->max_context_tokens);
    cJSON_AddNumberToObject(root, "max_tool_rounds", cfg->max_tool_rounds);
    cJSON_AddNumberToObject(root, "planner_max_rounds",
                            cfg->planner_max_rounds);
    cJSON_AddNumberToObject(root, "explorer_max_rounds",
                            cfg->explorer_max_rounds);
    cJSON_AddNumberToObject(root, "tool_result_max_chars",
                            cfg->tool_result_max_chars);
    cJSON_AddNumberToObject(root, "sub_agent_result_max_chars",
                            cfg->sub_agent_result_max_chars);

    char *json_str = cJSON_Print(root);
    cJSON_Delete(root);

    FILE *fp = fopen(config_path(), "w");
    if (!fp) {
        LOG_ERROR("Cannot write config to %s: %s",
                  config_path(), strerror(errno));
        free(json_str);
        return false;
    }
    fputs(json_str, fp);
    fputc('\n', fp);
    fclose(fp);
    free(json_str);

    LOG_INFO("Config saved to %s", config_path());
    return true;
}

bool config_set(Config *cfg, const char *key, const char *value)
{
    if (strcmp(key, "api_key") == 0) {
        free(cfg->api_key);
        cfg->api_key = xstrdup(value);
    } else if (strcmp(key, "base_url") == 0) {
        free(cfg->base_url);
        cfg->base_url = xstrdup(value);
    } else if (strcmp(key, "model") == 0) {
        free(cfg->model);
        cfg->model = xstrdup(value);
    } else if (strcmp(key, "reasoning_model") == 0) {
        free(cfg->reasoning_model);
        cfg->reasoning_model = xstrdup(value);
    } else if (strcmp(key, "fast_model") == 0) {
        free(cfg->fast_model);
        cfg->fast_model = xstrdup(value);
    } else if (strcmp(key, "max_tokens") == 0) {
        cfg->max_tokens = atoi(value);
    } else if (strcmp(key, "temperature") == 0) {
        cfg->temperature = atof(value);
    } else if (strcmp(key, "max_context_tokens") == 0) {
        cfg->max_context_tokens = atoi(value);
    } else if (strcmp(key, "max_tool_rounds") == 0) {
        cfg->max_tool_rounds = atoi(value);
    } else if (strcmp(key, "planner_max_rounds") == 0) {
        cfg->planner_max_rounds = atoi(value);
    } else if (strcmp(key, "explorer_max_rounds") == 0) {
        cfg->explorer_max_rounds = atoi(value);
    } else if (strcmp(key, "tool_result_max_chars") == 0) {
        cfg->tool_result_max_chars = atoi(value);
    } else if (strcmp(key, "sub_agent_result_max_chars") == 0) {
        cfg->sub_agent_result_max_chars = atoi(value);
    } else {
        return false;
    }
    return true;
}

void config_free(Config *cfg)
{
    free(cfg->api_key);
    free(cfg->base_url);
    free(cfg->model);
    free(cfg->reasoning_model);
    free(cfg->fast_model);
    memset(cfg, 0, sizeof(*cfg));
}
