#include "tools.h"
#include "util.h"
#include "cJSON.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

/*
 * edit_file: search-and-replace tool, similar to Claude Code's Edit.
 *
 * Parameters:
 *   file_path   - path to the file
 *   old_string  - exact text to find (must be unique unless replace_all)
 *   new_string  - replacement text
 *   replace_all - if true, replace all occurrences (default false)
 */
char *tool_edit_exec(const char *args_json, void *userdata)
{
    (void)userdata;
    cJSON *args = cJSON_Parse(args_json);
    if (!args) return xstrdup("Error: invalid JSON arguments");

    cJSON *path_j    = cJSON_GetObjectItem(args, "file_path");
    cJSON *old_j     = cJSON_GetObjectItem(args, "old_string");
    cJSON *new_j     = cJSON_GetObjectItem(args, "new_string");
    cJSON *repl_all_j = cJSON_GetObjectItem(args, "replace_all");

    if (!path_j || !cJSON_IsString(path_j)) {
        cJSON_Delete(args);
        return xstrdup("Error: missing 'file_path' parameter");
    }
    if (!old_j || !cJSON_IsString(old_j)) {
        cJSON_Delete(args);
        return xstrdup("Error: missing 'old_string' parameter");
    }
    if (!new_j || !cJSON_IsString(new_j)) {
        cJSON_Delete(args);
        return xstrdup("Error: missing 'new_string' parameter");
    }

    bool replace_all = false;
    if (repl_all_j && cJSON_IsBool(repl_all_j))
        replace_all = cJSON_IsTrue(repl_all_j);

    const char *filepath   = path_j->valuestring;
    const char *old_string = old_j->valuestring;
    const char *new_string = new_j->valuestring;

    /* read the file */
    FILE *fp = fopen(filepath, "r");
    if (!fp) {
        StrBuf sb;
        strbuf_init(&sb);
        strbuf_appendf(&sb, "Error: cannot open '%s': %s",
                        filepath, strerror(errno));
        cJSON_Delete(args);
        return strbuf_detach(&sb);
    }

    fseek(fp, 0, SEEK_END);
    long sz = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    if (sz < 0 || sz > 10 * 1024 * 1024) {
        fclose(fp);
        cJSON_Delete(args);
        return xstrdup("Error: file too large (>10MB) or unreadable");
    }

    char *content = xmalloc((size_t)sz + 1);
    size_t rd = fread(content, 1, (size_t)sz, fp);
    content[rd] = '\0';
    fclose(fp);

    size_t old_len = strlen(old_string);

    if (old_len == 0) {
        free(content);
        cJSON_Delete(args);
        return xstrdup("Error: 'old_string' cannot be empty");
    }

    if (strcmp(old_string, new_string) == 0) {
        free(content);
        cJSON_Delete(args);
        return xstrdup("Error: 'old_string' and 'new_string' are identical");
    }

    /* count occurrences first */
    int count = 0;
    {
        const char *p = content;
        while ((p = strstr(p, old_string)) != NULL) {
            count++;
            p += old_len;
        }
    }

    if (count == 0) {
        free(content);
        cJSON_Delete(args);
        return xstrdup("Error: 'old_string' not found in file. "
                        "Make sure the string matches exactly, "
                        "including whitespace and indentation.");
    }

    if (!replace_all && count > 1) {
        free(content);
        cJSON_Delete(args);
        StrBuf sb;
        strbuf_init(&sb);
        strbuf_appendf(&sb,
            "Error: 'old_string' found %d times in file. "
            "It must be unique for a single replacement. "
            "Either provide more surrounding context to make it unique, "
            "or set 'replace_all' to true.",
            count);
        return strbuf_detach(&sb);
    }

    /* perform replacement */
    StrBuf result;
    strbuf_init(&result);

    const char *p = content;
    int replacements = 0;

    while (*p) {
        const char *found = strstr(p, old_string);
        if (!found || (!replace_all && replacements >= 1)) {
            /* append the rest */
            strbuf_appends(&result, p);
            break;
        }
        /* append text before the match */
        strbuf_append(&result, p, (size_t)(found - p));
        /* append replacement */
        strbuf_appends(&result, new_string);
        replacements++;
        p = found + old_len;
    }

    /* write back */
    fp = fopen(filepath, "w");
    if (!fp) {
        free(content);
        strbuf_free(&result);
        cJSON_Delete(args);
        StrBuf sb;
        strbuf_init(&sb);
        strbuf_appendf(&sb, "Error: cannot write to '%s': %s",
                        filepath, strerror(errno));
        return strbuf_detach(&sb);
    }

    fwrite(result.data, 1, result.len, fp);
    fclose(fp);

    free(content);

    StrBuf msg;
    strbuf_init(&msg);
    strbuf_appendf(&msg, "Successfully edited '%s': %d replacement(s) made.",
                    filepath, replacements);

    strbuf_free(&result);
    cJSON_Delete(args);
    return strbuf_detach(&msg);
}
