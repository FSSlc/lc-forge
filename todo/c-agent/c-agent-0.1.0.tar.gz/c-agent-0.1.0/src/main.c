#include "agent.h"
#include "api.h"
#include "config.h"
#include "repl.h"
#include "telegram.h"
#include "util.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <unistd.h>
#include <errno.h>

static void print_usage(const char *prog)
{
    fprintf(stderr,
        "Usage: %s [options]\n"
        "\n"
        "Options:\n"
        "  -C, --workspace DIR   Set workspace directory (default: cwd)\n"
        "  -k, --api-key KEY     DeepSeek API key\n"
        "  -m, --model MODEL     Model name (default: deepseek-chat)\n"
        "  -u, --base-url URL    API base URL\n"
        "  -e, --execute CMD     Execute a single prompt and exit\n"
        "  -t, --telegram        Run as Telegram bot (long polling)\n"
        "  -d, --debug           Enable debug logging\n"
        "  -h, --help            Show this help\n"
        "\n"
        "Config file: ~/.c-agent/config.json\n"
        "Environment: DEEPSEEK_API_KEY, DEEPSEEK_BASE_URL, DEEPSEEK_MODEL\n"
        "             TELEGRAM_BOT_TOKEN\n"
        "\n",
        prog);
}

int main(int argc, char *argv[])
{
    /* load config from file + env */
    Config cfg;
    config_load(&cfg);

    char *execute_cmd = NULL;
    char *workspace   = NULL;
    bool debug = false;
    bool telegram_mode = false;

    static struct option long_opts[] = {
        { "workspace", required_argument, NULL, 'C' },
        { "api-key",   required_argument, NULL, 'k' },
        { "model",     required_argument, NULL, 'm' },
        { "base-url",  required_argument, NULL, 'u' },
        { "execute",   required_argument, NULL, 'e' },
        { "telegram",  no_argument,       NULL, 't' },
        { "debug",     no_argument,       NULL, 'd' },
        { "help",      no_argument,       NULL, 'h' },
        { NULL, 0, NULL, 0 }
    };

    int opt;
    while ((opt = getopt_long(argc, argv, "C:k:m:u:e:tdh", long_opts, NULL)) != -1) {
        switch (opt) {
        case 'C':
            free(workspace);
            workspace = xstrdup(optarg);
            break;
        case 'k':
            free(cfg.api_key);
            cfg.api_key = xstrdup(optarg);
            break;
        case 'm':
            free(cfg.model);
            cfg.model = xstrdup(optarg);
            break;
        case 'u':
            free(cfg.base_url);
            cfg.base_url = xstrdup(optarg);
            break;
        case 'e':
            execute_cmd = xstrdup(optarg);
            break;
        case 't':
            telegram_mode = true;
            break;
        case 'd':
            debug = true;
            break;
        case 'h':
            print_usage(argv[0]);
            return 0;
        default:
            print_usage(argv[0]);
            return 1;
        }
    }

    if (debug)
        log_set_level(LOG_DEBUG);

    /*
     * Workspace resolution:
     *   -C flag > cwd (where the user launched c-agent)
     *
     * We chdir to the workspace so all tools (bash, read, write, grep, list)
     * naturally work relative to it.
     */
    if (workspace) {
        if (chdir(workspace) != 0) {
            fprintf(stderr, "Error: cannot chdir to workspace '%s': %s\n",
                    workspace, strerror(errno));
            free(workspace);
            config_free(&cfg);
            return 1;
        }
    }

    /* resolve the absolute workspace path */
    {
        char cwd[4096];
        if (getcwd(cwd, sizeof(cwd)))
            cfg.workspace = xstrdup(cwd);
        else
            cfg.workspace = xstrdup(".");
    }
    free(workspace);

    /* init curl globally */
    api_global_init();

    /* create agent */
    Agent agent;
    agent_init(&agent, &cfg, AGENT_DEFAULT);

    if (execute_cmd) {
        /* single-shot mode */
        if (!cfg.api_key || !cfg.api_key[0]) {
            fprintf(stderr, "Error: no API key. Set DEEPSEEK_API_KEY or "
                    "use /config set api_key.\n");
            free(execute_cmd);
            agent_free(&agent);
            config_free(&cfg);
            api_global_cleanup();
            return 1;
        }
        char *reply = agent_process(&agent, execute_cmd);
        fprintf(stdout, "\n");
        free(reply);
        free(execute_cmd);
    } else if (telegram_mode) {
        /* Telegram bot mode */
        telegram_run(&agent, &cfg);
    } else {
        /* interactive REPL */
        repl_run(&agent, &cfg);
    }

    agent_free(&agent);
    config_free(&cfg);
    api_global_cleanup();
    return 0;
}
