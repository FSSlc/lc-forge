#include "agent.h"
#include "util.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <ctype.h>

/* ---------- System prompts per agent type ---------- */
static const char *SYSTEM_PROMPT_DEFAULT =
    "You are c-agent, a helpful AI coding assistant running in a terminal.\n"
    "You have access to tools for:\n"
    "  - Reading, writing, editing files\n"
    "  - Running bash commands\n"
    "  - Searching code (grep) and listing files\n"
    "  - Creating and managing TODO plans (todo_create, todo_update, todo_list)\n"
    "  - Spawning sub-agents for parallel/specialized work\n\n"
    "For complex tasks, use todo_create to plan your work, then update status "
    "as you progress.\n"
    "When a user asks to use a specific skill by name, follow that skill's "
    "workflow and file conventions strictly; do not invent alternate formats.\n\n"
    "Be concise. Use tools proactively to help the user.";

static const char *SYSTEM_PROMPT_PLANNER =
    "You are a planning agent with deep reasoning capabilities.\n"
    "Your job is to analyze complex tasks, break them into steps, and "
    "create actionable plans. You have access to tools for reading files, "
    "searching code, running commands, and creating TODOs.\n"
    "Think step by step. Be thorough in your analysis.";

static const char *SYSTEM_PROMPT_EXPLORER =
    "You are a fast exploration agent optimized for speed.\n"
    "Your job is to quickly find information in codebases: locate files, "
    "search for patterns, read code, and report findings concisely.\n"
    "Be fast and direct. Focus on answering the specific question asked.";

/* ---------- on_content callbacks for streaming ---------- */
static void print_content_delta(const char *delta, void *userdata)
{
    (void)userdata;
    fputs(delta, stdout);
    fflush(stdout);
}

static bool g_thinking_header_printed = false;

static void print_reasoning_delta(const char *delta, void *userdata)
{
    (void)userdata;
    if (!g_thinking_header_printed) {
        fprintf(stdout, "%s%s[thinking]%s ", CLR_DIM, CLR_MAGENTA, CLR_RESET);
        g_thinking_header_printed = true;
    }
    fprintf(stdout, "%s%s%s", CLR_DIM, delta, CLR_RESET);
    fflush(stdout);
}

/* ---------- TODO tool executors ---------- */
static char *tool_todo_create_exec(const char *args_json, void *userdata)
{
    Agent *agent = (Agent *)userdata;
    cJSON *args = cJSON_Parse(args_json);
    if (!args) return xstrdup("Error: invalid JSON arguments");

    /* support both single object and array of objects */
    cJSON *items_arr = NULL;
    bool free_arr = false;

    if (cJSON_IsArray(args)) {
        items_arr = args;
    } else if (cJSON_IsObject(args)) {
        /* check if there's a "todos" array field */
        cJSON *todos_j = cJSON_GetObjectItem(args, "todos");
        if (todos_j && cJSON_IsArray(todos_j)) {
            items_arr = todos_j;
        } else {
            /* single object — wrap in array */
            items_arr = cJSON_CreateArray();
            cJSON_AddItemToArray(items_arr, cJSON_Duplicate(args, 1));
            free_arr = true;
        }
    }

    if (!items_arr) {
        cJSON_Delete(args);
        return xstrdup("Error: expected object or array");
    }

    StrBuf result;
    strbuf_init(&result);
    int n = cJSON_GetArraySize(items_arr);
    for (int i = 0; i < n; i++) {
        cJSON *item = cJSON_GetArrayItem(items_arr, i);
        cJSON *subj = cJSON_GetObjectItem(item, "subject");
        cJSON *desc = cJSON_GetObjectItem(item, "description");
        if (!subj || !cJSON_IsString(subj)) {
            strbuf_appends(&result, "Error: missing 'subject' in item\n");
            continue;
        }
        int id = todo_create(&agent->todos,
            subj->valuestring,
            (desc && cJSON_IsString(desc)) ? desc->valuestring : NULL);
        strbuf_appendf(&result, "Created TODO #%d: %s\n",
                        id, subj->valuestring);
    }

    if (free_arr) cJSON_Delete(items_arr);
    cJSON_Delete(args);
    return strbuf_detach(&result);
}

static char *tool_todo_update_exec(const char *args_json, void *userdata)
{
    Agent *agent = (Agent *)userdata;
    cJSON *args = cJSON_Parse(args_json);
    if (!args) return xstrdup("Error: invalid JSON arguments");

    cJSON *id_j = cJSON_GetObjectItem(args, "id");
    cJSON *st_j = cJSON_GetObjectItem(args, "status");

    if (!id_j || !cJSON_IsNumber(id_j)) {
        cJSON_Delete(args);
        return xstrdup("Error: missing 'id' parameter (integer)");
    }
    if (!st_j || !cJSON_IsString(st_j)) {
        cJSON_Delete(args);
        return xstrdup("Error: missing 'status' parameter "
                        "(pending|in_progress|completed|failed)");
    }

    TodoStatus status;
    const char *s = st_j->valuestring;
    if (strcmp(s, "pending") == 0)          status = TODO_PENDING;
    else if (strcmp(s, "in_progress") == 0) status = TODO_IN_PROGRESS;
    else if (strcmp(s, "completed") == 0)   status = TODO_COMPLETED;
    else if (strcmp(s, "failed") == 0)      status = TODO_FAILED;
    else {
        cJSON_Delete(args);
        return xstrdup("Error: invalid status. "
                        "Use: pending, in_progress, completed, failed");
    }

    int id = id_j->valueint;
    bool ok = todo_update(&agent->todos, id, status);
    cJSON_Delete(args);

    if (ok) {
        StrBuf sb;
        strbuf_init(&sb);
        strbuf_appendf(&sb, "TODO #%d updated to '%s'", id,
                       todo_status_str(status));
        return strbuf_detach(&sb);
    } else {
        StrBuf sb;
        strbuf_init(&sb);
        strbuf_appendf(&sb, "Error: TODO #%d not found", id);
        return strbuf_detach(&sb);
    }
}

static char *tool_todo_list_exec(const char *args_json, void *userdata)
{
    (void)args_json;
    Agent *agent = (Agent *)userdata;
    return todo_format(&agent->todos);
}

/* ---------- register TODO tools on an agent ---------- */
static void register_todo_tools(Agent *agent)
{
    tools_register(&agent->tools, "todo_create",
        "Create one or more TODO items for tracking task progress. "
        "Use this to plan complex tasks by breaking them into steps.",
        "{"
        "  \"type\": \"object\","
        "  \"properties\": {"
        "    \"todos\": {"
        "      \"type\": \"array\","
        "      \"description\": \"Array of TODO items to create\","
        "      \"items\": {"
        "        \"type\": \"object\","
        "        \"properties\": {"
        "          \"subject\": {"
        "            \"type\": \"string\","
        "            \"description\": \"Brief title of the task\""
        "          },"
        "          \"description\": {"
        "            \"type\": \"string\","
        "            \"description\": \"Detailed description\""
        "          }"
        "        },"
        "        \"required\": [\"subject\"]"
        "      }"
        "    }"
        "  },"
        "  \"required\": [\"todos\"]"
        "}",
        tool_todo_create_exec, agent);

    tools_register(&agent->tools, "todo_update",
        "Update the status of a TODO item.",
        "{"
        "  \"type\": \"object\","
        "  \"properties\": {"
        "    \"id\": {"
        "      \"type\": \"integer\","
        "      \"description\": \"The TODO item ID\""
        "    },"
        "    \"status\": {"
        "      \"type\": \"string\","
        "      \"enum\": [\"pending\", \"in_progress\", \"completed\", \"failed\"],"
        "      \"description\": \"New status\""
        "    }"
        "  },"
        "  \"required\": [\"id\", \"status\"]"
        "}",
        tool_todo_update_exec, agent);

    tools_register(&agent->tools, "todo_list",
        "List all current TODO items with their status.",
        "{"
        "  \"type\": \"object\","
        "  \"properties\": {}"
        "}",
        tool_todo_list_exec, agent);
}

/* ---------- init / free ---------- */
void agent_init(Agent *agent, Config *cfg, AgentType type)
{
    memset(agent, 0, sizeof(*agent));
    agent->config       = cfg;
    agent->type         = type;
    agent->is_sub_agent = (type != AGENT_DEFAULT);
    agent->max_rounds   = cfg->max_tool_rounds;

    /* API config: select model based on agent type */
    api_config_init(&agent->api_cfg);

    free(agent->api_cfg.api_key);
    agent->api_cfg.api_key = cfg->api_key ? xstrdup(cfg->api_key) : NULL;

    free(agent->api_cfg.base_url);
    agent->api_cfg.base_url = xstrdup(cfg->base_url);

    free(agent->api_cfg.model);
    switch (type) {
    case AGENT_PLANNER:
        agent->api_cfg.model = xstrdup(cfg->reasoning_model);
        agent->api_cfg.enable_thinking = true;
        agent->max_rounds = cfg->planner_max_rounds;
        break;
    case AGENT_EXPLORER:
        agent->api_cfg.model = xstrdup(cfg->fast_model);
        agent->api_cfg.enable_thinking = false;
        agent->max_rounds = cfg->explorer_max_rounds;
        break;
    default:
        agent->api_cfg.model = xstrdup(cfg->model);
        agent->api_cfg.enable_thinking = false;
        break;
    }

    agent->api_cfg.max_tokens  = cfg->max_tokens;
    agent->api_cfg.temperature = cfg->temperature;

    /* context */
    ctx_init(&agent->ctx, cfg->max_context_tokens);

    /* tools: built-in file/bash tools */
    tools_init(&agent->tools);
    register_builtin_tools(&agent->tools);

    /* Termux:API tools (only on Android/Termux) */
    if (is_termux())
        register_termux_tools(&agent->tools);

    /* TODO tools (all agents can track TODOs) */
    todo_init(&agent->todos);
    register_todo_tools(agent);

    /* only parent (default) agent gets spawn_sub_agent */
    if (type == AGENT_DEFAULT) {
        tools_register(&agent->tools, "spawn_sub_agent",
            "Spawn a sub-agent to handle a subtask. Sub-agents run with "
            "their own context and tools.\n"
            "Agent types:\n"
            "  - \"planner\": reasoning model with thinking/CoT, for complex "
            "planning and analysis\n"
            "  - \"explorer\": fast model for quick code search and exploration\n"
            "  - \"default\": standard agent for general tasks",
            "{"
            "  \"type\": \"object\","
            "  \"properties\": {"
            "    \"task\": {"
            "      \"type\": \"string\","
            "      \"description\": \"Description of the subtask\""
            "    },"
            "    \"agent_type\": {"
            "      \"type\": \"string\","
            "      \"enum\": [\"planner\", \"explorer\", \"default\"],"
            "      \"description\": \"Type of sub-agent (default: 'default')\""
            "    }"
            "  },"
            "  \"required\": [\"task\"]"
            "}",
            tool_spawn_sub_agent_exec, agent);
    }

    /* workspace: inherit from parent config or use cwd */
    if (cfg->workspace)
        agent->workspace = xstrdup(cfg->workspace);
    else {
        char cwd[4096];
        if (getcwd(cwd, sizeof(cwd)))
            agent->workspace = xstrdup(cwd);
        else
            agent->workspace = xstrdup(".");
    }

    /* MCP: load config and start servers (main agent only) */
    mcp_init(&agent->mcp);
    if (type == AGENT_DEFAULT) {
        mcp_load_config(&agent->mcp, agent->workspace);
        if (agent->mcp.n_servers > 0) {
            mcp_start_all(&agent->mcp);
            mcp_register_tools(&agent->mcp, &agent->tools);
        }
    }

    /* Skills: discover and load skills (main agent only) */
    skill_init(&agent->skills);
    if (type == AGENT_DEFAULT) {
        skill_load(&agent->skills, agent->workspace);

        /* register skill install/remove tools */
        tools_register(&agent->tools, "skill_install",
            "Install a skill from a Git repository URL. "
            "By default installs to the workspace (.c-agent/skills/). "
            "Set global=true to install to the global directory (~/.c-agent/skills/).",
            "{"
            "  \"type\": \"object\","
            "  \"properties\": {"
            "    \"url\": {"
            "      \"type\": \"string\","
            "      \"description\": \"Git repository URL to clone\""
            "    },"
            "    \"name\": {"
            "      \"type\": \"string\","
            "      \"description\": \"Optional directory name (default: repo name)\""
            "    },"
            "    \"global\": {"
            "      \"type\": \"boolean\","
            "      \"description\": \"Install to global ~/.c-agent/skills/ instead of workspace (default: false)\""
            "    }"
            "  },"
            "  \"required\": [\"url\"]"
            "}",
            tool_skill_install_exec, agent);

        tools_register(&agent->tools, "skill_remove",
            "Remove an installed skill by name. "
            "By default removes from the workspace. "
            "Set global=true to remove from the global directory.",
            "{"
            "  \"type\": \"object\","
            "  \"properties\": {"
            "    \"name\": {"
            "      \"type\": \"string\","
            "      \"description\": \"Name of the skill to remove\""
            "    },"
            "    \"global\": {"
            "      \"type\": \"boolean\","
            "      \"description\": \"Remove from global ~/.c-agent/skills/ instead of workspace (default: false)\""
            "    }"
            "  },"
            "  \"required\": [\"name\"]"
            "}",
            tool_skill_remove_exec, agent);
    }

    /* Session persistence (main agent only) */
    session_init(&agent->session);
    if (type == AGENT_DEFAULT) {
        session_create(&agent->session, agent->workspace);
    }

    /* add system prompt based on type, with workspace info */
    const char *base_prompt;
    switch (type) {
    case AGENT_PLANNER:  base_prompt = SYSTEM_PROMPT_PLANNER;  break;
    case AGENT_EXPLORER: base_prompt = SYSTEM_PROMPT_EXPLORER; break;
    default:             base_prompt = SYSTEM_PROMPT_DEFAULT;   break;
    }

    StrBuf sys;
    strbuf_init(&sys);
    strbuf_appends(&sys, base_prompt);
    strbuf_appendf(&sys, "\n\nWorkspace: %s\n"
                   "All file paths should be relative to or within this directory.",
                   agent->workspace);

    /* append skill metadata to system prompt */
    skill_append_system_prompt(&agent->skills, &sys);

    ctx_add_system(&agent->ctx, sys.data);
    strbuf_free(&sys);
}

void agent_free(Agent *agent)
{
    session_free(&agent->session);
    skill_free(&agent->skills);
    mcp_free(&agent->mcp);
    api_config_free(&agent->api_cfg);
    ctx_free(&agent->ctx);
    tools_free(&agent->tools);
    todo_free(&agent->todos);
    free(agent->workspace);
}

void agent_interrupt(Agent *agent) { agent->interrupted = true; }

/* ---------- agent type label ---------- */
static const char *agent_type_label(AgentType t)
{
    switch (t) {
    case AGENT_PLANNER:  return "planner";
    case AGENT_EXPLORER: return "explorer";
    default:             return "c-agent";
    }
}

static const char *agent_type_color(AgentType t)
{
    switch (t) {
    case AGENT_PLANNER:  return CLR_MAGENTA;
    case AGENT_EXPLORER: return CLR_GREEN;
    default:             return CLR_CYAN;
    }
}

static bool contains_ci(const char *haystack, const char *needle)
{
    if (!haystack || !needle || !needle[0]) return false;
    size_t nlen = strlen(needle);
    for (const char *p = haystack; *p; p++) {
        size_t i = 0;
        while (i < nlen && p[i] &&
               tolower((unsigned char)p[i]) ==
               tolower((unsigned char)needle[i])) {
            i++;
        }
        if (i == nlen) return true;
    }
    return false;
}

/* Tolerate a common typo for "creator" -> "creater". */
static bool contains_skill_alias(const char *input, const char *name)
{
    if (!input || !name) return false;
    if (!strstr(name, "creator")) return false;

    char alias[256];
    snprintf(alias, sizeof(alias), "%s", name);
    char *p = strstr(alias, "creator");
    if (!p) return false;

    char tail[256];
    snprintf(tail, sizeof(tail), "%s", p + strlen("creator"));
    snprintf(p, (size_t)(alias + sizeof(alias) - p), "creater%s", tail);
    return contains_ci(input, alias);
}

static Skill *find_mentioned_skill(Agent *agent, const char *user_input)
{
    if (!agent || !user_input || agent->is_sub_agent) return NULL;
    if (strstr(user_input, "<skill name=\"")) return NULL; /* already injected */

    for (int i = 0; i < agent->skills.n_skills; i++) {
        Skill *sk = &agent->skills.skills[i];
        if (!sk->name || !sk->name[0]) continue;
        if (contains_ci(user_input, sk->name) ||
            contains_skill_alias(user_input, sk->name)) {
            return sk;
        }
    }
    return NULL;
}

/* ---------- sub-agent support ---------- */
typedef struct {
    Config    *config;
    char      *task;
    AgentType  type;
    char      *result;
} SubAgentArgs;

static void *sub_agent_thread(void *arg)
{
    SubAgentArgs *sa = (SubAgentArgs *)arg;

    Agent sub;
    agent_init(&sub, sa->config, sa->type);

    sa->result = agent_process(&sub, sa->task);

    agent_free(&sub);
    return NULL;
}

/* ---------- core processing loop ---------- */
char *agent_process(Agent *agent, const char *user_input)
{
    agent->interrupted = false;

    /* Recover from prior Ctrl+C turns that ended with unfinished tool calls. */
    while (ctx_drop_incomplete_tool_turn(&agent->ctx)) {}

    char *effective_input = xstrdup(user_input ? user_input : "");
    Skill *auto_skill = find_mentioned_skill(agent, user_input);
    if (auto_skill) {
        char *body = skill_read_content(auto_skill);
        if (body) {
            StrBuf injected;
            strbuf_init(&injected);
            strbuf_appendf(&injected, "<skill name=\"%s\">\n%s\n</skill>\n\n"
                                      "User request:\n%s",
                           auto_skill->name, body, effective_input);
            free(effective_input);
            effective_input = strbuf_detach(&injected);
            if (!agent->is_sub_agent) {
                fprintf(stdout, "%s[auto-skill: %s]%s\n",
                        CLR_YELLOW, auto_skill->name, CLR_RESET);
            }
        }
        free(body);
    }

    /* add user message */
    ctx_add_user(&agent->ctx, effective_input);
    if (!agent->is_sub_agent)
        session_append_user(&agent->session, effective_input);
    free(effective_input);

    /* truncate if over capacity */
    ctx_truncate(&agent->ctx);

    StrBuf final_reply;
    strbuf_init(&final_reply);

    for (int round = 0; round < agent->max_rounds; round++) {
        if (agent->interrupted) {
            strbuf_appends(&final_reply, "\n[interrupted]");
            break;
        }

        /* print prompt header */
        if (!agent->is_sub_agent) {
            fprintf(stdout, "\n%s%s%s%s> ",
                    CLR_BOLD, agent_type_color(agent->type),
                    agent_type_label(agent->type), CLR_RESET);
            fflush(stdout);
        }

        /* reset thinking header flag */
        g_thinking_header_printed = false;

        /* call API (streaming) */
        void (*content_cb)(const char *, void *) =
            agent->is_sub_agent ? NULL : print_content_delta;
        void (*reasoning_cb)(const char *, void *) =
            (agent->is_sub_agent || !agent->api_cfg.enable_thinking)
                ? NULL : print_reasoning_delta;

        ApiResponse resp = api_chat_stream(
            &agent->api_cfg, &agent->ctx, &agent->tools,
            content_cb, reasoning_cb, NULL);

        /* newline after thinking section if we printed one */
        if (!agent->is_sub_agent && g_thinking_header_printed)
            fprintf(stdout, "\n");

        if (!agent->is_sub_agent)
            fprintf(stdout, "\n");

        if (!resp.ok) {
            fprintf(stderr, "%sAPI Error: %s%s\n",
                    CLR_RED, resp.error ? resp.error : "unknown", CLR_RESET);
            strbuf_appends(&final_reply, "Error: API call failed");
            api_response_free(&resp);
            break;
        }

        /* add assistant message to context */
        ctx_add_assistant(&agent->ctx, resp.content,
                          resp.reasoning_content,
                          resp.tool_calls, resp.n_tool_calls);
        if (!agent->is_sub_agent)
            session_append_assistant(&agent->session, resp.content,
                                    resp.reasoning_content,
                                    resp.tool_calls, resp.n_tool_calls);

        /* accumulate content */
        if (resp.content)
            strbuf_appends(&final_reply, resp.content);

        /* if no tool calls, we're done */
        if (resp.n_tool_calls == 0) {
            if (!resp.content || !resp.content[0]) {
                strbuf_appends(&final_reply, "(empty model response)");
                if (!agent->is_sub_agent)
                    fprintf(stdout, "%s(no response from model)%s\n",
                            CLR_DIM, CLR_RESET);
            }
            api_response_free(&resp);
            break;
        }

        /* execute each tool call — with parallel sub-agent support.
         * When multiple spawn_sub_agent calls appear in one response,
         * launch them all concurrently, execute other tools sequentially,
         * then join the sub-agent threads. */

        /* Phase 1: identify sub-agent calls and launch threads */
        typedef struct {
            int           idx;       /* index in resp.tool_calls */
            SubAgentArgs  sa;
            pthread_t     tid;
            bool          launched;
        } ParallelSA;

        int n_parallel = 0;
        ParallelSA *psa = NULL;

        if (resp.n_tool_calls > 1) {
            /* count sub-agent calls */
            for (int i = 0; i < resp.n_tool_calls; i++) {
                if (strcmp(resp.tool_calls[i].name, "spawn_sub_agent") == 0)
                    n_parallel++;
            }
            if (n_parallel > 1) {
                psa = xmalloc(sizeof(ParallelSA) * (size_t)n_parallel);
                int pi = 0;
                for (int i = 0; i < resp.n_tool_calls; i++) {
                    ToolCall *tc = &resp.tool_calls[i];
                    if (strcmp(tc->name, "spawn_sub_agent") != 0)
                        continue;

                    cJSON *a = cJSON_Parse(tc->arguments);
                    cJSON *task_j = a ? cJSON_GetObjectItem(a, "task") : NULL;
                    cJSON *type_j = a ? cJSON_GetObjectItem(a, "agent_type") : NULL;

                    AgentType stype = AGENT_DEFAULT;
                    if (type_j && cJSON_IsString(type_j)) {
                        if (strcmp(type_j->valuestring, "planner") == 0)
                            stype = AGENT_PLANNER;
                        else if (strcmp(type_j->valuestring, "explorer") == 0)
                            stype = AGENT_EXPLORER;
                    }

                    psa[pi].idx = i;
                    psa[pi].sa.config = agent->config;
                    psa[pi].sa.task = task_j && cJSON_IsString(task_j)
                        ? xstrdup(task_j->valuestring)
                        : xstrdup("(no task)");
                    psa[pi].sa.type = stype;
                    psa[pi].sa.result = NULL;
                    psa[pi].launched = false;

                    const char *lbl = stype == AGENT_PLANNER ? "planner"
                                    : stype == AGENT_EXPLORER ? "explorer"
                                    : "default";
                    fprintf(stdout, "%s[spawning %s sub-agent %d/%d]%s %s\n",
                            CLR_CYAN, lbl, pi + 1, n_parallel,
                            CLR_RESET, psa[pi].sa.task);

                    if (pthread_create(&psa[pi].tid, NULL,
                                       sub_agent_thread, &psa[pi].sa) == 0) {
                        psa[pi].launched = true;
                    }
                    cJSON_Delete(a);
                    pi++;
                }
            } else {
                n_parallel = 0; /* only 1 sub-agent, run normally */
            }
        }

        /* Phase 2: execute tool calls sequentially (skip parallel sub-agents) */
        for (int i = 0; i < resp.n_tool_calls; i++) {
            if (agent->interrupted) {
                for (int j = i; j < resp.n_tool_calls; j++) {
                    ToolCall *pending = &resp.tool_calls[j];
                    /* skip if it's a parallel sub-agent (already running) */
                    bool is_psa = false;
                    for (int p = 0; p < n_parallel; p++) {
                        if (psa[p].idx == j) { is_psa = true; break; }
                    }
                    if (is_psa) continue;
                    const char *msg =
                        "Error: skipped because request was interrupted";
                    ctx_add_tool(&agent->ctx, pending->id, msg);
                    if (!agent->is_sub_agent)
                        session_append_tool(&agent->session, pending->id, msg);
                }
                break;
            }

            /* skip sub-agent calls that are running in parallel */
            bool is_parallel_sa = false;
            for (int p = 0; p < n_parallel; p++) {
                if (psa[p].idx == i) { is_parallel_sa = true; break; }
            }
            if (is_parallel_sa) continue;

            ToolCall *tc = &resp.tool_calls[i];

            if (!agent->is_sub_agent) {
                fprintf(stdout, "%s[tool: %s]%s ",
                        CLR_YELLOW, tc->name, CLR_RESET);
                if (tc->arguments) {
                    size_t alen = strlen(tc->arguments);
                    if (alen > 100)
                        fprintf(stdout, "%.100s...\n", tc->arguments);
                    else
                        fprintf(stdout, "%s\n", tc->arguments);
                }
                fflush(stdout);
            }

            char *result = tools_execute(&agent->tools, tc->name,
                                         tc->arguments);

            /* truncate very large tool results to prevent context overflow. */
            if (result) {
                size_t rlen = strlen(result);
                int max_chars = agent->config->tool_result_max_chars;
                if (rlen > (size_t)max_chars) {
                    int cut = max_chars;
                    for (int k = max_chars; k > max_chars - 200 && k > 0; k--) {
                        if (result[k] == '\n') { cut = k; break; }
                    }
                    result[cut] = '\0';
                    const char *notice =
                        "\n\n...[result truncated]...";
                    size_t nlen = strlen(notice);
                    result = xrealloc(result, (size_t)cut + nlen + 1);
                    memcpy(result + cut, notice, nlen + 1);
                }
            }

            /* show tool result (truncated) */
            if (!agent->is_sub_agent && result) {
                size_t rlen = strlen(result);
                if (rlen > 500)
                    fprintf(stdout, "%s%.500s...%s\n",
                            CLR_DIM, result, CLR_RESET);
                else
                    fprintf(stdout, "%s%s%s\n",
                            CLR_DIM, result, CLR_RESET);
            }

            /* add tool result to context */
            ctx_add_tool(&agent->ctx, tc->id,
                         result ? result : "Error: no result");
            if (!agent->is_sub_agent)
                session_append_tool(&agent->session, tc->id,
                                   result ? result : "Error: no result");
            free(result);
        }

        /* Phase 3: join parallel sub-agents and collect results */
        if (n_parallel > 0) {
            for (int p = 0; p < n_parallel; p++) {
                if (!psa[p].launched) {
                    ToolCall *tc = &resp.tool_calls[psa[p].idx];
                    const char *msg = "Error: failed to launch sub-agent thread";
                    ctx_add_tool(&agent->ctx, tc->id, msg);
                    if (!agent->is_sub_agent)
                        session_append_tool(&agent->session, tc->id, msg);
                    free(psa[p].sa.task);
                    continue;
                }

                pthread_join(psa[p].tid, NULL);

                char *result = psa[p].sa.result
                    ? psa[p].sa.result : xstrdup("(no result)");

                /* truncate sub-agent result */
                int sa_max = agent->config->sub_agent_result_max_chars;
                if ((int)strlen(result) > sa_max) {
                    result[sa_max] = '\0';
                    size_t len = strlen(result);
                    result = xrealloc(result, len + 30);
                    strcat(result, "\n...(truncated)...");
                }

                ToolCall *tc = &resp.tool_calls[psa[p].idx];

                if (!agent->is_sub_agent) {
                    fprintf(stdout, "%s[sub-agent %d/%d done]%s\n",
                            CLR_GREEN, p + 1, n_parallel, CLR_RESET);
                    size_t rlen = strlen(result);
                    if (rlen > 500)
                        fprintf(stdout, "%s%.500s...%s\n",
                                CLR_DIM, result, CLR_RESET);
                    else
                        fprintf(stdout, "%s%s%s\n",
                                CLR_DIM, result, CLR_RESET);
                }

                ctx_add_tool(&agent->ctx, tc->id, result);
                if (!agent->is_sub_agent)
                    session_append_tool(&agent->session, tc->id, result);

                free(result);
                free(psa[p].sa.task);
            }
            free(psa);
        }

        api_response_free(&resp);
        ctx_truncate(&agent->ctx);
    }

    return strbuf_detach(&final_reply);
}

char *tool_spawn_sub_agent_exec(const char *args_json, void *userdata)
{
    Agent *parent = (Agent *)userdata;
    cJSON *args = cJSON_Parse(args_json);
    if (!args) return xstrdup("Error: invalid JSON arguments");

    cJSON *task_j = cJSON_GetObjectItem(args, "task");
    if (!task_j || !cJSON_IsString(task_j)) {
        cJSON_Delete(args);
        return xstrdup("Error: missing 'task' parameter");
    }

    /* determine agent type */
    AgentType sub_type = AGENT_DEFAULT;
    cJSON *type_j = cJSON_GetObjectItem(args, "agent_type");
    if (type_j && cJSON_IsString(type_j)) {
        if (strcmp(type_j->valuestring, "planner") == 0)
            sub_type = AGENT_PLANNER;
        else if (strcmp(type_j->valuestring, "explorer") == 0)
            sub_type = AGENT_EXPLORER;
    }

    const char *type_label;
    const char *type_color;
    switch (sub_type) {
    case AGENT_PLANNER:
        type_label = "planner";
        type_color = CLR_MAGENTA;
        break;
    case AGENT_EXPLORER:
        type_label = "explorer";
        type_color = CLR_GREEN;
        break;
    default:
        type_label = "default";
        type_color = CLR_CYAN;
        break;
    }

    fprintf(stdout, "%s[spawning %s sub-agent]%s %s\n",
            type_color, type_label, CLR_RESET, task_j->valuestring);

    SubAgentArgs sa;
    sa.config = parent->config;
    sa.task   = xstrdup(task_j->valuestring);
    sa.type   = sub_type;
    sa.result = NULL;

    pthread_t tid;
    if (pthread_create(&tid, NULL, sub_agent_thread, &sa) != 0) {
        free(sa.task);
        cJSON_Delete(args);
        return xstrdup("Error: failed to create sub-agent thread");
    }

    pthread_join(tid, NULL);

    char *result = sa.result ? sa.result : xstrdup("(no result)");
    free(sa.task);
    cJSON_Delete(args);

    /* truncate very long sub-agent results */
    int max_chars = parent->config->sub_agent_result_max_chars;
    if ((int)strlen(result) > max_chars) {
        result[max_chars] = '\0';
        size_t len = strlen(result);
        result = xrealloc(result, len + 30);
        strcat(result, "\n...(truncated)...");
    }

    return result;
}
