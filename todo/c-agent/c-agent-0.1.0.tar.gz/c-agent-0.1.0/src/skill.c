#include "skill.h"
#include "agent.h"
#include "util.h"
#include "cJSON.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>

/* ---------- helpers ---------- */

/* Get ~/.c-agent/skills/ path. Returns static buffer. */
static const char *global_skills_dir(void)
{
    static char buf[4096];
    const char *home = get_home_dir();
    snprintf(buf, sizeof(buf), "%s/.c-agent/skills", home);
    return buf;
}

/* Strip leading/trailing whitespace in-place, return pointer into s */
static char *str_trim(char *s)
{
    while (*s == ' ' || *s == '\t') s++;
    size_t len = strlen(s);
    while (len > 0 && (s[len - 1] == ' ' || s[len - 1] == '\t' ||
                       s[len - 1] == '\n' || s[len - 1] == '\r'))
        s[--len] = '\0';
    return s;
}

/* Strip surrounding quotes (single or double) in-place */
static char *str_unquote(char *s)
{
    size_t len = strlen(s);
    if (len >= 2 && ((s[0] == '"' && s[len - 1] == '"') ||
                     (s[0] == '\'' && s[len - 1] == '\''))) {
        s[len - 1] = '\0';
        return s + 1;
    }
    return s;
}

/* Parse YAML frontmatter from SKILL.md content.
 * Extracts name and description. Returns body start offset. */
static int parse_frontmatter(const char *content, char **out_name,
                              char **out_desc)
{
    *out_name = NULL;
    *out_desc = NULL;

    const char *p = content;
    /* must start with --- */
    if (strncmp(p, "---", 3) != 0)
        return 0;
    p += 3;
    while (*p == ' ' || *p == '\t') p++;
    if (*p == '\r') p++;
    if (*p == '\n') p++;
    else return 0;

    /* find closing --- */
    const char *end = strstr(p, "\n---");
    if (!end) return 0;

    /* parse lines between markers */
    while (p < end) {
        const char *nl = strchr(p, '\n');
        if (!nl || nl > end) nl = end;

        /* copy line for manipulation */
        size_t llen = (size_t)(nl - p);
        char *line = xmalloc(llen + 1);
        memcpy(line, p, llen);
        line[llen] = '\0';

        char *trimmed = str_trim(line);
        if (strncmp(trimmed, "name:", 5) == 0) {
            char *val = str_trim(trimmed + 5);
            val = str_unquote(val);
            *out_name = xstrdup(val);
        } else if (strncmp(trimmed, "description:", 12) == 0) {
            char *val = str_trim(trimmed + 12);
            val = str_unquote(val);
            *out_desc = xstrdup(val);
        }
        free(line);

        p = nl + 1;
    }

    /* body starts after closing --- line */
    const char *body = end + 4;  /* skip \n--- */
    while (*body == ' ' || *body == '\t') body++;
    if (*body == '\r') body++;
    if (*body == '\n') body++;

    return (int)(body - content);
}

/* Read entire file into malloc'd buffer. Returns NULL on failure. */
static char *read_file_contents(const char *path)
{
    FILE *fp = fopen(path, "r");
    if (!fp) return NULL;

    fseek(fp, 0, SEEK_END);
    long sz = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    if (sz < 0 || sz > 1024 * 1024) {
        fclose(fp);
        return NULL;
    }

    char *buf = xmalloc((size_t)sz + 1);
    size_t rd = fread(buf, 1, (size_t)sz, fp);
    buf[rd] = '\0';
    fclose(fp);
    return buf;
}

/* Add a single skill entry. If name already exists, overwrite. */
static void add_skill(SkillManager *mgr, const char *name,
                      const char *description, const char *dir_path,
                      const char *skill_md_path, bool is_global)
{
    /* check for existing name (workspace overrides global) */
    for (int i = 0; i < mgr->n_skills; i++) {
        if (strcmp(mgr->skills[i].name, name) == 0) {
            /* replace */
            free(mgr->skills[i].name);
            free(mgr->skills[i].description);
            free(mgr->skills[i].dir_path);
            free(mgr->skills[i].skill_md_path);
            mgr->skills[i].name          = xstrdup(name);
            mgr->skills[i].description   = description ? xstrdup(description) : xstrdup("");
            mgr->skills[i].dir_path      = xstrdup(dir_path);
            mgr->skills[i].skill_md_path = xstrdup(skill_md_path);
            mgr->skills[i].is_global     = is_global;
            return;
        }
    }

    /* append new */
    mgr->skills = xrealloc(mgr->skills,
                            (size_t)(mgr->n_skills + 1) * sizeof(Skill));
    Skill *s = &mgr->skills[mgr->n_skills++];
    s->name          = xstrdup(name);
    s->description   = description ? xstrdup(description) : xstrdup("");
    s->dir_path      = xstrdup(dir_path);
    s->skill_md_path = xstrdup(skill_md_path);
    s->is_global     = is_global;
}

/* Scan a directory for skill subdirectories containing SKILL.md */
static void scan_skills_dir(SkillManager *mgr, const char *base_dir,
                            bool is_global)
{
    DIR *d = opendir(base_dir);
    if (!d) return;

    struct dirent *ent;
    while ((ent = readdir(d)) != NULL) {
        if (ent->d_name[0] == '.') continue;

        char dir_path[4096];
        snprintf(dir_path, sizeof(dir_path), "%s/%s", base_dir, ent->d_name);

        struct stat st;
        if (stat(dir_path, &st) != 0 || !S_ISDIR(st.st_mode))
            continue;

        char md_path[4096];
        snprintf(md_path, sizeof(md_path), "%s/SKILL.md", dir_path);

        if (access(md_path, R_OK) != 0) continue;

        /* parse frontmatter */
        char *content = read_file_contents(md_path);
        if (!content) continue;

        char *name = NULL, *desc = NULL;
        parse_frontmatter(content, &name, &desc);
        free(content);

        /* fallback name = directory name */
        if (!name)
            name = xstrdup(ent->d_name);

        add_skill(mgr, name, desc, dir_path, md_path, is_global);
        free(name);
        free(desc);
    }
    closedir(d);
}

/* ---------- public API ---------- */

void skill_init(SkillManager *mgr)
{
    mgr->skills   = NULL;
    mgr->n_skills = 0;
}

void skill_free(SkillManager *mgr)
{
    for (int i = 0; i < mgr->n_skills; i++) {
        free(mgr->skills[i].name);
        free(mgr->skills[i].description);
        free(mgr->skills[i].dir_path);
        free(mgr->skills[i].skill_md_path);
    }
    free(mgr->skills);
    mgr->skills   = NULL;
    mgr->n_skills = 0;
}

void skill_load(SkillManager *mgr, const char *workspace)
{
    /* clear existing */
    skill_free(mgr);
    skill_init(mgr);

    /* 1. scan global skills */
    scan_skills_dir(mgr, global_skills_dir(), true);

    /* 2. scan workspace skills (overrides global same-name) */
    if (workspace) {
        char ws_dir[4096];
        snprintf(ws_dir, sizeof(ws_dir), "%s/.c-agent/skills", workspace);
        scan_skills_dir(mgr, ws_dir, false);
    }

    if (mgr->n_skills > 0)
        LOG_INFO("Loaded %d skill(s)", mgr->n_skills);
}

Skill *skill_find(const SkillManager *mgr, const char *name)
{
    for (int i = 0; i < mgr->n_skills; i++) {
        if (strcmp(mgr->skills[i].name, name) == 0)
            return &mgr->skills[i];
    }
    return NULL;
}

char *skill_read_content(const Skill *skill)
{
    if (!skill) return NULL;

    char *content = read_file_contents(skill->skill_md_path);
    if (!content) return NULL;

    char *name = NULL, *desc = NULL;
    int body_offset = parse_frontmatter(content, &name, &desc);
    free(name);
    free(desc);

    if (body_offset > 0) {
        char *body = xstrdup(content + body_offset);
        free(content);
        return body;
    }

    return content;
}

void skill_print_list(const SkillManager *mgr)
{
    if (mgr->n_skills == 0) {
        fprintf(stdout, "\n  (no skills installed)\n\n"
                "  Install skills:\n"
                "    /skill install <git-url>\n"
                "  Or create manually:\n"
                "    ~/.c-agent/skills/<name>/SKILL.md\n\n");
        return;
    }

    fprintf(stdout, "\n");
    for (int i = 0; i < mgr->n_skills; i++) {
        const Skill *s = &mgr->skills[i];
        fprintf(stdout, "  %s/%s%s  %s%s%s\n",
                CLR_BOLD, s->name, CLR_RESET,
                CLR_DIM, s->description, CLR_RESET);
        fprintf(stdout, "    %s[%s]%s %s\n",
                CLR_DIM, s->is_global ? "global" : "workspace",
                CLR_RESET, s->dir_path);
    }
    fprintf(stdout, "\n");
}

void skill_append_system_prompt(const SkillManager *mgr, void *strbuf_ptr)
{
    StrBuf *sb = (StrBuf *)strbuf_ptr;
    if (mgr->n_skills == 0) return;

    strbuf_appends(sb,
        "\n\nAvailable skills (invoke with /<name> or mention skill name):\n");
    for (int i = 0; i < mgr->n_skills; i++) {
        strbuf_appendf(sb, "  - %s: %s\n",
                        mgr->skills[i].name,
                        mgr->skills[i].description);
    }
}

/* ---------- tool: skill_install ---------- */

/* Extract repo name from URL: https://github.com/user/repo.git -> repo */
static char *extract_repo_name(const char *url)
{
    /* find last / */
    const char *last_slash = strrchr(url, '/');
    if (!last_slash) return xstrdup("skill");
    const char *name = last_slash + 1;

    /* strip .git suffix */
    size_t len = strlen(name);
    if (len > 4 && strcmp(name + len - 4, ".git") == 0)
        len -= 4;
    if (len == 0) return xstrdup("skill");

    char *result = xmalloc(len + 1);
    memcpy(result, name, len);
    result[len] = '\0';
    return result;
}

/*
 * Parse GitHub subdirectory URL pattern:
 *   https://github.com/{owner}/{repo}/tree/{branch}/{subpath}
 *
 * Returns true if matched, fills out_repo_url, out_branch, out_subpath.
 * Caller frees all output strings.
 */
static bool parse_github_subdir_url(const char *url,
                                     char **out_repo_url,
                                     char **out_branch,
                                     char **out_subpath)
{
    *out_repo_url = NULL;
    *out_branch   = NULL;
    *out_subpath  = NULL;

    /* match github.com (with optional https:// or http://) */
    const char *gh = strstr(url, "github.com/");
    if (!gh) return false;

    const char *path = gh + 11;  /* after "github.com/" */

    /* parse owner */
    const char *slash1 = strchr(path, '/');
    if (!slash1) return false;

    /* parse repo */
    const char *slash2 = strchr(slash1 + 1, '/');
    if (!slash2) return false;

    /* expect "/tree/" after repo */
    if (strncmp(slash2, "/tree/", 6) != 0) return false;

    const char *after_tree = slash2 + 6;

    /* parse branch (up to next /) */
    const char *slash3 = strchr(after_tree, '/');
    if (!slash3) return false;

    /* subpath is everything after branch/ */
    const char *subpath = slash3 + 1;
    if (!*subpath) return false;

    /* strip trailing slash from subpath */
    size_t sp_len = strlen(subpath);
    while (sp_len > 0 && subpath[sp_len - 1] == '/')
        sp_len--;
    if (sp_len == 0) return false;

    /* build repo URL: everything up to /tree/ */
    size_t prefix_len = (size_t)(slash2 - url);
    *out_repo_url = xmalloc(prefix_len + 5);  /* +".git\0" */
    memcpy(*out_repo_url, url, prefix_len);
    memcpy(*out_repo_url + prefix_len, ".git", 5);

    /* branch */
    size_t br_len = (size_t)(slash3 - after_tree);
    *out_branch = xmalloc(br_len + 1);
    memcpy(*out_branch, after_tree, br_len);
    (*out_branch)[br_len] = '\0';

    /* subpath */
    *out_subpath = xmalloc(sp_len + 1);
    memcpy(*out_subpath, subpath, sp_len);
    (*out_subpath)[sp_len] = '\0';

    return true;
}

/* Run a shell command, capture output. Returns exit status. */
static int run_cmd_capture(const char *cmd, StrBuf *output)
{
    FILE *fp = popen(cmd, "r");
    if (!fp) return -1;

    char buf[1024];
    while (fgets(buf, sizeof(buf), fp))
        strbuf_appends(output, buf);
    return pclose(fp);
}

char *tool_skill_install_exec(const char *args_json, void *userdata)
{
    Agent *agent = (Agent *)userdata;
    cJSON *args = cJSON_Parse(args_json);
    if (!args) return xstrdup("Error: invalid JSON arguments");

    cJSON *url_j = cJSON_GetObjectItem(args, "url");
    if (!url_j || !cJSON_IsString(url_j)) {
        cJSON_Delete(args);
        return xstrdup("Error: missing 'url' parameter");
    }
    const char *url = url_j->valuestring;

    /* determine target: workspace (default) or global */
    cJSON *global_j = cJSON_GetObjectItem(args, "global");
    bool use_global = (global_j && cJSON_IsTrue(global_j));

    char base_dir[4096];
    if (use_global) {
        snprintf(base_dir, sizeof(base_dir), "%s", global_skills_dir());
    } else if (agent && agent->workspace) {
        snprintf(base_dir, sizeof(base_dir), "%s/.c-agent/skills",
                 agent->workspace);
    } else {
        snprintf(base_dir, sizeof(base_dir), "%s", global_skills_dir());
    }

    /* ensure skills directory exists */
    char mkdir_cmd[4200];
    snprintf(mkdir_cmd, sizeof(mkdir_cmd), "mkdir -p '%s'", base_dir);
    if (system(mkdir_cmd) != 0) {
        cJSON_Delete(args);
        return xstrdup("Error: failed to create skills directory");
    }

    /* check if this is a GitHub subdirectory URL */
    char *repo_url = NULL, *branch = NULL, *subpath = NULL;
    bool is_subdir = parse_github_subdir_url(url, &repo_url, &branch, &subpath);

    /* determine target directory name */
    cJSON *name_j = cJSON_GetObjectItem(args, "name");
    char *dir_name;
    if (name_j && cJSON_IsString(name_j)) {
        dir_name = xstrdup(name_j->valuestring);
    } else if (is_subdir) {
        dir_name = extract_repo_name(subpath);
    } else {
        dir_name = extract_repo_name(url);
    }

    /* check if already exists */
    char target[4096];
    snprintf(target, sizeof(target), "%s/%s", base_dir, dir_name);

    struct stat st_check;
    if (stat(target, &st_check) == 0) {
        StrBuf sb;
        strbuf_init(&sb);
        strbuf_appendf(&sb, "Error: skill directory '%s' already exists. "
                        "Remove it first with skill_remove.", dir_name);
        free(dir_name);
        free(repo_url); free(branch); free(subpath);
        cJSON_Delete(args);
        return strbuf_detach(&sb);
    }

    StrBuf cmd_output;
    strbuf_init(&cmd_output);
    int ret;

    if (is_subdir) {
        /* GitHub subdirectory: clone to temp, copy subpath out */
        char tmpdir[4096];
        snprintf(tmpdir, sizeof(tmpdir), "%s/.tmp_clone_XXXXXX", base_dir);

        /* create temp dir using mktemp shell command for portability */
        {
            char mktmp_cmd[4200];
            snprintf(mktmp_cmd, sizeof(mktmp_cmd),
                     "mktemp -d '%s' 2>&1", tmpdir);
            StrBuf mktmp_out;
            strbuf_init(&mktmp_out);
            int mktmp_ret = run_cmd_capture(mktmp_cmd, &mktmp_out);
            if (mktmp_ret != 0 || !mktmp_out.data || !mktmp_out.data[0]) {
                strbuf_free(&mktmp_out);
                free(dir_name);
                free(repo_url); free(branch); free(subpath);
                cJSON_Delete(args);
                return xstrdup("Error: failed to create temporary directory");
            }
            /* trim newline from mktemp output */
            char *td = mktmp_out.data;
            size_t tdlen = strlen(td);
            while (tdlen > 0 && (td[tdlen-1] == '\n' || td[tdlen-1] == '\r'))
                td[--tdlen] = '\0';
            snprintf(tmpdir, sizeof(tmpdir), "%s", td);
            strbuf_free(&mktmp_out);
        }

        /* shallow clone with specific branch */
        char clone_cmd[8192];
        snprintf(clone_cmd, sizeof(clone_cmd),
                 "git clone --depth 1 --branch '%s' '%s' '%s' 2>&1",
                 branch, repo_url, tmpdir);
        ret = run_cmd_capture(clone_cmd, &cmd_output);

        if (ret != 0) {
            StrBuf sb;
            strbuf_init(&sb);
            strbuf_appendf(&sb, "Error: git clone failed:\n%s",
                            cmd_output.data ? cmd_output.data : "");
            strbuf_free(&cmd_output);
            /* cleanup temp dir */
            char rm_tmp[4200];
            snprintf(rm_tmp, sizeof(rm_tmp), "rm -rf '%s'", tmpdir);
            system(rm_tmp);
            free(dir_name);
            free(repo_url); free(branch); free(subpath);
            cJSON_Delete(args);
            return strbuf_detach(&sb);
        }
        strbuf_reset(&cmd_output);

        /* check that subpath exists in cloned repo */
        char src_dir[4096];
        snprintf(src_dir, sizeof(src_dir), "%s/%s", tmpdir, subpath);

        struct stat st_sub;
        if (stat(src_dir, &st_sub) != 0 || !S_ISDIR(st_sub.st_mode)) {
            StrBuf sb;
            strbuf_init(&sb);
            strbuf_appendf(&sb, "Error: subdirectory '%s' not found in "
                            "repository", subpath);
            strbuf_free(&cmd_output);
            char rm_tmp[4200];
            snprintf(rm_tmp, sizeof(rm_tmp), "rm -rf '%s'", tmpdir);
            system(rm_tmp);
            free(dir_name);
            free(repo_url); free(branch); free(subpath);
            cJSON_Delete(args);
            return strbuf_detach(&sb);
        }

        /* copy subdirectory to target */
        char cp_cmd[8192];
        snprintf(cp_cmd, sizeof(cp_cmd), "cp -R '%s' '%s' 2>&1",
                 src_dir, target);
        ret = run_cmd_capture(cp_cmd, &cmd_output);

        /* cleanup temp dir */
        char rm_tmp[4200];
        snprintf(rm_tmp, sizeof(rm_tmp), "rm -rf '%s'", tmpdir);
        system(rm_tmp);

        if (ret != 0) {
            StrBuf sb;
            strbuf_init(&sb);
            strbuf_appendf(&sb, "Error: failed to copy subdirectory:\n%s",
                            cmd_output.data ? cmd_output.data : "");
            strbuf_free(&cmd_output);
            free(dir_name);
            free(repo_url); free(branch); free(subpath);
            cJSON_Delete(args);
            return strbuf_detach(&sb);
        }
    } else {
        /* normal git repo: direct clone */
        char clone_cmd[8192];
        snprintf(clone_cmd, sizeof(clone_cmd),
                 "git clone --depth 1 '%s' '%s' 2>&1", url, target);
        ret = run_cmd_capture(clone_cmd, &cmd_output);

        if (ret != 0) {
            StrBuf sb;
            strbuf_init(&sb);
            strbuf_appendf(&sb, "Error: git clone failed:\n%s",
                            cmd_output.data ? cmd_output.data : "");
            strbuf_free(&cmd_output);
            free(dir_name);
            free(repo_url); free(branch); free(subpath);
            cJSON_Delete(args);
            return strbuf_detach(&sb);
        }
    }
    strbuf_free(&cmd_output);
    free(repo_url); free(branch); free(subpath);

    /* verify SKILL.md exists */
    char md_path[4096];
    snprintf(md_path, sizeof(md_path), "%s/SKILL.md", target);
    if (access(md_path, R_OK) != 0) {
        StrBuf sb;
        strbuf_init(&sb);
        strbuf_appendf(&sb, "Warning: Installed '%s' but no SKILL.md found. "
                        "The skill may not work correctly.", dir_name);
        free(dir_name);
        cJSON_Delete(args);
        return strbuf_detach(&sb);
    }

    StrBuf result;
    strbuf_init(&result);
    strbuf_appendf(&result, "Successfully installed skill '%s' from %s\n"
                    "Location: %s [%s]",
                    dir_name, url, target,
                    use_global ? "global" : "workspace");
    free(dir_name);
    cJSON_Delete(args);
    return strbuf_detach(&result);
}

/* ---------- tool: skill_remove ---------- */

char *tool_skill_remove_exec(const char *args_json, void *userdata)
{
    Agent *agent = (Agent *)userdata;
    cJSON *args = cJSON_Parse(args_json);
    if (!args) return xstrdup("Error: invalid JSON arguments");

    cJSON *name_j = cJSON_GetObjectItem(args, "name");
    if (!name_j || !cJSON_IsString(name_j)) {
        cJSON_Delete(args);
        return xstrdup("Error: missing 'name' parameter");
    }
    const char *name = name_j->valuestring;

    /* determine target: workspace (default) or global */
    cJSON *global_j = cJSON_GetObjectItem(args, "global");
    bool use_global = (global_j && cJSON_IsTrue(global_j));

    char target[4096];
    if (use_global) {
        snprintf(target, sizeof(target), "%s/%s", global_skills_dir(), name);
    } else if (agent && agent->workspace) {
        snprintf(target, sizeof(target), "%s/.c-agent/skills/%s",
                 agent->workspace, name);
    } else {
        snprintf(target, sizeof(target), "%s/%s", global_skills_dir(), name);
    }

    struct stat st;
    if (stat(target, &st) != 0 || !S_ISDIR(st.st_mode)) {
        StrBuf sb;
        strbuf_init(&sb);
        strbuf_appendf(&sb, "Error: skill '%s' not found in %s directory (%s)",
                        name, use_global ? "global" : "workspace", target);
        cJSON_Delete(args);
        return strbuf_detach(&sb);
    }

    /* rm -rf the directory */
    char rm_cmd[4200];
    snprintf(rm_cmd, sizeof(rm_cmd), "rm -rf '%s'", target);
    int ret = system(rm_cmd);

    cJSON_Delete(args);

    if (ret != 0) {
        StrBuf sb;
        strbuf_init(&sb);
        strbuf_appendf(&sb, "Error: failed to remove skill '%s'", name);
        return strbuf_detach(&sb);
    }

    StrBuf result;
    strbuf_init(&result);
    strbuf_appendf(&result, "Successfully removed skill '%s' [%s]",
                    name, use_global ? "global" : "workspace");
    return strbuf_detach(&result);
}
