#include "sse.h"
#include "util.h"
#include <stdlib.h>
#include <string.h>

void sse_init(SseParser *p, SseChunkCb cb, void *userdata)
{
    p->line_buf  = xmalloc(256);
    p->line_len  = 0;
    p->line_cap  = 256;
    p->cb        = cb;
    p->userdata  = userdata;
    p->done      = false;
}

void sse_free(SseParser *p)
{
    free(p->line_buf);
    p->line_buf = NULL;
    p->line_len = p->line_cap = 0;
}

static void sse_process_line(SseParser *p, const char *line, size_t len)
{
    /* skip empty lines and comments */
    if (len == 0) return;
    if (line[0] == ':') return;

    /* we only care about "data: ..." lines */
    if (len < 6 || strncmp(line, "data: ", 6) != 0)
        return;

    const char *payload = line + 6;

    /* check for [DONE] sentinel */
    if (strcmp(payload, "[DONE]") == 0) {
        p->done = true;
        return;
    }

    /* parse JSON */
    cJSON *json = cJSON_Parse(payload);
    if (!json) return;

    if (p->cb)
        p->cb(json, p->userdata);

    cJSON_Delete(json);
}

void sse_feed(SseParser *p, const char *data, size_t len)
{
    for (size_t i = 0; i < len; i++) {
        char c = data[i];
        if (c == '\n') {
            /* strip trailing \r if present */
            size_t end = p->line_len;
            if (end > 0 && p->line_buf[end - 1] == '\r')
                end--;
            p->line_buf[end] = '\0';
            sse_process_line(p, p->line_buf, end);
            p->line_len = 0;
        } else {
            /* grow buffer if needed */
            if (p->line_len + 1 >= p->line_cap) {
                p->line_cap *= 2;
                p->line_buf = xrealloc(p->line_buf, p->line_cap);
            }
            p->line_buf[p->line_len++] = c;
        }
    }
}

bool sse_is_done(const SseParser *p) { return p->done; }
