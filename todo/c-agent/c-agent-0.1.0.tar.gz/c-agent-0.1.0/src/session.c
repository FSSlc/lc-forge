#include "session.h"
#include "util.h"
#include "cJSON.h"
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include <dirent.h>
#include <errno.h>

/* ---------- internal: write one JSON line ---------- */
static void session_write_line(Session *s, cJSON *obj)
{
    if (!s->fp || !obj) return;
    char *line = cJSON_PrintUnformatted(obj);
    if (line) {
        fputs(line, s->fp);
        fputc('\n', s->fp);
        fflush(s->fp);
        free(line);
    }
}

/* ---------- internal: sessions directory path ---------- */
static void sessions_dir(const char *workspace, char *buf, size_t sz)
{
    snprintf(buf, sz, "%s/.c-agent/sessions", workspace);
}

/* ---------- internal: ensure directory exists ---------- */
static void mkdirs(const char *path)
{
    char tmp[4096];
    snprintf(tmp, sizeof(tmp), "%s", path);
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = '\0';
            mkdir(tmp, 0755);
            *p = '/';
        }
    }
    mkdir(tmp, 0755);
}

/* ---------- lifecycle ---------- */
void session_init(Session *s)
{
    memset(s, 0, sizeof(*s));
}

void session_free(Session *s)
{
    if (s->fp) {
        fclose(s->fp);
        s->fp = NULL;
    }
    free(s->session_id);
    free(s->file_path);
    s->session_id = NULL;
    s->file_path  = NULL;
}

int session_create(Session *s, const char *workspace)
{
    /* close any existing session */
    session_free(s);

    /* ensure directory */
    char dir[4096];
    sessions_dir(workspace, dir, sizeof(dir));
    mkdirs(dir);

    /* generate session id: YYYYMMDD_HHMMSS_xxx */
    time_t now = time(NULL);
    struct tm tm;
    localtime_r(&now, &tm);

    unsigned int rnd = (unsigned int)(now ^ (long)s) & 0xFFF;
    char id[32];
    snprintf(id, sizeof(id), "%04d%02d%02d_%02d%02d%02d_%03x",
             tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
             tm.tm_hour, tm.tm_min, tm.tm_sec, rnd);

    char fpath[4096];
    snprintf(fpath, sizeof(fpath), "%s/%s.jsonl", dir, id);

    FILE *fp = fopen(fpath, "a");
    if (!fp) {
        LOG_ERROR("session: cannot create %s: %s", fpath, strerror(errno));
        return -1;
    }

    s->session_id = xstrdup(id);
    s->file_path  = xstrdup(fpath);
    s->fp         = fp;
    return 0;
}

/* ---------- append messages ---------- */
void session_append_user(Session *s, const char *content)
{
    if (!s->fp) return;
    cJSON *obj = cJSON_CreateObject();
    cJSON_AddNumberToObject(obj, "ts", (double)time(NULL));
    cJSON_AddStringToObject(obj, "role", "user");
    cJSON_AddStringToObject(obj, "content", content);
    session_write_line(s, obj);
    cJSON_Delete(obj);
}

void session_append_assistant(Session *s, const char *content,
                              const char *reasoning_content,
                              ToolCall *tcs, int n_tcs)
{
    if (!s->fp) return;
    cJSON *obj = cJSON_CreateObject();
    cJSON_AddNumberToObject(obj, "ts", (double)time(NULL));
    cJSON_AddStringToObject(obj, "role", "assistant");
    if (content)
        cJSON_AddStringToObject(obj, "content", content);
    else
        cJSON_AddNullToObject(obj, "content");

    if (reasoning_content)
        cJSON_AddStringToObject(obj, "reasoning_content", reasoning_content);

    if (n_tcs > 0) {
        cJSON *arr = cJSON_CreateArray();
        for (int i = 0; i < n_tcs; i++) {
            cJSON *tc = cJSON_CreateObject();
            cJSON_AddStringToObject(tc, "id", tcs[i].id);
            cJSON_AddStringToObject(tc, "type", "function");
            cJSON *fn = cJSON_CreateObject();
            cJSON_AddStringToObject(fn, "name", tcs[i].name);
            cJSON_AddStringToObject(fn, "arguments", tcs[i].arguments);
            cJSON_AddItemToObject(tc, "function", fn);
            cJSON_AddItemToArray(arr, tc);
        }
        cJSON_AddItemToObject(obj, "tool_calls", arr);
    }
    session_write_line(s, obj);
    cJSON_Delete(obj);
}

void session_append_tool(Session *s, const char *tool_call_id,
                         const char *content)
{
    if (!s->fp) return;
    cJSON *obj = cJSON_CreateObject();
    cJSON_AddNumberToObject(obj, "ts", (double)time(NULL));
    cJSON_AddStringToObject(obj, "role", "tool");
    cJSON_AddStringToObject(obj, "tool_call_id", tool_call_id);
    cJSON_AddStringToObject(obj, "content", content);
    session_write_line(s, obj);
    cJSON_Delete(obj);
}

/* ---------- load session into context ---------- */
int session_load_into_ctx(const char *file_path, Context *ctx)
{
    FILE *fp = fopen(file_path, "r");
    if (!fp) return -1;

    char buf[65536];
    int start_n = ctx ? ctx->n_msgs : 0;
    int count = 0;

    while (fgets(buf, sizeof(buf), fp)) {
        /* strip trailing newline */
        size_t len = strlen(buf);
        while (len > 0 && (buf[len - 1] == '\n' || buf[len - 1] == '\r'))
            buf[--len] = '\0';
        if (len == 0) continue;

        cJSON *obj = cJSON_Parse(buf);
        if (!obj) continue;

        cJSON *role_j = cJSON_GetObjectItem(obj, "role");
        if (!role_j || !cJSON_IsString(role_j)) {
            cJSON_Delete(obj);
            continue;
        }
        const char *role = role_j->valuestring;

        /* skip system messages */
        if (strcmp(role, "system") == 0) {
            cJSON_Delete(obj);
            continue;
        }

        cJSON *content_j = cJSON_GetObjectItem(obj, "content");
        const char *content = (content_j && cJSON_IsString(content_j))
                              ? content_j->valuestring : NULL;

        if (strcmp(role, "user") == 0) {
            if (content) {
                ctx_add_user(ctx, content);
                count++;
            }
        } else if (strcmp(role, "assistant") == 0) {
            /* parse tool_calls if present */
            cJSON *tcs_j = cJSON_GetObjectItem(obj, "tool_calls");
            ToolCall *tcs = NULL;
            int n_tcs = 0;

            if (tcs_j && cJSON_IsArray(tcs_j)) {
                n_tcs = cJSON_GetArraySize(tcs_j);
                if (n_tcs > 0) {
                    tcs = xmalloc((size_t)n_tcs * sizeof(ToolCall));
                    for (int i = 0; i < n_tcs; i++) {
                        cJSON *tc = cJSON_GetArrayItem(tcs_j, i);
                        cJSON *id_j = cJSON_GetObjectItem(tc, "id");
                        cJSON *fn_j = cJSON_GetObjectItem(tc, "function");
                        cJSON *name_j = fn_j ? cJSON_GetObjectItem(fn_j, "name") : NULL;
                        cJSON *args_j = fn_j ? cJSON_GetObjectItem(fn_j, "arguments") : NULL;
                        tcs[i].id = xstrdup(id_j && cJSON_IsString(id_j)
                                            ? id_j->valuestring : "");
                        tcs[i].name = xstrdup(name_j && cJSON_IsString(name_j)
                                              ? name_j->valuestring : "");
                        tcs[i].arguments = xstrdup(args_j && cJSON_IsString(args_j)
                                                   ? args_j->valuestring : "{}");
                    }
                }
            }

            /* parse reasoning_content if present (DeepSeek V4) */
            cJSON *rc_j = cJSON_GetObjectItem(obj, "reasoning_content");
            const char *reasoning = (rc_j && cJSON_IsString(rc_j))
                                    ? rc_j->valuestring : NULL;

            ctx_add_assistant(ctx, content, reasoning, tcs, n_tcs);
            count++;

            /* free temporary tool calls */
            for (int i = 0; i < n_tcs; i++)
                toolcall_free(&tcs[i]);
            free(tcs);
        } else if (strcmp(role, "tool") == 0) {
            cJSON *tcid_j = cJSON_GetObjectItem(obj, "tool_call_id");
            const char *tcid = (tcid_j && cJSON_IsString(tcid_j))
                               ? tcid_j->valuestring : "";
            ctx_add_tool(ctx, tcid, content ? content : "");
            count++;
        }

        cJSON_Delete(obj);
    }

    /* Drop incomplete assistant(tool_calls) blocks if the session was
     * interrupted before corresponding tool results were written. */
    while (ctx_drop_incomplete_tool_turn(ctx)) {}

    fclose(fp);
    count = ctx->n_msgs - start_n;
    if (count < 0) count = 0;
    return count;
}

/* ---------- comparator for sorting by mtime descending ---------- */
typedef struct {
    char  name[256];
    time_t mtime;
} SessionEntry;

static int cmp_session_desc(const void *a, const void *b)
{
    const SessionEntry *sa = (const SessionEntry *)a;
    const SessionEntry *sb = (const SessionEntry *)b;
    if (sb->mtime > sa->mtime) return 1;
    if (sb->mtime < sa->mtime) return -1;
    return 0;
}

/* ---------- internal: count lines in file ---------- */
static int count_lines(const char *path)
{
    FILE *fp = fopen(path, "r");
    if (!fp) return 0;
    int n = 0;
    char buf[4096];
    while (fgets(buf, sizeof(buf), fp)) n++;
    fclose(fp);
    return n;
}

/* ---------- internal: read first user message summary ---------- */
static void first_user_summary(const char *path, char *out, size_t sz)
{
    out[0] = '\0';
    FILE *fp = fopen(path, "r");
    if (!fp) return;

    char buf[65536];
    while (fgets(buf, sizeof(buf), fp)) {
        cJSON *obj = cJSON_Parse(buf);
        if (!obj) continue;
        cJSON *role_j = cJSON_GetObjectItem(obj, "role");
        if (role_j && cJSON_IsString(role_j) &&
            strcmp(role_j->valuestring, "user") == 0) {
            cJSON *c = cJSON_GetObjectItem(obj, "content");
            if (c && cJSON_IsString(c)) {
                size_t clen = strlen(c->valuestring);
                if (clen > sz - 4) {
                    memcpy(out, c->valuestring, sz - 4);
                    out[sz - 4] = '\0';
                    strcat(out, "...");
                } else {
                    snprintf(out, sz, "%s", c->valuestring);
                }
                /* replace newlines with spaces */
                for (char *p = out; *p; p++)
                    if (*p == '\n' || *p == '\r') *p = ' ';
            }
            cJSON_Delete(obj);
            break;
        }
        cJSON_Delete(obj);
    }
    fclose(fp);
}

/* ---------- list sessions ---------- */
void session_list_print(const char *workspace)
{
    char dir[4096];
    sessions_dir(workspace, dir, sizeof(dir));

    DIR *d = opendir(dir);
    if (!d) {
        fprintf(stdout, "\n  No sessions found.\n\n");
        return;
    }

    SessionEntry entries[256];
    int n = 0;

    struct dirent *ent;
    while ((ent = readdir(d)) != NULL && n < 256) {
        size_t nlen = strlen(ent->d_name);
        if (nlen < 6 || strcmp(ent->d_name + nlen - 6, ".jsonl") != 0)
            continue;
        char fpath[4096];
        snprintf(fpath, sizeof(fpath), "%s/%s", dir, ent->d_name);
        struct stat st;
        if (stat(fpath, &st) != 0) continue;
        snprintf(entries[n].name, sizeof(entries[n].name), "%s", ent->d_name);
        entries[n].mtime = st.st_mtime;
        n++;
    }
    closedir(d);

    if (n == 0) {
        fprintf(stdout, "\n  No sessions found.\n\n");
        return;
    }

    qsort(entries, (size_t)n, sizeof(SessionEntry), cmp_session_desc);

    int show = n > 10 ? 10 : n;
    fprintf(stdout, "\n%sRecent sessions:%s\n", CLR_BOLD, CLR_RESET);
    for (int i = 0; i < show; i++) {
        /* strip .jsonl to get session id */
        char sid[256];
        snprintf(sid, sizeof(sid), "%s", entries[i].name);
        char *dot = strrchr(sid, '.');
        if (dot) *dot = '\0';

        /* parse date from session id: YYYYMMDD_HHMMSS_xxx */
        char date_str[32] = "";
        if (strlen(sid) >= 15) {
            snprintf(date_str, sizeof(date_str),
                     "%.4s-%.2s-%.2s %.2s:%.2s",
                     sid, sid + 4, sid + 6, sid + 9, sid + 11);
        }

        /* count messages */
        char fpath[4096];
        snprintf(fpath, sizeof(fpath), "%s/%s", dir, entries[i].name);
        int msgs = count_lines(fpath);

        /* first user message */
        char summary[64];
        first_user_summary(fpath, summary, sizeof(summary));

        fprintf(stdout, "  %s%s%s  %s  (%d msgs)  \"%s\"\n",
                CLR_CYAN, sid, CLR_RESET,
                date_str, msgs,
                summary[0] ? summary : "...");
    }
    if (n > 10)
        fprintf(stdout, "  %s... and %d more%s\n", CLR_DIM, n - 10, CLR_RESET);
    fprintf(stdout, "\n");
}

/* ---------- find latest session ---------- */
int session_find_latest(const char *workspace, char *out_path, size_t sz)
{
    char dir[4096];
    sessions_dir(workspace, dir, sizeof(dir));

    DIR *d = opendir(dir);
    if (!d) return -1;

    char latest_name[256] = "";
    time_t latest_mtime = 0;

    struct dirent *ent;
    while ((ent = readdir(d)) != NULL) {
        size_t nlen = strlen(ent->d_name);
        if (nlen < 6 || strcmp(ent->d_name + nlen - 6, ".jsonl") != 0)
            continue;
        char fpath[4096];
        snprintf(fpath, sizeof(fpath), "%s/%s", dir, ent->d_name);
        struct stat st;
        if (stat(fpath, &st) != 0) continue;
        if (st.st_mtime > latest_mtime) {
            latest_mtime = st.st_mtime;
            snprintf(latest_name, sizeof(latest_name), "%s", ent->d_name);
        }
    }
    closedir(d);

    if (latest_name[0] == '\0') return -1;
    snprintf(out_path, sz, "%s/%s", dir, latest_name);
    return 0;
}

/* ---------- find session by id ---------- */
int session_find_by_id(const char *workspace, const char *id,
                       char *out_path, size_t sz)
{
    char dir[4096];
    sessions_dir(workspace, dir, sizeof(dir));

    /* try exact match first */
    snprintf(out_path, sz, "%s/%s.jsonl", dir, id);
    struct stat st;
    if (stat(out_path, &st) == 0) return 0;

    /* try prefix match */
    DIR *d = opendir(dir);
    if (!d) return -1;

    size_t id_len = strlen(id);
    struct dirent *ent;
    while ((ent = readdir(d)) != NULL) {
        if (strncmp(ent->d_name, id, id_len) == 0) {
            snprintf(out_path, sz, "%s/%s", dir, ent->d_name);
            closedir(d);
            return 0;
        }
    }
    closedir(d);
    return -1;
}
