#include "repl.h"
#include "util.h"
#include "todo.h"
#include "config.h"
#include "mcp.h"
#include "skill.h"
#include "session.h"
#include "cJSON.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <histedit.h>  /* libedit on macOS */

/* ---------- global agent pointer for signal handler ---------- */
static Agent *g_agent = NULL;

static void sigint_handler(int sig)
{
    (void)sig;
    if (g_agent)
        agent_interrupt(g_agent);
    (void)write(STDOUT_FILENO, "\n", 1);
}

/* ---------- libedit prompt function ---------- */
static const char *el_prompt_fn(EditLine *el)
{
    (void)el;
    return "\033[1;32myou\033[0m> ";
}

/* ---------- handle special commands ---------- */
typedef enum {
    CMD_HANDLED = 0,
    CMD_QUIT    = 1,
    CMD_UNKNOWN = -1
} CmdResult;

static CmdResult handle_command(const char *line, Agent *agent, Config *cfg)
{
    if (strcmp(line, "/quit") == 0 || strcmp(line, "/exit") == 0) {
        return CMD_QUIT;  /* signal exit */
    }

    if (strcmp(line, "/help") == 0) {
        fprintf(stdout,
            "\n%sCommands:%s\n"
            "  /help              Show this help\n"
            "  /quit              Exit c-agent\n"
            "  /clear             Clear conversation & start new session\n"
            "  /sessions          List recent sessions\n"
            "  /resume [id]       Resume a session (default: latest)\n"
            "  /todo              Show current TODO list\n"
            "  /mcp               Show MCP server status\n"
            "  /skills            Show available skills\n"
            "  /skill install <url>  Install skill (workspace by default)\n"
            "  /skill install -g <url> Install skill globally\n"
            "  /skill remove <name>  Remove a workspace skill\n"
            "  /skill remove -g <name> Remove a global skill\n"
            "  /<skill-name>      Invoke a skill\n"
            "  /context           Show context stats\n"
            "  /config            Show current configuration\n"
            "  /config set <k> <v> Set a config value\n"
            "\n",
            CLR_BOLD, CLR_RESET);
        return CMD_HANDLED;
    }

    if (strcmp(line, "/clear") == 0) {
        ctx_clear(&agent->ctx);
        session_free(&agent->session);
        session_create(&agent->session, agent->workspace);
        fprintf(stdout, "%sConversation cleared. New session started.%s\n",
                CLR_GREEN, CLR_RESET);
        return CMD_HANDLED;
    }

    if (strcmp(line, "/sessions") == 0) {
        session_list_print(agent->workspace);
        return CMD_HANDLED;
    }

    if (strcmp(line, "/resume") == 0 || strncmp(line, "/resume ", 8) == 0) {
        char path[4096];
        int found;
        if (strlen(line) > 8) {
            /* /resume <id> */
            const char *id = line + 8;
            while (*id == ' ') id++;
            found = session_find_by_id(agent->workspace, id, path, sizeof(path));
        } else {
            /* /resume — find latest */
            found = session_find_latest(agent->workspace, path, sizeof(path));
        }

        if (found != 0) {
            fprintf(stderr, "%sNo session found.%s\n", CLR_RED, CLR_RESET);
            return CMD_HANDLED;
        }

        /* clear current context (keep system prompt) */
        ctx_clear(&agent->ctx);

        /* load history into context */
        int loaded = session_load_into_ctx(path, &agent->ctx);

        /* create a new session file for continued conversation */
        session_free(&agent->session);
        session_create(&agent->session, agent->workspace);

        /* replay loaded history into the new session file for continuity */
        for (int i = 0; i < agent->ctx.n_msgs; i++) {
            Message *m = &agent->ctx.msgs[i];
            if (m->role == ROLE_SYSTEM) continue;
            if (m->role == ROLE_USER)
                session_append_user(&agent->session, m->content);
            else if (m->role == ROLE_ASSISTANT)
                session_append_assistant(&agent->session, m->content,
                                        m->reasoning_content,
                                        m->tool_calls, m->n_tool_calls);
            else if (m->role == ROLE_TOOL)
                session_append_tool(&agent->session, m->tool_call_id,
                                   m->content);
        }

        /* extract session id from path for display */
        const char *fname = strrchr(path, '/');
        fname = fname ? fname + 1 : path;

        fprintf(stdout, "%sResumed session: %s (%d messages loaded)%s\n",
                CLR_GREEN, fname, loaded, CLR_RESET);
        return CMD_HANDLED;
    }

    if (strcmp(line, "/todo") == 0) {
        char *txt = todo_format(&agent->todos);
        fprintf(stdout, "\n%sTODO List:%s\n%s\n",
                CLR_BOLD, CLR_RESET, txt);
        free(txt);
        return CMD_HANDLED;
    }

    if (strcmp(line, "/mcp") == 0) {
        fprintf(stdout, "\n%sMCP Servers:%s", CLR_BOLD, CLR_RESET);
        mcp_print_status(&agent->mcp);
        return CMD_HANDLED;
    }

    if (strcmp(line, "/context") == 0) {
        int tokens = ctx_estimate_tokens(&agent->ctx);
        int msgs   = ctx_msg_count(&agent->ctx);
        fprintf(stdout,
            "\n%sContext:%s\n"
            "  Messages: %d\n"
            "  Est. tokens: %d / %d (%.0f%%)\n\n",
            CLR_BOLD, CLR_RESET,
            msgs, tokens, agent->ctx.max_tokens,
            100.0 * tokens / agent->ctx.max_tokens);
        return CMD_HANDLED;
    }

    if (strcmp(line, "/config") == 0) {
        fprintf(stdout,
            "\n%sConfiguration:%s (file: %s)\n"
            "  api_key:            %s\n"
            "  base_url:           %s\n"
            "  model:              %s\n"
            "  reasoning_model:    %s\n"
            "  fast_model:         %s\n"
            "  max_tokens:         %d\n"
            "  temperature:        %.1f\n"
            "  max_context_tokens: %d\n"
            "  max_tool_rounds:    %d\n\n",
            CLR_BOLD, CLR_RESET, config_path(),
            cfg->api_key ? "***" : "(not set)",
            cfg->base_url,
            cfg->model,
            cfg->reasoning_model,
            cfg->fast_model,
            cfg->max_tokens,
            cfg->temperature,
            cfg->max_context_tokens,
            cfg->max_tool_rounds);
        return CMD_HANDLED;
    }

    if (strncmp(line, "/config set ", 12) == 0) {
        const char *rest = line + 12;
        /* parse "key value" */
        char key[64] = {0};
        const char *space = strchr(rest, ' ');
        if (!space) {
            fprintf(stderr, "%sUsage: /config set <key> <value>%s\n",
                    CLR_RED, CLR_RESET);
            return CMD_HANDLED;
        }
        size_t klen = (size_t)(space - rest);
        if (klen >= sizeof(key)) klen = sizeof(key) - 1;
        memcpy(key, rest, klen);
        key[klen] = '\0';
        const char *value = space + 1;

        if (config_set(cfg, key, value)) {
            config_save(cfg);
            /* also update agent's API config if relevant */
            if (strcmp(key, "api_key") == 0) {
                free(agent->api_cfg.api_key);
                agent->api_cfg.api_key = xstrdup(value);
            } else if (strcmp(key, "base_url") == 0) {
                free(agent->api_cfg.base_url);
                agent->api_cfg.base_url = xstrdup(value);
            } else if (strcmp(key, "model") == 0) {
                free(agent->api_cfg.model);
                agent->api_cfg.model = xstrdup(value);
            }
            fprintf(stdout, "%sConfig '%s' set to '%s' and saved.%s\n",
                    CLR_GREEN, key, value, CLR_RESET);
        } else {
            fprintf(stderr, "%sUnknown config key: '%s'%s\n",
                    CLR_RED, key, CLR_RESET);
            fprintf(stderr, "Valid keys: api_key, base_url, model, "
                    "reasoning_model, fast_model, "
                    "max_tokens, temperature, max_context_tokens, "
                    "max_tool_rounds\n");
        }
        return CMD_HANDLED;
    }

    /* /skills - list available skills */
    if (strcmp(line, "/skills") == 0) {
        fprintf(stdout, "\n%sSkills:%s", CLR_BOLD, CLR_RESET);
        skill_print_list(&agent->skills);
        return CMD_HANDLED;
    }

    /* /skill install [-g] <url> */
    if (strncmp(line, "/skill install ", 15) == 0) {
        const char *rest = line + 15;
        while (*rest == ' ') rest++;
        bool global = false;
        if (strncmp(rest, "-g ", 3) == 0) {
            global = true;
            rest += 3;
            while (*rest == ' ') rest++;
        }
        if (!*rest) {
            fprintf(stderr, "%sUsage: /skill install [-g] <git-url>%s\n",
                    CLR_RED, CLR_RESET);
            return CMD_HANDLED;
        }
        /* build JSON args and call install */
        cJSON *args = cJSON_CreateObject();
        cJSON_AddStringToObject(args, "url", rest);
        if (global) cJSON_AddTrueToObject(args, "global");
        char *args_str = cJSON_PrintUnformatted(args);
        char *result = tool_skill_install_exec(args_str, agent);
        fprintf(stdout, "%s\n", result);
        free(result);
        free(args_str);
        cJSON_Delete(args);
        /* reload skills */
        skill_load(&agent->skills, agent->workspace);
        return CMD_HANDLED;
    }

    /* /skill remove [-g] <name> */
    if (strncmp(line, "/skill remove ", 14) == 0) {
        const char *rest = line + 14;
        while (*rest == ' ') rest++;
        bool global = false;
        if (strncmp(rest, "-g ", 3) == 0) {
            global = true;
            rest += 3;
            while (*rest == ' ') rest++;
        }
        if (!*rest) {
            fprintf(stderr, "%sUsage: /skill remove [-g] <name>%s\n",
                    CLR_RED, CLR_RESET);
            return CMD_HANDLED;
        }
        cJSON *args = cJSON_CreateObject();
        cJSON_AddStringToObject(args, "name", rest);
        if (global) cJSON_AddTrueToObject(args, "global");
        char *args_str = cJSON_PrintUnformatted(args);
        char *result = tool_skill_remove_exec(args_str, agent);
        fprintf(stdout, "%s\n", result);
        free(result);
        free(args_str);
        cJSON_Delete(args);
        /* reload skills */
        skill_load(&agent->skills, agent->workspace);
        return CMD_HANDLED;
    }

    return CMD_UNKNOWN;
}

/* ---------- REPL main loop ---------- */
void repl_run(Agent *agent, Config *cfg)
{
    g_agent = agent;

    /* install signal handler */
    struct sigaction sa;
    sa.sa_handler = sigint_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART;
    sigaction(SIGINT, &sa, NULL);

    /* init libedit */
    EditLine *el = el_init("c-agent", stdin, stdout, stderr);
    el_set(el, EL_PROMPT, el_prompt_fn);
    el_set(el, EL_EDITOR, "emacs");

    History *hist = history_init();
    HistEvent hev;
    history(hist, &hev, H_SETSIZE, 500);
    el_set(el, EL_HIST, history, hist);

    fprintf(stdout,
        "\n"
        "%s    ██████╗       █████╗  ██████╗ ███████╗███╗   ██╗████████╗%s\n"
        "%s   ██╔════╝      ██╔══██╗██╔════╝ ██╔════╝████╗  ██║╚══██╔══╝%s\n"
        "%s   ██║     █████╗███████║██║  ███╗█████╗  ██╔██╗ ██║   ██║%s\n"
        "%s   ██║     ╚════╝██╔══██║██║   ██║██╔══╝  ██║╚██╗██║   ██║%s\n"
        "%s   ╚██████╗      ██║  ██║╚██████╔╝███████╗██║ ╚████║   ██║%s\n"
        "%s    ╚═════╝      ╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═══╝   ╚═╝%s\n"
        "\n"
        "%s   Pure C CLI Agent · v0.1.0%s\n"
        "\n"
        "   Workspace: %s%s%s\n"
        "   Model:     %s%s%s\n"
        "   Type %s/help%s for commands, %s/quit%s to exit.\n\n",
        CLR_CYAN, CLR_RESET,
        CLR_CYAN, CLR_RESET,
        CLR_BOLD "\033[36m", CLR_RESET,
        CLR_CYAN, CLR_RESET,
        CLR_CYAN, CLR_RESET,
        CLR_CYAN, CLR_RESET,
        CLR_DIM, CLR_RESET,
        CLR_BOLD, agent->workspace, CLR_RESET,
        CLR_BOLD, cfg->model, CLR_RESET,
        CLR_CYAN, CLR_RESET,
        CLR_CYAN, CLR_RESET);

    if (!cfg->api_key || !cfg->api_key[0]) {
        fprintf(stdout,
            "%sWarning: No API key configured!%s\n"
            "Set it with: /config set api_key sk-your-key-here\n"
            "Or set DEEPSEEK_API_KEY environment variable.\n\n",
            CLR_YELLOW, CLR_RESET);
    }

    while (1) {
        int count = 0;
        const char *line = el_gets(el, &count);

        if (!line || count <= 0) {
            fprintf(stdout, "\n");
            break;  /* EOF */
        }

        /* strip trailing newline */
        char *input = xstrdup(line);
        size_t len = strlen(input);
        while (len > 0 && (input[len - 1] == '\n' || input[len - 1] == '\r'))
            input[--len] = '\0';

        /* skip empty lines */
        if (len == 0) {
            free(input);
            continue;
        }

        /* add to history */
        history(hist, &hev, H_ENTER, input);

        /* check for commands */
        if (input[0] == '/') {
            CmdResult cmd_res = handle_command(input, agent, cfg);
            if (cmd_res == CMD_QUIT) {
                free(input);
                break;
            }
            if (cmd_res == CMD_HANDLED) {
                free(input);
                continue;
            }

            /* try skill invocation: /<skill-name> [extra message] */
            const char *cmd = input + 1;
            /* extract skill name (first word) */
            char skill_name[256] = {0};
            const char *space = strchr(cmd, ' ');
            size_t nlen = space ? (size_t)(space - cmd) : strlen(cmd);
            if (nlen >= sizeof(skill_name)) nlen = sizeof(skill_name) - 1;
            memcpy(skill_name, cmd, nlen);
            skill_name[nlen] = '\0';

            Skill *sk = skill_find(&agent->skills, skill_name);
            if (sk) {
                char *body = skill_read_content(sk);
                const char *extra = space ? space + 1 : "";

                StrBuf prompt;
                strbuf_init(&prompt);
                strbuf_appendf(&prompt, "<skill name=\"%s\">\n%s\n</skill>",
                               sk->name, body ? body : "");
                if (extra[0])
                    strbuf_appendf(&prompt, "\n\n%s", extra);

                fprintf(stdout, "%s[skill: %s]%s\n",
                        CLR_YELLOW, sk->name, CLR_RESET);

                char *reply = agent_process(agent, prompt.data);
                free(reply);
                strbuf_free(&prompt);
                free(body);
            } else {
                fprintf(stderr, "%sUnknown command or skill: %s%s\n",
                        CLR_RED, input, CLR_RESET);
            }

            free(input);
            continue;
        }

        /* process with agent */
        char *reply = agent_process(agent, input);
        free(reply);  /* content was already streamed to stdout */
        free(input);
    }

    history_end(hist);
    el_end(el);
    g_agent = NULL;
}
