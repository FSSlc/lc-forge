#include "api.h"
#include "tools.h"
#include "util.h"
#include <curl/curl.h>
#include <stdlib.h>
#include <string.h>

/* ---------- ApiConfig ---------- */
void api_config_init(ApiConfig *cfg)
{
    memset(cfg, 0, sizeof(*cfg));
    cfg->base_url        = xstrdup("https://api.deepseek.com");
    cfg->model           = xstrdup("deepseek-v4-flash");
    cfg->temperature     = 0.0;
    cfg->max_tokens      = 16384;
    cfg->enable_thinking = false;
}

void api_config_free(ApiConfig *cfg)
{
    free(cfg->api_key);
    free(cfg->base_url);
    free(cfg->model);
    if (cfg->curl_handle) {
        curl_easy_cleanup(cfg->curl_handle);
        cfg->curl_handle = NULL;
    }
    memset(cfg, 0, sizeof(*cfg));
}

/* ---------- ApiResponse ---------- */
void api_response_free(ApiResponse *resp)
{
    free(resp->content);
    free(resp->reasoning_content);
    for (int i = 0; i < resp->n_tool_calls; i++)
        toolcall_free(&resp->tool_calls[i]);
    free(resp->tool_calls);
    free(resp->error);
    memset(resp, 0, sizeof(*resp));
}

/* ---------- global init ---------- */
void api_global_init(void)  { curl_global_init(CURL_GLOBAL_DEFAULT); }
void api_global_cleanup(void) { curl_global_cleanup(); }

/* ---------- build request body ---------- */
static char *build_request_body(const ApiConfig *cfg, const Context *ctx,
                                ToolRegistry *tools, bool stream)
{
    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "model", cfg->model);

    cJSON *msgs = ctx_to_json(ctx);
    cJSON_AddItemToObject(root, "messages", msgs);

    if (cfg->max_tokens > 0)
        cJSON_AddNumberToObject(root, "max_tokens", cfg->max_tokens);

    /* thinking mode: temperature/top_p are ignored by the API, but
       we still send temperature for non-thinking requests */
    if (!cfg->enable_thinking)
        cJSON_AddNumberToObject(root, "temperature", cfg->temperature);

    if (stream)
        cJSON_AddBoolToObject(root, "stream", 1);

    /* enable thinking mode if requested */
    if (cfg->enable_thinking) {
        cJSON *thinking = cJSON_CreateObject();
        cJSON_AddStringToObject(thinking, "type", "enabled");
        cJSON_AddItemToObject(root, "thinking", thinking);
    }

    /* add tools if any */
    if (tools && tools->n_tools > 0) {
        cJSON *tarr = cJSON_Duplicate(tools_get_cached_json(tools), 1);
        cJSON_AddItemToObject(root, "tools", tarr);
    }

    char *body = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    return body;
}

/* ---------- curl write callback (non-streaming) ---------- */
static size_t write_cb(char *ptr, size_t size, size_t nmemb, void *ud)
{
    StrBuf *sb = (StrBuf *)ud;
    size_t n = size * nmemb;
    strbuf_append(sb, ptr, n);
    return n;
}

/* ---------- parse non-streaming response ---------- */
static ApiResponse parse_response(const char *body)
{
    ApiResponse resp;
    memset(&resp, 0, sizeof(resp));

    cJSON *root = cJSON_Parse(body);
    if (!root) {
        resp.ok    = false;
        resp.error = xstrdup("Failed to parse API response JSON");
        return resp;
    }

    /* check for error */
    cJSON *err = cJSON_GetObjectItem(root, "error");
    if (err) {
        cJSON *msg = cJSON_GetObjectItem(err, "message");
        resp.ok    = false;
        resp.error = xstrdup(msg ? msg->valuestring : "Unknown API error");
        cJSON_Delete(root);
        return resp;
    }

    resp.ok = true;

    cJSON *choices = cJSON_GetObjectItem(root, "choices");
    if (!choices || cJSON_GetArraySize(choices) == 0) {
        cJSON_Delete(root);
        return resp;
    }

    cJSON *choice = cJSON_GetArrayItem(choices, 0);
    cJSON *message = cJSON_GetObjectItem(choice, "message");
    if (!message) {
        cJSON_Delete(root);
        return resp;
    }

    /* content */
    cJSON *content = cJSON_GetObjectItem(message, "content");
    if (content && cJSON_IsString(content))
        resp.content = xstrdup(content->valuestring);

    /* reasoning_content (thinking mode) */
    cJSON *reasoning = cJSON_GetObjectItem(message, "reasoning_content");
    if (reasoning && cJSON_IsString(reasoning))
        resp.reasoning_content = xstrdup(reasoning->valuestring);

    /* tool_calls */
    cJSON *tcs = cJSON_GetObjectItem(message, "tool_calls");
    if (tcs && cJSON_IsArray(tcs)) {
        int n = cJSON_GetArraySize(tcs);
        resp.tool_calls   = xmalloc((size_t)n * sizeof(ToolCall));
        resp.n_tool_calls = n;
        for (int i = 0; i < n; i++) {
            cJSON *tc = cJSON_GetArrayItem(tcs, i);
            cJSON *id = cJSON_GetObjectItem(tc, "id");
            cJSON *fn = cJSON_GetObjectItem(tc, "function");
            cJSON *nm = fn ? cJSON_GetObjectItem(fn, "name") : NULL;
            cJSON *ag = fn ? cJSON_GetObjectItem(fn, "arguments") : NULL;
            resp.tool_calls[i].id = xstrdup(id ? id->valuestring : "");
            resp.tool_calls[i].name = xstrdup(nm ? nm->valuestring : "");
            resp.tool_calls[i].arguments = xstrdup(ag ? ag->valuestring : "{}");
        }
    }

    cJSON_Delete(root);
    return resp;
}

/* ---------- get or create curl handle ---------- */
static CURL *get_curl(ApiConfig *cfg)
{
    if (cfg->curl_handle) {
        curl_easy_reset(cfg->curl_handle);
        return cfg->curl_handle;
    }
    cfg->curl_handle = curl_easy_init();
    return cfg->curl_handle;
}

/* ---------- non-streaming API call ---------- */
ApiResponse api_chat(ApiConfig *cfg, const Context *ctx,
                     ToolRegistry *tools)
{
    ApiResponse resp;
    memset(&resp, 0, sizeof(resp));

    char *body = build_request_body(cfg, ctx, tools, false);

    StrBuf url;
    strbuf_init(&url);
    strbuf_appendf(&url, "%s/v1/chat/completions", cfg->base_url);

    StrBuf auth;
    strbuf_init(&auth);
    strbuf_appendf(&auth, "Authorization: Bearer %s", cfg->api_key);

    CURL *curl = get_curl(cfg);
    if (!curl) {
        resp.ok    = false;
        resp.error = xstrdup("Failed to init curl");
        free(body);
        strbuf_free(&url);
        strbuf_free(&auth);
        return resp;
    }

    StrBuf response;
    strbuf_init(&response);

    struct curl_slist *headers = NULL;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    headers = curl_slist_append(headers, auth.data);

    curl_easy_setopt(curl, CURLOPT_URL, url.data);
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, body);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_cb);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 120L);

    CURLcode rc = curl_easy_perform(curl);
    if (rc != CURLE_OK) {
        resp.ok    = false;
        resp.error = xstrdup(curl_easy_strerror(rc));
    } else {
        resp = parse_response(response.data);
    }

    curl_slist_free_all(headers);
    strbuf_free(&response);
    strbuf_free(&url);
    strbuf_free(&auth);
    free(body);
    return resp;
}

/* ---------- streaming support ---------- */
void stream_state_init(StreamState *st,
                       void (*on_content)(const char *, void *),
                       void (*on_reasoning)(const char *, void *),
                       void *userdata)
{
    memset(st, 0, sizeof(*st));
    strbuf_init(&st->content);
    strbuf_init(&st->reasoning_content);
    st->on_content     = on_content;
    st->on_reasoning   = on_reasoning;
    st->userdata       = userdata;
    st->ok             = true;
}

void stream_state_free(StreamState *st)
{
    strbuf_free(&st->content);
    strbuf_free(&st->reasoning_content);
    for (int i = 0; i < st->n_tool_calls; i++)
        toolcall_free(&st->tool_calls[i]);
    free(st->tool_calls);
    for (int i = 0; i < st->cap_arg_bufs; i++)
        strbuf_free(&st->arg_bufs[i]);
    free(st->arg_bufs);
    free(st->error);
}

static void ensure_tc_slot(StreamState *st, int idx)
{
    while (idx >= st->cap_tool_calls) {
        int newcap = st->cap_tool_calls ? st->cap_tool_calls * 2 : 4;
        st->tool_calls = xrealloc(st->tool_calls,
                                  (size_t)newcap * sizeof(ToolCall));
        for (int i = st->cap_tool_calls; i < newcap; i++) {
            st->tool_calls[i].id        = NULL;
            st->tool_calls[i].name      = NULL;
            st->tool_calls[i].arguments = NULL;
        }
        st->cap_tool_calls = newcap;
    }
    while (idx >= st->cap_arg_bufs) {
        int newcap = st->cap_arg_bufs ? st->cap_arg_bufs * 2 : 4;
        st->arg_bufs = xrealloc(st->arg_bufs,
                                (size_t)newcap * sizeof(StrBuf));
        for (int i = st->cap_arg_bufs; i < newcap; i++)
            strbuf_init(&st->arg_bufs[i]);
        st->cap_arg_bufs = newcap;
    }
    if (idx >= st->n_tool_calls)
        st->n_tool_calls = idx + 1;
}

static void stream_sse_cb(cJSON *chunk, void *userdata)
{
    StreamState *st = (StreamState *)userdata;

    cJSON *choices = cJSON_GetObjectItem(chunk, "choices");
    if (!choices || cJSON_GetArraySize(choices) == 0) return;

    cJSON *choice = cJSON_GetArrayItem(choices, 0);
    cJSON *delta  = cJSON_GetObjectItem(choice, "delta");
    if (!delta) return;

    /* reasoning_content delta (thinking mode) */
    cJSON *reasoning = cJSON_GetObjectItem(delta, "reasoning_content");
    if (reasoning && cJSON_IsString(reasoning) && reasoning->valuestring[0]) {
        strbuf_appends(&st->reasoning_content, reasoning->valuestring);
        if (st->on_reasoning)
            st->on_reasoning(reasoning->valuestring, st->userdata);
    }

    /* content delta */
    cJSON *content = cJSON_GetObjectItem(delta, "content");
    if (content && cJSON_IsString(content) && content->valuestring[0]) {
        strbuf_appends(&st->content, content->valuestring);
        if (st->on_content)
            st->on_content(content->valuestring, st->userdata);
    }

    /* tool_calls delta */
    cJSON *tcs = cJSON_GetObjectItem(delta, "tool_calls");
    if (tcs && cJSON_IsArray(tcs)) {
        int n = cJSON_GetArraySize(tcs);
        for (int i = 0; i < n; i++) {
            cJSON *tc = cJSON_GetArrayItem(tcs, i);
            cJSON *idx_j = cJSON_GetObjectItem(tc, "index");
            int idx = idx_j ? idx_j->valueint : i;

            ensure_tc_slot(st, idx);
            ToolCall *slot = &st->tool_calls[idx];

            cJSON *id = cJSON_GetObjectItem(tc, "id");
            if (id && cJSON_IsString(id)) {
                free(slot->id);
                slot->id = xstrdup(id->valuestring);
            }

            cJSON *fn = cJSON_GetObjectItem(tc, "function");
            if (fn) {
                cJSON *nm = cJSON_GetObjectItem(fn, "name");
                if (nm && cJSON_IsString(nm)) {
                    free(slot->name);
                    slot->name = xstrdup(nm->valuestring);
                }
                cJSON *ag = cJSON_GetObjectItem(fn, "arguments");
                if (ag && cJSON_IsString(ag)) {
                    strbuf_appends(&st->arg_bufs[idx], ag->valuestring);
                }
            }
        }
    }
}

static size_t stream_write_cb(char *ptr, size_t size, size_t nmemb,
                               void *ud)
{
    struct stream_ctx {
        SseParser   *parser;
        StreamState *state;
    } *sc = (struct stream_ctx *)ud;
    size_t n = size * nmemb;
    sse_feed(sc->parser, ptr, n);
    return n;
}

ApiResponse api_chat_stream(ApiConfig *cfg, const Context *ctx,
                            ToolRegistry *tools,
                            void (*on_content)(const char *, void *),
                            void (*on_reasoning)(const char *, void *),
                            void *userdata)
{
    ApiResponse resp;
    memset(&resp, 0, sizeof(resp));

    StreamState st;
    stream_state_init(&st, on_content, on_reasoning, userdata);

    SseParser parser;
    sse_init(&parser, stream_sse_cb, &st);

    struct {
        SseParser   *parser;
        StreamState *state;
    } sctx = { &parser, &st };

    char *body = build_request_body(cfg, ctx, tools, true);

    StrBuf url;
    strbuf_init(&url);
    strbuf_appendf(&url, "%s/v1/chat/completions", cfg->base_url);

    StrBuf auth;
    strbuf_init(&auth);
    strbuf_appendf(&auth, "Authorization: Bearer %s", cfg->api_key);

    CURL *curl = get_curl(cfg);
    if (!curl) {
        resp.ok    = false;
        resp.error = xstrdup("Failed to init curl");
        free(body);
        strbuf_free(&url);
        strbuf_free(&auth);
        sse_free(&parser);
        stream_state_free(&st);
        return resp;
    }

    struct curl_slist *headers = NULL;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    headers = curl_slist_append(headers, auth.data);

    curl_easy_setopt(curl, CURLOPT_URL, url.data);
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, body);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, stream_write_cb);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &sctx);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 300L);

    CURLcode rc = curl_easy_perform(curl);
    if (rc != CURLE_OK) {
        resp.ok    = false;
        resp.error = xstrdup(curl_easy_strerror(rc));
    } else if (!st.ok) {
        resp.ok    = false;
        resp.error = st.error ? xstrdup(st.error) : xstrdup("Stream error");
    } else {
        resp.ok = true;
        if (st.content.len > 0)
            resp.content = xstrdup(st.content.data);
        if (st.reasoning_content.len > 0)
            resp.reasoning_content = xstrdup(st.reasoning_content.data);
        if (st.n_tool_calls > 0) {
            for (int i = 0; i < st.n_tool_calls; i++) {
                if (i < st.cap_arg_bufs && st.arg_bufs[i].len > 0) {
                    free(st.tool_calls[i].arguments);
                    st.tool_calls[i].arguments = strbuf_detach(&st.arg_bufs[i]);
                }
                if (!st.tool_calls[i].arguments)
                    st.tool_calls[i].arguments = xstrdup("{}");
            }
            resp.tool_calls   = st.tool_calls;
            resp.n_tool_calls = st.n_tool_calls;
            st.tool_calls     = NULL;
            st.n_tool_calls   = 0;
        }
    }

    curl_slist_free_all(headers);
    strbuf_free(&url);
    strbuf_free(&auth);
    free(body);
    sse_free(&parser);
    stream_state_free(&st);
    return resp;
}
