#include "tools.h"
#include "util.h"
#include "cJSON.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static char *run_termux_cmd(const char *cmd)
{
    FILE *fp = popen(cmd, "r");
    if (!fp)
        return xstrdup("Error: failed to execute command");

    StrBuf sb;
    strbuf_init(&sb);
    char buf[1024];
    while (fgets(buf, sizeof(buf), fp))
        strbuf_appends(&sb, buf);
    int status = pclose(fp);

    if (sb.len == 0) {
        strbuf_appendf(&sb, "Done (exit %d)", WEXITSTATUS(status));
    }
    return strbuf_detach(&sb);
}

/* ---------- termux_notification ---------- */
static char *tool_termux_notification_exec(const char *args_json, void *userdata)
{
    (void)userdata;
    cJSON *args = cJSON_Parse(args_json);
    if (!args) return xstrdup("Error: invalid JSON");

    cJSON *title   = cJSON_GetObjectItem(args, "title");
    cJSON *content = cJSON_GetObjectItem(args, "content");
    cJSON *id_j    = cJSON_GetObjectItem(args, "id");

    StrBuf cmd;
    strbuf_init(&cmd);
    strbuf_appends(&cmd, "termux-notification");
    if (title && cJSON_IsString(title))
        strbuf_appendf(&cmd, " --title '%s'", title->valuestring);
    if (content && cJSON_IsString(content))
        strbuf_appendf(&cmd, " --content '%s'", content->valuestring);
    if (id_j && cJSON_IsNumber(id_j))
        strbuf_appendf(&cmd, " --id %d", id_j->valueint);

    char *result = run_termux_cmd(cmd.data);
    strbuf_free(&cmd);
    cJSON_Delete(args);
    return result;
}

/* ---------- termux_tts ---------- */
static char *tool_termux_tts_exec(const char *args_json, void *userdata)
{
    (void)userdata;
    cJSON *args = cJSON_Parse(args_json);
    if (!args) return xstrdup("Error: invalid JSON");

    cJSON *text = cJSON_GetObjectItem(args, "text");
    if (!text || !cJSON_IsString(text)) {
        cJSON_Delete(args);
        return xstrdup("Error: missing 'text' parameter");
    }

    StrBuf cmd;
    strbuf_init(&cmd);
    strbuf_appendf(&cmd, "echo '%s' | termux-tts-speak", text->valuestring);

    char *result = run_termux_cmd(cmd.data);
    strbuf_free(&cmd);
    cJSON_Delete(args);
    return result;
}

/* ---------- termux_clipboard_get ---------- */
static char *tool_termux_clipboard_get_exec(const char *args_json, void *userdata)
{
    (void)args_json;
    (void)userdata;
    return run_termux_cmd("termux-clipboard-get");
}

/* ---------- termux_clipboard_set ---------- */
static char *tool_termux_clipboard_set_exec(const char *args_json, void *userdata)
{
    (void)userdata;
    cJSON *args = cJSON_Parse(args_json);
    if (!args) return xstrdup("Error: invalid JSON");

    cJSON *content = cJSON_GetObjectItem(args, "content");
    if (!content || !cJSON_IsString(content)) {
        cJSON_Delete(args);
        return xstrdup("Error: missing 'content' parameter");
    }

    StrBuf cmd;
    strbuf_init(&cmd);
    strbuf_appendf(&cmd, "echo '%s' | termux-clipboard-set", content->valuestring);

    char *result = run_termux_cmd(cmd.data);
    strbuf_free(&cmd);
    cJSON_Delete(args);
    return result;
}

/* ---------- termux_volume ---------- */
static char *tool_termux_volume_exec(const char *args_json, void *userdata)
{
    (void)userdata;
    cJSON *args = cJSON_Parse(args_json);
    if (!args) return xstrdup("Error: invalid JSON");

    cJSON *stream = cJSON_GetObjectItem(args, "stream");
    cJSON *volume = cJSON_GetObjectItem(args, "volume");

    if (!stream || !cJSON_IsString(stream) || !volume || !cJSON_IsNumber(volume)) {
        cJSON_Delete(args);
        return run_termux_cmd("termux-volume");
    }

    StrBuf cmd;
    strbuf_init(&cmd);
    strbuf_appendf(&cmd, "termux-volume %s %d",
                   stream->valuestring, volume->valueint);

    char *result = run_termux_cmd(cmd.data);
    strbuf_free(&cmd);
    cJSON_Delete(args);
    return result;
}

/* ---------- termux_vibrate ---------- */
static char *tool_termux_vibrate_exec(const char *args_json, void *userdata)
{
    (void)userdata;
    cJSON *args = cJSON_Parse(args_json);
    if (!args) return xstrdup("Error: invalid JSON");

    cJSON *dur = cJSON_GetObjectItem(args, "duration_ms");
    int ms = (dur && cJSON_IsNumber(dur)) ? dur->valueint : 300;

    StrBuf cmd;
    strbuf_init(&cmd);
    strbuf_appendf(&cmd, "termux-vibrate -d %d", ms);

    char *result = run_termux_cmd(cmd.data);
    strbuf_free(&cmd);
    cJSON_Delete(args);
    return result;
}

/* ---------- termux_battery ---------- */
static char *tool_termux_battery_exec(const char *args_json, void *userdata)
{
    (void)args_json;
    (void)userdata;
    return run_termux_cmd("termux-battery-status");
}

/* ---------- termux_camera ---------- */
static char *tool_termux_camera_exec(const char *args_json, void *userdata)
{
    (void)userdata;
    cJSON *args = cJSON_Parse(args_json);
    if (!args) return xstrdup("Error: invalid JSON");

    cJSON *output = cJSON_GetObjectItem(args, "output_file");
    if (!output || !cJSON_IsString(output)) {
        cJSON_Delete(args);
        return xstrdup("Error: missing 'output_file' parameter");
    }

    cJSON *cam = cJSON_GetObjectItem(args, "camera_id");
    int cam_id = (cam && cJSON_IsNumber(cam)) ? cam->valueint : 0;

    StrBuf cmd;
    strbuf_init(&cmd);
    strbuf_appendf(&cmd, "termux-camera-photo -c %d '%s'",
                   cam_id, output->valuestring);

    char *result = run_termux_cmd(cmd.data);
    strbuf_free(&cmd);
    cJSON_Delete(args);
    return result;
}

/* ---------- termux_open_url ---------- */
static char *tool_termux_open_url_exec(const char *args_json, void *userdata)
{
    (void)userdata;
    cJSON *args = cJSON_Parse(args_json);
    if (!args) return xstrdup("Error: invalid JSON");

    cJSON *url = cJSON_GetObjectItem(args, "url");
    if (!url || !cJSON_IsString(url)) {
        cJSON_Delete(args);
        return xstrdup("Error: missing 'url' parameter");
    }

    StrBuf cmd;
    strbuf_init(&cmd);
    strbuf_appendf(&cmd, "termux-open-url '%s'", url->valuestring);

    char *result = run_termux_cmd(cmd.data);
    strbuf_free(&cmd);
    cJSON_Delete(args);
    return result;
}

/* ---------- registration ---------- */
void register_termux_tools(ToolRegistry *reg)
{
    tools_register(reg, "termux_notification",
        "Show a notification on the Android device.",
        "{\"type\":\"object\",\"properties\":{"
        "\"title\":{\"type\":\"string\",\"description\":\"Notification title\"},"
        "\"content\":{\"type\":\"string\",\"description\":\"Notification body text\"},"
        "\"id\":{\"type\":\"integer\",\"description\":\"Notification ID for updates\"}"
        "},\"required\":[\"content\"]}",
        tool_termux_notification_exec, NULL);

    tools_register(reg, "termux_tts",
        "Speak text aloud using text-to-speech.",
        "{\"type\":\"object\",\"properties\":{"
        "\"text\":{\"type\":\"string\",\"description\":\"Text to speak\"}"
        "},\"required\":[\"text\"]}",
        tool_termux_tts_exec, NULL);

    tools_register(reg, "termux_clipboard_get",
        "Get the current clipboard content.",
        "{\"type\":\"object\",\"properties\":{}}",
        tool_termux_clipboard_get_exec, NULL);

    tools_register(reg, "termux_clipboard_set",
        "Set the clipboard content.",
        "{\"type\":\"object\",\"properties\":{"
        "\"content\":{\"type\":\"string\",\"description\":\"Text to copy to clipboard\"}"
        "},\"required\":[\"content\"]}",
        tool_termux_clipboard_set_exec, NULL);

    tools_register(reg, "termux_volume",
        "Get or set device volume. Call without params to get current volumes.",
        "{\"type\":\"object\",\"properties\":{"
        "\"stream\":{\"type\":\"string\",\"description\":\"Audio stream (music, ring, alarm, notification)\"},"
        "\"volume\":{\"type\":\"integer\",\"description\":\"Volume level to set\"}"
        "}}",
        tool_termux_volume_exec, NULL);

    tools_register(reg, "termux_vibrate",
        "Vibrate the device.",
        "{\"type\":\"object\",\"properties\":{"
        "\"duration_ms\":{\"type\":\"integer\",\"description\":\"Vibration duration in milliseconds (default: 300)\"}"
        "}}",
        tool_termux_vibrate_exec, NULL);

    tools_register(reg, "termux_battery",
        "Get battery status (level, charging state, temperature).",
        "{\"type\":\"object\",\"properties\":{}}",
        tool_termux_battery_exec, NULL);

    tools_register(reg, "termux_camera",
        "Take a photo using the device camera.",
        "{\"type\":\"object\",\"properties\":{"
        "\"output_file\":{\"type\":\"string\",\"description\":\"Path to save the photo\"},"
        "\"camera_id\":{\"type\":\"integer\",\"description\":\"Camera ID (0=back, 1=front)\"}"
        "},\"required\":[\"output_file\"]}",
        tool_termux_camera_exec, NULL);

    tools_register(reg, "termux_open_url",
        "Open a URL in the default browser or app.",
        "{\"type\":\"object\",\"properties\":{"
        "\"url\":{\"type\":\"string\",\"description\":\"URL to open\"}"
        "},\"required\":[\"url\"]}",
        tool_termux_open_url_exec, NULL);
}
