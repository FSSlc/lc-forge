#include "tools.h"
#include "util.h"
#include <stdlib.h>
#include <string.h>

void tools_init(ToolRegistry *reg)
{
    memset(reg, 0, sizeof(*reg));
    reg->cache_dirty = true;
}

void tools_free(ToolRegistry *reg)
{
    for (int i = 0; i < reg->n_tools; i++) {
        free(reg->tools[i].name);
        free(reg->tools[i].description);
        cJSON_Delete(reg->tools[i].parameters);
    }
    cJSON_Delete(reg->cached_json);
    reg->cached_json = NULL;
    reg->n_tools = 0;
}

bool tools_register(ToolRegistry *reg, const char *name,
                    const char *description, const char *params_json,
                    ToolExecFn exec, void *userdata)
{
    if (reg->n_tools >= MAX_TOOLS) {
        LOG_ERROR("Tool registry full (max %d)", MAX_TOOLS);
        return false;
    }
    Tool *t = &reg->tools[reg->n_tools++];
    t->name        = xstrdup(name);
    t->description = xstrdup(description);
    t->parameters  = cJSON_Parse(params_json);
    t->exec        = exec;
    t->userdata    = userdata;
    if (!t->parameters) {
        LOG_WARN("Failed to parse params JSON for tool '%s'", name);
        t->parameters = cJSON_CreateObject();
    }
    reg->cache_dirty = true;
    return true;
}

Tool *tools_find(const ToolRegistry *reg, const char *name)
{
    for (int i = 0; i < reg->n_tools; i++) {
        if (strcmp(reg->tools[i].name, name) == 0)
            return (Tool *)&reg->tools[i];
    }
    return NULL;
}

char *tools_execute(const ToolRegistry *reg, const char *name,
                    const char *args_json)
{
    Tool *t = tools_find(reg, name);
    if (!t) {
        StrBuf sb;
        strbuf_init(&sb);
        strbuf_appendf(&sb, "Error: unknown tool '%s'", name);
        return strbuf_detach(&sb);
    }
    return t->exec(args_json, t->userdata);
}

cJSON *tools_to_json(const ToolRegistry *reg)
{
    cJSON *arr = cJSON_CreateArray();
    for (int i = 0; i < reg->n_tools; i++) {
        const Tool *t = &reg->tools[i];
        cJSON *item = cJSON_CreateObject();
        cJSON_AddStringToObject(item, "type", "function");
        cJSON *fn = cJSON_CreateObject();
        cJSON_AddStringToObject(fn, "name", t->name);
        cJSON_AddStringToObject(fn, "description", t->description);
        cJSON_AddItemToObject(fn, "parameters",
                              cJSON_Duplicate(t->parameters, 1));
        cJSON_AddItemToObject(item, "function", fn);
        cJSON_AddItemToArray(arr, item);
    }
    return arr;
}

cJSON *tools_get_cached_json(ToolRegistry *reg)
{
    if (!reg->cache_dirty && reg->cached_json)
        return reg->cached_json;
    cJSON_Delete(reg->cached_json);
    reg->cached_json = tools_to_json(reg);
    reg->cache_dirty = false;
    return reg->cached_json;
}

/* ---------- register built-in tools ---------- */
void register_builtin_tools(ToolRegistry *reg)
{
    /* 1. bash */
    tools_register(reg, "bash",
        "Execute a bash command and return stdout/stderr. "
        "Use for running commands, compiling code, git operations, etc.",
        "{"
        "  \"type\": \"object\","
        "  \"properties\": {"
        "    \"command\": {"
        "      \"type\": \"string\","
        "      \"description\": \"The bash command to execute\""
        "    },"
        "    \"timeout\": {"
        "      \"type\": \"integer\","
        "      \"description\": \"Timeout in seconds (default 30)\""
        "    }"
        "  },"
        "  \"required\": [\"command\"]"
        "}",
        tool_bash_exec, NULL);

    /* 2. read_file */
    tools_register(reg, "read_file",
        "Read the contents of a file. Returns the file content with line numbers.",
        "{"
        "  \"type\": \"object\","
        "  \"properties\": {"
        "    \"file_path\": {"
        "      \"type\": \"string\","
        "      \"description\": \"Absolute or relative path to the file\""
        "    },"
        "    \"offset\": {"
        "      \"type\": \"integer\","
        "      \"description\": \"Line number to start reading from (1-based)\""
        "    },"
        "    \"limit\": {"
        "      \"type\": \"integer\","
        "      \"description\": \"Maximum number of lines to read\""
        "    }"
        "  },"
        "  \"required\": [\"file_path\"]"
        "}",
        tool_read_exec, NULL);

    /* 3. write_file */
    tools_register(reg, "write_file",
        "Write content to a file. Creates the file and parent directories if they don't exist.",
        "{"
        "  \"type\": \"object\","
        "  \"properties\": {"
        "    \"file_path\": {"
        "      \"type\": \"string\","
        "      \"description\": \"Path to the file to write\""
        "    },"
        "    \"content\": {"
        "      \"type\": \"string\","
        "      \"description\": \"Content to write to the file\""
        "    }"
        "  },"
        "  \"required\": [\"file_path\", \"content\"]"
        "}",
        tool_write_exec, NULL);

    /* 4. grep_search */
    tools_register(reg, "grep_search",
        "Search for a pattern in files. Returns matching lines with file paths and line numbers.",
        "{"
        "  \"type\": \"object\","
        "  \"properties\": {"
        "    \"pattern\": {"
        "      \"type\": \"string\","
        "      \"description\": \"The search pattern (supports basic regex)\""
        "    },"
        "    \"path\": {"
        "      \"type\": \"string\","
        "      \"description\": \"Directory or file to search in (default: current dir)\""
        "    },"
        "    \"include\": {"
        "      \"type\": \"string\","
        "      \"description\": \"File glob pattern to include (e.g. *.c)\""
        "    }"
        "  },"
        "  \"required\": [\"pattern\"]"
        "}",
        tool_grep_exec, NULL);

    /* 5. list_files */
    tools_register(reg, "list_files",
        "List files and directories at a given path.",
        "{"
        "  \"type\": \"object\","
        "  \"properties\": {"
        "    \"path\": {"
        "      \"type\": \"string\","
        "      \"description\": \"Directory path to list (default: current dir)\""
        "    },"
        "    \"recursive\": {"
        "      \"type\": \"boolean\","
        "      \"description\": \"Whether to list recursively (default: false)\""
        "    }"
        "  }"
        "}",
        tool_list_exec, NULL);

    /* 6. edit_file */
    tools_register(reg, "edit_file",
        "Edit a file by replacing an exact string with a new string. "
        "The old_string must match exactly (including whitespace/indentation). "
        "By default, old_string must appear exactly once in the file. "
        "Use replace_all=true to replace all occurrences.",
        "{"
        "  \"type\": \"object\","
        "  \"properties\": {"
        "    \"file_path\": {"
        "      \"type\": \"string\","
        "      \"description\": \"Path to the file to edit\""
        "    },"
        "    \"old_string\": {"
        "      \"type\": \"string\","
        "      \"description\": \"The exact text to find and replace\""
        "    },"
        "    \"new_string\": {"
        "      \"type\": \"string\","
        "      \"description\": \"The replacement text\""
        "    },"
        "    \"replace_all\": {"
        "      \"type\": \"boolean\","
        "      \"description\": \"Replace all occurrences (default: false)\""
        "    }"
        "  },"
        "  \"required\": [\"file_path\", \"old_string\", \"new_string\"]"
        "}",
        tool_edit_exec, NULL);
}
