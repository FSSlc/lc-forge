#include "util.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <pwd.h>

/* ---------- memory ---------- */
void *xmalloc(size_t n)
{
    void *p = malloc(n);
    if (!p) { fprintf(stderr, "out of memory\n"); abort(); }
    return p;
}

void *xrealloc(void *p, size_t n)
{
    void *q = realloc(p, n);
    if (!q && n) { fprintf(stderr, "out of memory\n"); abort(); }
    return q;
}

char *xstrdup(const char *s)
{
    if (!s) return NULL;
    char *d = strdup(s);
    if (!d) { fprintf(stderr, "out of memory\n"); abort(); }
    return d;
}

/* ---------- StrBuf ---------- */
void strbuf_init(StrBuf *sb)
{
    sb->data = xmalloc(64);
    sb->data[0] = '\0';
    sb->len = 0;
    sb->cap = 64;
}

void strbuf_free(StrBuf *sb)
{
    free(sb->data);
    sb->data = NULL;
    sb->len = sb->cap = 0;
}

static void strbuf_grow(StrBuf *sb, size_t need)
{
    if (sb->len + need + 1 <= sb->cap) return;
    size_t newcap = sb->cap * 2;
    while (newcap < sb->len + need + 1) newcap *= 2;
    sb->data = xrealloc(sb->data, newcap);
    sb->cap = newcap;
}

void strbuf_append(StrBuf *sb, const char *s, size_t n)
{
    strbuf_grow(sb, n);
    memcpy(sb->data + sb->len, s, n);
    sb->len += n;
    sb->data[sb->len] = '\0';
}

void strbuf_appends(StrBuf *sb, const char *s)
{
    strbuf_append(sb, s, strlen(s));
}

void strbuf_appendf(StrBuf *sb, const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    va_list ap2;
    va_copy(ap2, ap);
    int n = vsnprintf(NULL, 0, fmt, ap);
    va_end(ap);
    if (n < 0) { va_end(ap2); return; }
    strbuf_grow(sb, (size_t)n);
    vsnprintf(sb->data + sb->len, (size_t)n + 1, fmt, ap2);
    va_end(ap2);
    sb->len += (size_t)n;
}

void strbuf_reset(StrBuf *sb)
{
    sb->len = 0;
    if (sb->data) sb->data[0] = '\0';
}

char *strbuf_detach(StrBuf *sb)
{
    char *s = sb->data;
    sb->data = NULL;
    sb->len = sb->cap = 0;
    return s;
}

/* ---------- logging ---------- */
static LogLevel g_log_level = LOG_INFO;

void log_set_level(LogLevel lv) { g_log_level = lv; }

void log_msg(LogLevel lv, const char *fmt, ...)
{
    if (lv < g_log_level) return;
    static const char *tags[] = { "DEBUG", "INFO", "WARN", "ERROR" };
    static const char *colors[] = { CLR_DIM, CLR_CYAN, CLR_YELLOW, CLR_RED };
    fprintf(stderr, "%s[%s]%s ", colors[lv], tags[lv], CLR_RESET);
    va_list ap;
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fprintf(stderr, "\n");
}

/* ---------- platform helpers ---------- */

const char *get_shell_path(void)
{
    static const char *cached = NULL;
    if (cached) return cached;

    /* 1. honour $SHELL */
    const char *env_shell = getenv("SHELL");
    if (env_shell && access(env_shell, X_OK) == 0) {
        cached = env_shell;
        return cached;
    }

    /* 2. try well-known locations (including Termux) */
    const char *prefix = getenv("PREFIX");  /* Termux sets this */
    static char termux_sh[256];
    if (prefix) {
        snprintf(termux_sh, sizeof(termux_sh), "%s/bin/sh", prefix);
    }

    const char *candidates[] = {
        prefix ? termux_sh : NULL,
        "/bin/sh",
        "/system/bin/sh",         /* Android fallback */
        NULL
    };
    for (int i = 0; candidates[i]; i++) {
        if (access(candidates[i], X_OK) == 0) {
            cached = candidates[i];
            return cached;
        }
    }

    cached = "sh";  /* fallback: rely on PATH */
    return cached;
}

const char *get_home_dir(void)
{
    static const char *cached = NULL;
    if (cached) return cached;

    /* 1. $HOME is set on virtually every system including Termux */
    const char *home = getenv("HOME");
    if (home && home[0]) {
        cached = home;
        return cached;
    }

    /* 2. passwd database lookup */
    struct passwd *pw = getpwuid(getuid());
    if (pw && pw->pw_dir && pw->pw_dir[0]) {
        cached = pw->pw_dir;
        return cached;
    }

    /* 3. Termux default home from $PREFIX */
    const char *prefix = getenv("PREFIX");
    if (prefix) {
        static char tbuf[256];
        snprintf(tbuf, sizeof(tbuf), "%s/home", prefix);
        if (access(tbuf, F_OK) == 0) {
            cached = tbuf;
            return cached;
        }
    }

    cached = "/tmp";
    return cached;
}

bool is_termux(void)
{
    const char *prefix = getenv("PREFIX");
    if (prefix && strstr(prefix, "com.termux"))
        return true;
    if (getenv("TERMUX_VERSION"))
        return true;
    return false;
}
