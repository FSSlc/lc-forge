#include "telegram.h"
#include "util.h"
#include "session.h"
#include "cJSON.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <curl/curl.h>
#include <inttypes.h>

/* ------------------------------------------------------------------ */
/*  Global for signal handler                                         */
/* ------------------------------------------------------------------ */
static volatile sig_atomic_t g_tg_running = 1;
static volatile sig_atomic_t g_tg_processing = 0;  /* 1 when agent_process active */
static Agent *g_tg_agent = NULL;

static void tg_sigint_handler(int sig)
{
    (void)sig;
    if (g_tg_processing && g_tg_agent) {
        /* first Ctrl+C during agent processing: just interrupt the agent */
        agent_interrupt(g_tg_agent);
        return;
    }
    /* idle or second Ctrl+C: stop the bot */
    g_tg_running = 0;
    if (g_tg_agent)
        agent_interrupt(g_tg_agent);
}

/* ------------------------------------------------------------------ */
/*  curl write callback                                               */
/* ------------------------------------------------------------------ */
static size_t curl_write_cb(void *data, size_t size, size_t nmemb,
                            void *userp)
{
    StrBuf *sb = (StrBuf *)userp;
    size_t total = size * nmemb;
    strbuf_append(sb, (const char *)data, total);
    return total;
}

/* ------------------------------------------------------------------ */
/*  curl progress callback — abort transfers on shutdown              */
/* ------------------------------------------------------------------ */
static int curl_progress_cb(void *clientp, curl_off_t dltotal,
                            curl_off_t dlnow, curl_off_t ultotal,
                            curl_off_t ulnow)
{
    (void)clientp; (void)dltotal; (void)dlnow; (void)ultotal; (void)ulnow;
    return g_tg_running ? 0 : 1;  /* non-zero aborts the transfer */
}

/* ------------------------------------------------------------------ */
/*  Telegram API helpers                                              */
/* ------------------------------------------------------------------ */

/* POST to Telegram Bot API, returns parsed JSON (caller deletes) */
static cJSON *tg_api_post(const char *bot_token, const char *method,
                          const char *json_body)
{
    char url[512];
    snprintf(url, sizeof(url),
             "https://api.telegram.org/bot%s/%s", bot_token, method);

    CURL *curl = curl_easy_init();
    if (!curl) return NULL;

    StrBuf resp;
    strbuf_init(&resp);

    struct curl_slist *headers = NULL;
    headers = curl_slist_append(headers, "Content-Type: application/json");

    curl_easy_setopt(curl, CURLOPT_URL, url);
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, json_body);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_write_cb);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &resp);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 60L);
    curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 0L);
    curl_easy_setopt(curl, CURLOPT_XFERINFOFUNCTION, curl_progress_cb);

    CURLcode res = curl_easy_perform(curl);
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);

    if (res != CURLE_OK) {
        if (res != CURLE_ABORTED_BY_CALLBACK)
            LOG_ERROR("Telegram API %s failed: %s", method, curl_easy_strerror(res));
        strbuf_free(&resp);
        return NULL;
    }

    cJSON *root = cJSON_Parse(resp.data);
    strbuf_free(&resp);
    return root;
}

/* GET from Telegram Bot API with long polling timeout */
static cJSON *tg_api_get(const char *bot_token, const char *method,
                         const char *query_params, long timeout_secs)
{
    char url[1024];
    snprintf(url, sizeof(url),
             "https://api.telegram.org/bot%s/%s?%s",
             bot_token, method, query_params);

    CURL *curl = curl_easy_init();
    if (!curl) return NULL;

    StrBuf resp;
    strbuf_init(&resp);

    curl_easy_setopt(curl, CURLOPT_URL, url);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_write_cb);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &resp);
    /* long polling: server holds connection for timeout_secs,
       give curl extra margin */
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, timeout_secs + 10);
    curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 0L);
    curl_easy_setopt(curl, CURLOPT_XFERINFOFUNCTION, curl_progress_cb);

    CURLcode res = curl_easy_perform(curl);
    curl_easy_cleanup(curl);

    if (res != CURLE_OK) {
        /* timeout during shutdown or abort is normal */
        if (g_tg_running && res != CURLE_ABORTED_BY_CALLBACK)
            LOG_ERROR("Telegram API %s failed: %s",
                      method, curl_easy_strerror(res));
        strbuf_free(&resp);
        return NULL;
    }

    cJSON *root = cJSON_Parse(resp.data);
    strbuf_free(&resp);
    return root;
}

/* ------------------------------------------------------------------ */
/*  Send message (with auto-splitting for >4000 chars)                */
/* ------------------------------------------------------------------ */
static void tg_send_message(TelegramCtx *ctx, int64_t chat_id,
                            const char *text)
{
    if (!text || !text[0]) return;

    size_t total_len = strlen(text);

    /* Telegram limit is 4096, we split at 4000 to leave margin */
    if (total_len <= 4000) {
        cJSON *body = cJSON_CreateObject();
        cJSON_AddNumberToObject(body, "chat_id", (double)chat_id);
        cJSON_AddStringToObject(body, "text", text);
        char *json = cJSON_PrintUnformatted(body);

        cJSON *resp = tg_api_post(ctx->bot_token, "sendMessage", json);
        cJSON_Delete(resp);
        free(json);
        cJSON_Delete(body);
        return;
    }

    /* split on newline boundaries */
    const char *p = text;
    while (*p) {
        size_t remaining = strlen(p);
        size_t chunk_len = remaining < 4000 ? remaining : 4000;

        /* try to split at last newline within the chunk */
        if (remaining > 4000) {
            const char *last_nl = NULL;
            for (size_t i = 0; i < chunk_len; i++) {
                if (p[i] == '\n') last_nl = p + i;
            }
            if (last_nl && (size_t)(last_nl - p) > 100)
                chunk_len = (size_t)(last_nl - p + 1);
        }

        char *chunk = xmalloc(chunk_len + 1);
        memcpy(chunk, p, chunk_len);
        chunk[chunk_len] = '\0';

        cJSON *body = cJSON_CreateObject();
        cJSON_AddNumberToObject(body, "chat_id", (double)chat_id);
        cJSON_AddStringToObject(body, "text", chunk);
        char *json = cJSON_PrintUnformatted(body);

        cJSON *resp = tg_api_post(ctx->bot_token, "sendMessage", json);
        cJSON_Delete(resp);
        free(json);
        cJSON_Delete(body);
        free(chunk);

        p += chunk_len;

        /* small delay between chunks to avoid rate limiting */
        if (*p) usleep(200000);
    }
}

/* ------------------------------------------------------------------ */
/*  getUpdates (long polling)                                         */
/* ------------------------------------------------------------------ */
static cJSON *tg_get_updates(TelegramCtx *ctx, int timeout)
{
    char params[256];
    snprintf(params, sizeof(params),
             "timeout=%d&offset=%d&allowed_updates=[\"message\"]",
             timeout, ctx->last_update_id + 1);

    return tg_api_get(ctx->bot_token, "getUpdates", params, (long)timeout);
}

/* ------------------------------------------------------------------ */
/*  Wait for user reply (for dangerous command confirmation)          */
/* ------------------------------------------------------------------ */
static char *tg_wait_reply(TelegramCtx *ctx, int timeout_secs)
{
    int elapsed = 0;
    int poll_interval = 2;  /* poll every 2 seconds */

    while (elapsed < timeout_secs && g_tg_running) {
        cJSON *resp = tg_get_updates(ctx, poll_interval);
        if (!resp) {
            elapsed += poll_interval;
            continue;
        }

        cJSON *ok = cJSON_GetObjectItem(resp, "ok");
        cJSON *result = cJSON_GetObjectItem(resp, "result");

        if (ok && cJSON_IsTrue(ok) && result && cJSON_IsArray(result)) {
            int n = cJSON_GetArraySize(result);
            for (int i = 0; i < n; i++) {
                cJSON *update = cJSON_GetArrayItem(result, i);
                cJSON *uid = cJSON_GetObjectItem(update, "update_id");
                if (uid && cJSON_IsNumber(uid))
                    ctx->last_update_id = uid->valueint;

                cJSON *msg = cJSON_GetObjectItem(update, "message");
                if (!msg) continue;

                cJSON *chat = cJSON_GetObjectItem(msg, "chat");
                cJSON *text = cJSON_GetObjectItem(msg, "text");

                if (chat && text && cJSON_IsString(text)) {
                    cJSON *cid = cJSON_GetObjectItem(chat, "id");
                    if (cid && (int64_t)cid->valuedouble == ctx->chat_id) {
                        char *reply = xstrdup(text->valuestring);
                        cJSON_Delete(resp);
                        return reply;
                    }
                }
            }
        }

        cJSON_Delete(resp);
        elapsed += poll_interval;
    }

    return NULL;  /* timeout */
}

/* ------------------------------------------------------------------ */
/*  Dangerous command detection                                       */
/* ------------------------------------------------------------------ */
static bool is_dangerous_command(const char *cmd)
{
    /* patterns that indicate potentially dangerous operations */
    static const char *patterns[] = {
        "rm ",  "rm\t", "rmdir",
        "sudo ",
        "kill -9", "kill -KILL", "killall",
        "mkfs",
        "dd ",
        "chmod 777", "chmod -R",
        "> /dev/", ">/dev/",
        "reboot", "shutdown", "halt", "poweroff",
        "--force", "-rf", "-fr",
        "mv /", "cp /dev/",
        ":(){", "fork bomb",
        "wget ", "curl ",  /* downloading & executing */
        NULL
    };

    for (int i = 0; patterns[i]; i++) {
        if (strstr(cmd, patterns[i]))
            return true;
    }

    /* special check: rm at start of line */
    if (cmd[0] == 'r' && cmd[1] == 'm' &&
        (cmd[2] == '\0' || cmd[2] == ' ' || cmd[2] == '\t'))
        return true;

    return false;
}

/* ------------------------------------------------------------------ */
/*  Bash wrapper with dangerous command confirmation                  */
/* ------------------------------------------------------------------ */
static char *tg_bash_wrapper(const char *args_json, void *userdata)
{
    TelegramCtx *ctx = (TelegramCtx *)userdata;

    /* parse command from args */
    cJSON *args = cJSON_Parse(args_json);
    if (!args)
        return ctx->orig_bash_exec(args_json, ctx->orig_bash_userdata);

    cJSON *cmd_j = cJSON_GetObjectItem(args, "command");
    const char *cmd = (cmd_j && cJSON_IsString(cmd_j)) ?
                       cmd_j->valuestring : NULL;

    if (!cmd || !is_dangerous_command(cmd)) {
        cJSON_Delete(args);
        /* safe command: execute directly */
        return ctx->orig_bash_exec(args_json, ctx->orig_bash_userdata);
    }

    /* dangerous command: ask for confirmation via Telegram */
    StrBuf prompt;
    strbuf_init(&prompt);
    strbuf_appendf(&prompt,
        "\xe2\x9a\xa0\xef\xb8\x8f Dangerous command detected:\n"
        "`%s`\n\n"
        "Reply 'y' to confirm, anything else to cancel (60s timeout).",
        cmd);

    tg_send_message(ctx, ctx->chat_id, prompt.data);
    strbuf_free(&prompt);

    char *reply = tg_wait_reply(ctx, 60);
    if (reply && (reply[0] == 'y' || reply[0] == 'Y')) {
        free(reply);
        cJSON_Delete(args);
        return ctx->orig_bash_exec(args_json, ctx->orig_bash_userdata);
    }

    free(reply);
    cJSON_Delete(args);
    return xstrdup("Command cancelled by user.");
}

/* ------------------------------------------------------------------ */
/*  Handle Telegram commands                                          */
/* ------------------------------------------------------------------ */
static bool handle_tg_command(TelegramCtx *ctx, const char *text,
                              int64_t chat_id)
{
    if (strcmp(text, "/help") == 0 || strcmp(text, "/start") == 0) {
        tg_send_message(ctx, chat_id,
            "c-agent Telegram Bot\n\n"
            "Commands:\n"
            "  /help     - Show this help\n"
            "  /sessions - List recent sessions\n"
            "  /resume [id] - Resume a session\n"
            "  /clear    - Clear conversation & new session\n"
            "  /status   - Show model, workspace, context\n\n"
            "Send any text to chat with the agent.\n"
            "Dangerous bash commands will ask for confirmation.");
        return true;
    }

    if (strcmp(text, "/sessions") == 0) {
        /* capture session list */
        StrBuf sb;
        strbuf_init(&sb);
        strbuf_appends(&sb, "Recent sessions:\n\n");

        /* use session_list_print logic - we need to capture its output */
        /* For now, build it manually by scanning the workspace */
        char pattern[4096];
        snprintf(pattern, sizeof(pattern), "%s/.c-agent/sessions",
                 ctx->agent->workspace);

        /* list directory */
        char cmd[4200];
        snprintf(cmd, sizeof(cmd),
                 "ls -1t '%s'/*.jsonl 2>/dev/null | head -10", pattern);

        FILE *fp = popen(cmd, "r");
        if (fp) {
            char line[512];
            int count = 0;
            while (fgets(line, sizeof(line), fp)) {
                /* strip newline */
                size_t len = strlen(line);
                if (len > 0 && line[len-1] == '\n') line[len-1] = '\0';

                /* extract filename */
                const char *fname = strrchr(line, '/');
                fname = fname ? fname + 1 : line;

                strbuf_appendf(&sb, "  %d. %s\n", ++count, fname);
            }
            pclose(fp);
            if (count == 0)
                strbuf_appends(&sb, "  (no sessions found)");
        } else {
            strbuf_appends(&sb, "  (cannot read sessions directory)");
        }

        tg_send_message(ctx, chat_id, sb.data);
        strbuf_free(&sb);
        return true;
    }

    if (strcmp(text, "/resume") == 0 ||
        strncmp(text, "/resume ", 8) == 0) {
        char path[4096];
        int found;

        if (strlen(text) > 8) {
            const char *id = text + 8;
            while (*id == ' ') id++;
            found = session_find_by_id(ctx->agent->workspace, id,
                                       path, sizeof(path));
        } else {
            found = session_find_latest(ctx->agent->workspace,
                                        path, sizeof(path));
        }

        if (found != 0) {
            tg_send_message(ctx, chat_id, "No session found.");
            return true;
        }

        ctx_clear(&ctx->agent->ctx);
        int loaded = session_load_into_ctx(path, &ctx->agent->ctx);

        session_free(&ctx->agent->session);
        session_create(&ctx->agent->session, ctx->agent->workspace);

        /* replay history into new session */
        for (int i = 0; i < ctx->agent->ctx.n_msgs; i++) {
            Message *m = &ctx->agent->ctx.msgs[i];
            if (m->role == ROLE_SYSTEM) continue;
            if (m->role == ROLE_USER)
                session_append_user(&ctx->agent->session, m->content);
            else if (m->role == ROLE_ASSISTANT)
                session_append_assistant(&ctx->agent->session, m->content,
                                        m->reasoning_content,
                                        m->tool_calls, m->n_tool_calls);
            else if (m->role == ROLE_TOOL)
                session_append_tool(&ctx->agent->session, m->tool_call_id,
                                   m->content);
        }

        const char *fname = strrchr(path, '/');
        fname = fname ? fname + 1 : path;

        StrBuf sb;
        strbuf_init(&sb);
        strbuf_appendf(&sb, "Resumed session: %s (%d messages loaded)",
                        fname, loaded);
        tg_send_message(ctx, chat_id, sb.data);
        strbuf_free(&sb);
        return true;
    }

    if (strcmp(text, "/clear") == 0) {
        ctx_clear(&ctx->agent->ctx);
        session_free(&ctx->agent->session);
        session_create(&ctx->agent->session, ctx->agent->workspace);
        tg_send_message(ctx, chat_id,
                        "Conversation cleared. New session started.");
        return true;
    }

    if (strcmp(text, "/status") == 0) {
        int tokens = ctx_estimate_tokens(&ctx->agent->ctx);
        int msgs   = ctx_msg_count(&ctx->agent->ctx);

        StrBuf sb;
        strbuf_init(&sb);
        strbuf_appendf(&sb,
            "c-agent status:\n\n"
            "  Model:     %s\n"
            "  Workspace: %s\n"
            "  Messages:  %d\n"
            "  Tokens:    %d / %d (%.0f%%)\n",
            ctx->config->model,
            ctx->agent->workspace,
            msgs, tokens, ctx->agent->ctx.max_tokens,
            ctx->agent->ctx.max_tokens > 0
                ? 100.0 * tokens / ctx->agent->ctx.max_tokens
                : 0.0);
        tg_send_message(ctx, chat_id, sb.data);
        strbuf_free(&sb);
        return true;
    }

    return false;
}

/* ------------------------------------------------------------------ */
/*  Main Telegram bot loop                                            */
/* ------------------------------------------------------------------ */
void telegram_run(Agent *agent, Config *cfg)
{
    if (!cfg->telegram_bot_token || !cfg->telegram_bot_token[0]) {
        fprintf(stderr,
            "Error: no Telegram bot token configured.\n"
            "Set TELEGRAM_BOT_TOKEN environment variable or\n"
            "use: /config set telegram_bot_token YOUR_TOKEN\n");
        return;
    }

    if (!cfg->api_key || !cfg->api_key[0]) {
        fprintf(stderr,
            "Error: no API key configured.\n"
            "Set DEEPSEEK_API_KEY or use /config set api_key.\n");
        return;
    }

    /* Initialize context */
    TelegramCtx ctx;
    memset(&ctx, 0, sizeof(ctx));
    ctx.bot_token      = cfg->telegram_bot_token;
    ctx.chat_id        = 0;
    ctx.last_update_id = 0;
    ctx.agent          = agent;
    ctx.config         = cfg;

    /* Replace bash tool exec with confirmation wrapper */
    Tool *bash = tools_find(&agent->tools, "bash");
    if (bash) {
        ctx.orig_bash_exec     = bash->exec;
        ctx.orig_bash_userdata = bash->userdata;
        bash->exec     = tg_bash_wrapper;
        bash->userdata = &ctx;
    }

    /* Install signal handler */
    g_tg_agent = agent;
    struct sigaction sa;
    sa.sa_handler = tg_sigint_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);

    fprintf(stdout,
        "Telegram bot started. Waiting for messages...\n"
        "Press Ctrl+C to interrupt agent, press again to stop bot.\n\n");

    /* Main polling loop */
    while (g_tg_running) {
        cJSON *resp = tg_get_updates(&ctx, 30);
        if (!resp) {
            if (g_tg_running)
                usleep(1000000);  /* 1s backoff on error */
            continue;
        }

        cJSON *ok = cJSON_GetObjectItem(resp, "ok");
        cJSON *result = cJSON_GetObjectItem(resp, "result");

        if (!ok || !cJSON_IsTrue(ok) || !result || !cJSON_IsArray(result)) {
            cJSON *desc = cJSON_GetObjectItem(resp, "description");
            LOG_ERROR("Telegram getUpdates error: %s",
                      desc && cJSON_IsString(desc) ?
                      desc->valuestring : "unknown");
            cJSON_Delete(resp);
            usleep(5000000);  /* 5s backoff on API error */
            continue;
        }

        int n = cJSON_GetArraySize(result);
        for (int i = 0; i < n && g_tg_running; i++) {
            cJSON *update = cJSON_GetArrayItem(result, i);

            /* update offset */
            cJSON *uid = cJSON_GetObjectItem(update, "update_id");
            if (uid && cJSON_IsNumber(uid))
                ctx.last_update_id = uid->valueint;

            /* extract message */
            cJSON *msg = cJSON_GetObjectItem(update, "message");
            if (!msg) continue;

            cJSON *chat = cJSON_GetObjectItem(msg, "chat");
            cJSON *text = cJSON_GetObjectItem(msg, "text");
            if (!chat || !text || !cJSON_IsString(text)) continue;

            cJSON *cid = cJSON_GetObjectItem(chat, "id");
            if (!cid) continue;
            int64_t chat_id = (int64_t)cid->valuedouble;

            /* update current chat_id */
            ctx.chat_id = chat_id;

            const char *msg_text = text->valuestring;
            LOG_INFO("Telegram [%" PRId64 "]: %s", chat_id, msg_text);

            /* handle telegram commands */
            if (msg_text[0] == '/') {
                if (handle_tg_command(&ctx, msg_text, chat_id))
                    continue;
                /* unknown command - ignore */
                continue;
            }

            /* process with agent */
            tg_send_message(&ctx, chat_id, "Thinking...");

            agent->interrupted = false;
            g_tg_processing = 1;
            char *reply = agent_process(agent, msg_text);
            g_tg_processing = 0;

            if (agent->interrupted) {
                tg_send_message(&ctx, chat_id,
                                "[interrupted by Ctrl+C]");
                agent->interrupted = false;
            } else if (reply && reply[0]) {
                tg_send_message(&ctx, chat_id, reply);
            } else {
                tg_send_message(&ctx, chat_id,
                                "(no response from agent)");
            }
            free(reply);
        }

        cJSON_Delete(resp);
    }

    /* Restore original bash tool */
    if (bash) {
        bash->exec     = ctx.orig_bash_exec;
        bash->userdata = ctx.orig_bash_userdata;
    }

    g_tg_agent = NULL;
    fprintf(stdout, "\nTelegram bot stopped.\n");
}
