#include "tools.h"
#include "util.h"
#include "cJSON.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>

static void list_recursive(const char *path, StrBuf *result,
                           int depth, int *count)
{
    if (depth > 10 || *count > 1000) return;

    DIR *dir = opendir(path);
    if (!dir) return;

    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        if (strcmp(entry->d_name, ".") == 0 ||
            strcmp(entry->d_name, "..") == 0)
            continue;
        /* skip hidden files and common noise */
        if (entry->d_name[0] == '.') continue;
        if (strcmp(entry->d_name, "node_modules") == 0) continue;
        if (strcmp(entry->d_name, "__pycache__") == 0) continue;

        StrBuf fullpath;
        strbuf_init(&fullpath);
        strbuf_appendf(&fullpath, "%s/%s", path, entry->d_name);

        struct stat st;
        if (stat(fullpath.data, &st) == 0) {
            if (S_ISDIR(st.st_mode)) {
                strbuf_appendf(result, "%s/\n", fullpath.data);
                (*count)++;
                list_recursive(fullpath.data, result, depth + 1, count);
            } else {
                strbuf_appendf(result, "%s\n", fullpath.data);
                (*count)++;
            }
        }
        strbuf_free(&fullpath);
    }
    closedir(dir);
}

char *tool_list_exec(const char *args_json, void *userdata)
{
    (void)userdata;
    cJSON *args = cJSON_Parse(args_json);

    const char *path = ".";
    bool recursive = false;

    if (args) {
        cJSON *path_j = cJSON_GetObjectItem(args, "path");
        if (path_j && cJSON_IsString(path_j))
            path = path_j->valuestring;

        cJSON *rec_j = cJSON_GetObjectItem(args, "recursive");
        if (rec_j && cJSON_IsBool(rec_j))
            recursive = cJSON_IsTrue(rec_j);
    }

    StrBuf result;
    strbuf_init(&result);

    if (recursive) {
        int count = 0;
        list_recursive(path, &result, 0, &count);
        if (count == 0)
            strbuf_appends(&result, "(empty directory)");
        else
            strbuf_appendf(&result, "\n(%d entries)", count);
    } else {
        DIR *dir = opendir(path);
        if (!dir) {
            strbuf_appendf(&result, "Error: cannot open directory '%s'", path);
            cJSON_Delete(args);
            return strbuf_detach(&result);
        }
        struct dirent *entry;
        int count = 0;
        while ((entry = readdir(dir)) != NULL) {
            if (strcmp(entry->d_name, ".") == 0 ||
                strcmp(entry->d_name, "..") == 0)
                continue;

            StrBuf fullpath;
            strbuf_init(&fullpath);
            strbuf_appendf(&fullpath, "%s/%s", path, entry->d_name);

            struct stat st;
            if (stat(fullpath.data, &st) == 0 && S_ISDIR(st.st_mode))
                strbuf_appendf(&result, "%s/\n", entry->d_name);
            else
                strbuf_appendf(&result, "%s\n", entry->d_name);
            strbuf_free(&fullpath);
            count++;
        }
        closedir(dir);
        if (count == 0)
            strbuf_appends(&result, "(empty directory)");
    }

    cJSON_Delete(args);
    return strbuf_detach(&result);
}
