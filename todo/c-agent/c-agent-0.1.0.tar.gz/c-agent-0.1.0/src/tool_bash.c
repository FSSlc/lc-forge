#include "tools.h"
#include "util.h"
#include "cJSON.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>

char *tool_bash_exec(const char *args_json, void *userdata)
{
    (void)userdata;
    cJSON *args = cJSON_Parse(args_json);
    if (!args) return xstrdup("Error: invalid JSON arguments");

    cJSON *cmd_j = cJSON_GetObjectItem(args, "command");
    if (!cmd_j || !cJSON_IsString(cmd_j)) {
        cJSON_Delete(args);
        return xstrdup("Error: missing 'command' parameter");
    }

    int timeout = 30;
    cJSON *to_j = cJSON_GetObjectItem(args, "timeout");
    if (to_j && cJSON_IsNumber(to_j))
        timeout = to_j->valueint;
    if (timeout <= 0) timeout = 30;
    if (timeout > 300) timeout = 300;

    const char *cmd = cmd_j->valuestring;

    /* create pipe for capturing output */
    int pipefd[2];
    if (pipe(pipefd) < 0) {
        cJSON_Delete(args);
        return xstrdup("Error: pipe() failed");
    }

    pid_t pid = fork();
    if (pid < 0) {
        close(pipefd[0]);
        close(pipefd[1]);
        cJSON_Delete(args);
        return xstrdup("Error: fork() failed");
    }

    if (pid == 0) {
        /* child */
        close(pipefd[0]);
        dup2(pipefd[1], STDOUT_FILENO);
        dup2(pipefd[1], STDERR_FILENO);
        close(pipefd[1]);
        const char *sh = get_shell_path();
        execl(sh, "sh", "-c", cmd, (char *)NULL);
        _exit(127);
    }

    /* parent */
    close(pipefd[1]);

    StrBuf output;
    strbuf_init(&output);

    /* read output with timeout awareness */
    char buf[4096];
    ssize_t n;
    while ((n = read(pipefd[0], buf, sizeof(buf))) > 0) {
        strbuf_append(&output, buf, (size_t)n);
        /* cap output to 100KB */
        if (output.len > 100 * 1024) {
            strbuf_appends(&output, "\n...(output truncated)...");
            break;
        }
    }
    close(pipefd[0]);

    /* wait for child with timeout */
    int status = 0;
    int elapsed = 0;
    int timeout_ticks = timeout * 10; /* convert seconds to 100ms ticks */
    while (elapsed < timeout_ticks) {
        pid_t w = waitpid(pid, &status, WNOHANG);
        if (w == pid) break;
        if (w < 0) break;
        usleep(100000); /* 100ms */
        elapsed++;
        if (elapsed >= timeout_ticks) {
            kill(pid, SIGKILL);
            waitpid(pid, &status, 0);
            strbuf_appendf(&output, "\n(Process killed: timeout after %ds)", timeout);
            break;
        }
    }

    int exit_code = WIFEXITED(status) ? WEXITSTATUS(status) : -1;

    StrBuf result;
    strbuf_init(&result);
    strbuf_appendf(&result, "Exit code: %d\n", exit_code);
    if (output.len > 0)
        strbuf_appendf(&result, "%s", output.data);
    else
        strbuf_appends(&result, "(no output)");

    strbuf_free(&output);
    cJSON_Delete(args);
    return strbuf_detach(&result);
}
