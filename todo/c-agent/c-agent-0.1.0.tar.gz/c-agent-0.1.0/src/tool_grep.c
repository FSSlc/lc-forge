#include "tools.h"
#include "util.h"
#include "cJSON.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *tool_grep_exec(const char *args_json, void *userdata)
{
    (void)userdata;
    cJSON *args = cJSON_Parse(args_json);
    if (!args) return xstrdup("Error: invalid JSON arguments");

    cJSON *pat_j = cJSON_GetObjectItem(args, "pattern");
    if (!pat_j || !cJSON_IsString(pat_j)) {
        cJSON_Delete(args);
        return xstrdup("Error: missing 'pattern' parameter");
    }

    const char *path = ".";
    cJSON *path_j = cJSON_GetObjectItem(args, "path");
    if (path_j && cJSON_IsString(path_j))
        path = path_j->valuestring;

    const char *include = NULL;
    cJSON *inc_j = cJSON_GetObjectItem(args, "include");
    if (inc_j && cJSON_IsString(inc_j))
        include = inc_j->valuestring;

    /* build grep command */
    StrBuf cmd;
    strbuf_init(&cmd);
    strbuf_appends(&cmd, "grep -rn --color=never");
    if (include) {
        strbuf_appends(&cmd, " --include='");
        strbuf_appends(&cmd, include);
        strbuf_appends(&cmd, "'");
    }
    strbuf_appends(&cmd, " -- '");
    /* escape single quotes in pattern */
    for (const char *p = pat_j->valuestring; *p; p++) {
        if (*p == '\'')
            strbuf_appends(&cmd, "'\\''");
        else
            strbuf_append(&cmd, p, 1);
    }
    strbuf_appends(&cmd, "' '");
    /* escape single quotes in path */
    for (const char *p = path; *p; p++) {
        if (*p == '\'')
            strbuf_appends(&cmd, "'\\''");
        else
            strbuf_append(&cmd, p, 1);
    }
    strbuf_appends(&cmd, "' 2>&1 | head -200");

    FILE *fp = popen(cmd.data, "r");
    if (!fp) {
        strbuf_free(&cmd);
        cJSON_Delete(args);
        return xstrdup("Error: failed to run grep");
    }

    StrBuf result;
    strbuf_init(&result);
    char line[4096];
    int count = 0;
    while (fgets(line, sizeof(line), fp)) {
        strbuf_appends(&result, line);
        count++;
    }
    pclose(fp);

    if (count == 0)
        strbuf_appends(&result, "No matches found.");
    else
        strbuf_appendf(&result, "\n(%d matches shown)", count);

    strbuf_free(&cmd);
    cJSON_Delete(args);
    return strbuf_detach(&result);
}
