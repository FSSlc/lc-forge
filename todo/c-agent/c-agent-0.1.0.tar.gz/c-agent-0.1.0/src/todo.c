#include "todo.h"
#include "util.h"
#include "cJSON.h"
#include <stdlib.h>
#include <string.h>

void todo_init(TodoList *tl)
{
    tl->items    = NULL;
    tl->n_items  = 0;
    tl->cap_items = 0;
    tl->next_id  = 1;
}

void todo_free(TodoList *tl)
{
    for (int i = 0; i < tl->n_items; i++) {
        free(tl->items[i].subject);
        free(tl->items[i].description);
    }
    free(tl->items);
    tl->items   = NULL;
    tl->n_items = tl->cap_items = 0;
}

int todo_create(TodoList *tl, const char *subject, const char *desc)
{
    if (tl->n_items >= tl->cap_items) {
        tl->cap_items = tl->cap_items ? tl->cap_items * 2 : 8;
        tl->items = xrealloc(tl->items,
                             (size_t)tl->cap_items * sizeof(TodoItem));
    }
    TodoItem *it = &tl->items[tl->n_items++];
    it->id          = tl->next_id++;
    it->subject     = xstrdup(subject);
    it->description = desc ? xstrdup(desc) : NULL;
    it->status      = TODO_PENDING;
    return it->id;
}

bool todo_update(TodoList *tl, int id, TodoStatus status)
{
    for (int i = 0; i < tl->n_items; i++) {
        if (tl->items[i].id == id) {
            tl->items[i].status = status;
            return true;
        }
    }
    return false;
}

char *todo_status_str(TodoStatus s)
{
    switch (s) {
    case TODO_PENDING:     return "pending";
    case TODO_IN_PROGRESS: return "in_progress";
    case TODO_COMPLETED:   return "completed";
    case TODO_FAILED:      return "failed";
    }
    return "unknown";
}

char *todo_format(const TodoList *tl)
{
    StrBuf sb;
    strbuf_init(&sb);

    if (tl->n_items == 0) {
        strbuf_appends(&sb, "(no TODOs)");
        return strbuf_detach(&sb);
    }

    for (int i = 0; i < tl->n_items; i++) {
        const TodoItem *it = &tl->items[i];
        const char *icon;
        switch (it->status) {
        case TODO_PENDING:     icon = "[ ]"; break;
        case TODO_IN_PROGRESS: icon = "[~]"; break;
        case TODO_COMPLETED:   icon = "[x]"; break;
        case TODO_FAILED:      icon = "[!]"; break;
        default:               icon = "[?]"; break;
        }
        strbuf_appendf(&sb, "  %s #%d: %s", icon, it->id, it->subject);
        if (it->description)
            strbuf_appendf(&sb, " - %s", it->description);
        strbuf_appends(&sb, "\n");
    }
    return strbuf_detach(&sb);
}

/* Parse <todo_create> and <todo_update> tags from LLM output */
void todo_parse_tags(TodoList *tl, const char *text)
{
    if (!text) return;

    /* parse <todo_create>[...]</todo_create> */
    const char *p = text;
    while ((p = strstr(p, "<todo_create>")) != NULL) {
        p += strlen("<todo_create>");
        const char *end = strstr(p, "</todo_create>");
        if (!end) break;

        /* extract JSON between tags */
        size_t len = (size_t)(end - p);
        char *json_str = xmalloc(len + 1);
        memcpy(json_str, p, len);
        json_str[len] = '\0';

        cJSON *arr = cJSON_Parse(json_str);
        if (arr && cJSON_IsArray(arr)) {
            int n = cJSON_GetArraySize(arr);
            for (int i = 0; i < n; i++) {
                cJSON *item = cJSON_GetArrayItem(arr, i);
                cJSON *subj = cJSON_GetObjectItem(item, "subject");
                cJSON *desc = cJSON_GetObjectItem(item, "description");
                if (subj && cJSON_IsString(subj)) {
                    int id = todo_create(tl,
                        subj->valuestring,
                        (desc && cJSON_IsString(desc)) ?
                            desc->valuestring : NULL);
                    LOG_INFO("TODO #%d created: %s", id, subj->valuestring);
                }
            }
        }
        cJSON_Delete(arr);
        free(json_str);
        p = end;
    }

    /* parse <todo_update>{...}</todo_update> */
    p = text;
    while ((p = strstr(p, "<todo_update>")) != NULL) {
        p += strlen("<todo_update>");
        const char *end = strstr(p, "</todo_update>");
        if (!end) break;

        size_t len = (size_t)(end - p);
        char *json_str = xmalloc(len + 1);
        memcpy(json_str, p, len);
        json_str[len] = '\0';

        cJSON *obj = cJSON_Parse(json_str);
        if (obj) {
            cJSON *id_j = cJSON_GetObjectItem(obj, "id");
            cJSON *st_j = cJSON_GetObjectItem(obj, "status");
            if (id_j && cJSON_IsNumber(id_j) &&
                st_j && cJSON_IsString(st_j)) {
                TodoStatus st = TODO_PENDING;
                if (strcmp(st_j->valuestring, "in_progress") == 0)
                    st = TODO_IN_PROGRESS;
                else if (strcmp(st_j->valuestring, "completed") == 0)
                    st = TODO_COMPLETED;
                else if (strcmp(st_j->valuestring, "failed") == 0)
                    st = TODO_FAILED;
                if (todo_update(tl, id_j->valueint, st))
                    LOG_INFO("TODO #%d → %s", id_j->valueint,
                             st_j->valuestring);
            }
        }
        cJSON_Delete(obj);
        free(json_str);
        p = end;
    }
}
