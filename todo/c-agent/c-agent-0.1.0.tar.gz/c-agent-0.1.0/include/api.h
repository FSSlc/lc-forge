#ifndef API_H
#define API_H

#include "context.h"
#include "sse.h"
#include "util.h"
#include "cJSON.h"
#include <stdbool.h>

#include <curl/curl.h>

/* Forward declarations */
typedef struct ToolRegistry ToolRegistry;

/* ---------- API configuration ---------- */
typedef struct {
    char *api_key;
    char *base_url;      /* default: https://api.deepseek.com */
    char *model;         /* default: deepseek-chat */
    int   max_tokens;    /* max response tokens, 0 = omit */
    double temperature;
    bool  enable_thinking; /* enable thinking mode (CoT reasoning) */
    CURL *curl_handle;   /* reusable curl handle for connection pooling */
} ApiConfig;

void api_config_init(ApiConfig *cfg);
void api_config_free(ApiConfig *cfg);

/* ---------- API response ---------- */
typedef struct {
    char     *content;          /* assistant text (may be NULL) */
    char     *reasoning_content; /* thinking CoT (may be NULL) */
    ToolCall *tool_calls;
    int       n_tool_calls;
    bool      ok;
    char     *error;            /* error message on failure */
} ApiResponse;

void api_response_free(ApiResponse *resp);

/* ---------- API calls ---------- */

/* Non-streaming: returns full response */
ApiResponse api_chat(ApiConfig *cfg, const Context *ctx,
                     ToolRegistry *tools);

/* Streaming call with callback per SSE chunk */
typedef struct {
    /* accumulated content and tool_calls */
    StrBuf   content;
    StrBuf   reasoning_content;  /* thinking CoT */
    ToolCall *tool_calls;
    int       n_tool_calls;
    int       cap_tool_calls;
    StrBuf   *arg_bufs;          /* parallel StrBufs for efficient argument accumulation */
    int       cap_arg_bufs;
    /* callbacks for content deltas (real-time print) */
    void    (*on_content)(const char *delta, void *userdata);
    void    (*on_reasoning)(const char *delta, void *userdata);
    void     *userdata;
    bool      ok;
    char     *error;
} StreamState;

void stream_state_init(StreamState *st,
                       void (*on_content)(const char *, void *),
                       void (*on_reasoning)(const char *, void *),
                       void *userdata);
void stream_state_free(StreamState *st);

ApiResponse api_chat_stream(ApiConfig *cfg, const Context *ctx,
                            ToolRegistry *tools,
                            void (*on_content)(const char *, void *),
                            void (*on_reasoning)(const char *, void *),
                            void *userdata);

/* Global init/cleanup (call once) */
void api_global_init(void);
void api_global_cleanup(void);

#endif /* API_H */
