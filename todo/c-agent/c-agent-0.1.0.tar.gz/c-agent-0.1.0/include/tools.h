#ifndef TOOLS_H
#define TOOLS_H

#include "cJSON.h"
#include <stdbool.h>

#define MAX_TOOLS 64

/*
 * A tool execution function.
 * Takes JSON arguments string, returns result string (caller frees).
 */
typedef char *(*ToolExecFn)(const char *args_json, void *userdata);

typedef struct {
    char      *name;
    char      *description;
    cJSON     *parameters;     /* JSON Schema object */
    ToolExecFn exec;
    void      *userdata;
} Tool;

typedef struct ToolRegistry {
    Tool tools[MAX_TOOLS];
    int  n_tools;
    cJSON *cached_json;    /* cached tools_to_json result */
    bool   cache_dirty;    /* true when tools changed since last cache */
} ToolRegistry;

void   tools_init(ToolRegistry *reg);
void   tools_free(ToolRegistry *reg);
bool   tools_register(ToolRegistry *reg, const char *name,
                      const char *description, const char *params_json,
                      ToolExecFn exec, void *userdata);
Tool  *tools_find(const ToolRegistry *reg, const char *name);
char  *tools_execute(const ToolRegistry *reg, const char *name,
                     const char *args_json);
cJSON *tools_to_json(const ToolRegistry *reg);
cJSON *tools_get_cached_json(ToolRegistry *reg);

/* Built-in tool registration */
void register_builtin_tools(ToolRegistry *reg);
void register_termux_tools(ToolRegistry *reg);

/* Individual tool executors */
char *tool_bash_exec(const char *args_json, void *userdata);
char *tool_read_exec(const char *args_json, void *userdata);
char *tool_write_exec(const char *args_json, void *userdata);
char *tool_grep_exec(const char *args_json, void *userdata);
char *tool_list_exec(const char *args_json, void *userdata);
char *tool_edit_exec(const char *args_json, void *userdata);

#endif /* TOOLS_H */
