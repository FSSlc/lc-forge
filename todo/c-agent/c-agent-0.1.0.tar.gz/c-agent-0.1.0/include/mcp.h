#ifndef MCP_H
#define MCP_H

#include "cJSON.h"
#include "tools.h"
#include <stdbool.h>
#include <sys/types.h>

/* MCP tool description (from tools/list) */
typedef struct {
    char  *name;
    char  *description;
    cJSON *input_schema;
} McpTool;

/* Single MCP server connection */
typedef struct {
    char    *name;         /* config key (e.g. "filesystem") */
    char    *command;      /* executable path */
    char   **args;         /* argument array */
    int      n_args;
    char   **env_keys;     /* environment variable keys */
    char   **env_vals;     /* environment variable values */
    int      n_env;
    pid_t    pid;          /* child process PID */
    int      fd_write;     /* write to child stdin */
    int      fd_read;      /* read from child stdout */
    int      next_id;      /* JSON-RPC request ID counter */
    bool     initialized;  /* completed initialize handshake */
    McpTool *tools;        /* discovered tools */
    int      n_tools;
} McpServer;

/* MCP tool execution context (stored as ToolRegistry userdata) */
typedef struct McpManager McpManager;

typedef struct {
    McpManager *mgr;
    int         server_idx;
    int         tool_idx;
} McpToolContext;

/* MCP manager */
struct McpManager {
    McpServer      *servers;
    int             n_servers;
    McpToolContext *tool_contexts;
    int             n_tool_contexts;
};

/* Lifecycle */
void mcp_init(McpManager *mgr);
void mcp_free(McpManager *mgr);

/* Configuration */
void mcp_load_config(McpManager *mgr, const char *workspace);

/* Server management */
bool mcp_start_all(McpManager *mgr);
void mcp_stop_all(McpManager *mgr);

/* Tool registration bridge */
void mcp_register_tools(McpManager *mgr, ToolRegistry *reg);

/* Generic tool executor (used as ToolExecFn) */
char *mcp_tool_exec(const char *args_json, void *userdata);

/* Status display (for /mcp command) */
void mcp_print_status(const McpManager *mgr);

#endif /* MCP_H */
