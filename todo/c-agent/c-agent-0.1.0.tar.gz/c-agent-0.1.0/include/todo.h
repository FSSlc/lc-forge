#ifndef TODO_H
#define TODO_H

#include <stdbool.h>

typedef enum {
    TODO_PENDING,
    TODO_IN_PROGRESS,
    TODO_COMPLETED,
    TODO_FAILED
} TodoStatus;

typedef struct {
    int         id;
    char       *subject;
    char       *description;
    TodoStatus  status;
} TodoItem;

typedef struct {
    TodoItem *items;
    int       n_items;
    int       cap_items;
    int       next_id;
} TodoList;

void  todo_init(TodoList *tl);
void  todo_free(TodoList *tl);
int   todo_create(TodoList *tl, const char *subject, const char *desc);
bool  todo_update(TodoList *tl, int id, TodoStatus status);
char *todo_format(const TodoList *tl);   /* caller frees */
void  todo_parse_tags(TodoList *tl, const char *text);
char *todo_status_str(TodoStatus s);

#endif /* TODO_H */
