#ifndef SKILL_H
#define SKILL_H

#include <stdbool.h>

typedef struct {
    char *name;            /* skill name (from frontmatter) */
    char *description;     /* skill description (from frontmatter) */
    char *dir_path;        /* skill directory absolute path */
    char *skill_md_path;   /* SKILL.md absolute path */
    bool  is_global;       /* true = ~/.c-agent/skills/, false = workspace */
} Skill;

typedef struct {
    Skill *skills;
    int    n_skills;
} SkillManager;

/* Lifecycle */
void skill_init(SkillManager *mgr);
void skill_free(SkillManager *mgr);

/* Discovery: scan global + workspace skill directories */
void skill_load(SkillManager *mgr, const char *workspace);

/* Lookup */
Skill *skill_find(const SkillManager *mgr, const char *name);

/* Read SKILL.md body (skipping frontmatter). Caller frees. */
char *skill_read_content(const Skill *skill);

/* Print skill list to stdout */
void skill_print_list(const SkillManager *mgr);

/* Append skill metadata to a string buffer for system prompt */
void skill_append_system_prompt(const SkillManager *mgr, void *strbuf);

/* Tool executors (for LLM tools) */
char *tool_skill_install_exec(const char *args_json, void *userdata);
char *tool_skill_remove_exec(const char *args_json, void *userdata);

#endif /* SKILL_H */
