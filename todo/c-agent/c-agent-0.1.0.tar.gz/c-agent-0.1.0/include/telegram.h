#ifndef TELEGRAM_H
#define TELEGRAM_H

#include "agent.h"
#include "config.h"
#include <stdint.h>

typedef struct {
    char    *bot_token;
    int64_t  chat_id;         /* current conversation chat_id */
    int      last_update_id;  /* getUpdates offset */
    Agent   *agent;
    Config  *config;
    ToolExecFn orig_bash_exec;   /* original bash exec function */
    void      *orig_bash_userdata;
} TelegramCtx;

/* Start the Telegram bot long-polling loop. Blocks until error or signal. */
void telegram_run(Agent *agent, Config *cfg);

#endif /* TELEGRAM_H */
