#ifndef SSE_H
#define SSE_H

#include "cJSON.h"
#include <stdbool.h>
#include <stddef.h>

/*
 * SSE (Server-Sent Events) line parser.
 *
 * Feed raw bytes from curl callback; the parser splits into lines,
 * extracts "data: ..." payloads, and passes parsed JSON to a user callback.
 */

typedef void (*SseChunkCb)(cJSON *chunk, void *userdata);

typedef struct {
    char      *line_buf;
    size_t     line_len;
    size_t     line_cap;
    SseChunkCb cb;
    void      *userdata;
    bool       done;        /* received [DONE] */
} SseParser;

void sse_init(SseParser *p, SseChunkCb cb, void *userdata);
void sse_free(SseParser *p);
void sse_feed(SseParser *p, const char *data, size_t len);
bool sse_is_done(const SseParser *p);

#endif /* SSE_H */
