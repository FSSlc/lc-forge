#ifndef CONTEXT_H
#define CONTEXT_H

#include "cJSON.h"
#include <stdbool.h>
#include <stddef.h>

/* ---------- tool call within an assistant message ---------- */
typedef struct {
    char *id;            /* tool_call_id */
    char *name;          /* function name */
    char *arguments;     /* JSON string */
} ToolCall;

/* ---------- single message ---------- */
typedef enum {
    ROLE_SYSTEM,
    ROLE_USER,
    ROLE_ASSISTANT,
    ROLE_TOOL
} Role;

typedef struct {
    Role      role;
    char     *content;              /* may be NULL for assistant+tool_calls */
    char     *reasoning_content;    /* thinking CoT (assistant only, may be NULL) */
    /* assistant messages only */
    ToolCall *tool_calls;
    int       n_tool_calls;
    /* tool messages only */
    char     *tool_call_id;
} Message;

/* ---------- context (conversation history) ---------- */
typedef struct {
    Message *msgs;
    int      n_msgs;
    int      cap_msgs;
    int      max_tokens;        /* context window limit */
    int      cached_tokens;     /* running total for O(1) estimation */
} Context;

void    ctx_init(Context *ctx, int max_tokens);
void    ctx_free(Context *ctx);
void    ctx_add_system(Context *ctx, const char *content);
void    ctx_add_user(Context *ctx, const char *content);
void    ctx_add_assistant(Context *ctx, const char *content,
                          const char *reasoning_content,
                          ToolCall *tcs, int n_tcs);
void    ctx_add_tool(Context *ctx, const char *tool_call_id,
                     const char *content);
void    ctx_clear(Context *ctx);           /* keep system prompt */
cJSON  *ctx_to_json(const Context *ctx);   /* caller frees */
int     ctx_estimate_tokens(const Context *ctx);
void    ctx_truncate(Context *ctx);        /* keep under 80% capacity */
int     ctx_msg_count(const Context *ctx);
bool    ctx_drop_incomplete_tool_turn(Context *ctx);

/* helpers */
ToolCall toolcall_dup(const ToolCall *tc);
void     toolcall_free(ToolCall *tc);

#endif /* CONTEXT_H */
