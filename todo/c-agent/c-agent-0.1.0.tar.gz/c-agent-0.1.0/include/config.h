#ifndef CONFIG_H
#define CONFIG_H

#include "cJSON.h"
#include <stdbool.h>

/*
 * Config file: ~/.c-agent/config.json
 *
 * {
 *   "api_key": "sk-...",
 *   "base_url": "https://api.deepseek.com",
 *   "model": "deepseek-v4-flash",
 *   "reasoning_model": "deepseek-v4-pro",
 *   "fast_model": "deepseek-v4-flash",
 *   "max_tokens": 16384,
 *   "temperature": 0.0,
 *   "max_context_tokens": 1000000,
 *   "max_tool_rounds": 25,
 *   "telegram_bot_token": "123456:ABC-DEF"
 * }
 *
 * Multi-model agent routing:
 *   - model:           default model for the main agent
 *   - reasoning_model: model for planner sub-agents (uses thinking mode)
 *   - fast_model:      model for explorer sub-agents (fast, no thinking)
 *
 * Environment variables override config file:
 *   DEEPSEEK_API_KEY, DEEPSEEK_BASE_URL, DEEPSEEK_MODEL
 *   TELEGRAM_BOT_TOKEN
 */

typedef struct {
    char  *api_key;
    char  *base_url;
    char  *model;             /* default agent model */
    char  *reasoning_model;   /* planner sub-agent model */
    char  *fast_model;        /* explorer sub-agent model */
    char  *workspace;         /* working directory (set at runtime, not saved) */
    char  *telegram_bot_token; /* Telegram bot token for remote control */
    int    max_tokens;
    double temperature;
    int    max_context_tokens;
    int    max_tool_rounds;
    int    planner_max_rounds;     /* sub-agent round limits */
    int    explorer_max_rounds;
    int    tool_result_max_chars;  /* truncation limits */
    int    sub_agent_result_max_chars;
} Config;

/* Load config from file + env vars. Returns defaults if file doesn't exist. */
void config_load(Config *cfg);

/* Save current config to file */
bool config_save(const Config *cfg);

/* Set a config key by name. Returns true on success. */
bool config_set(Config *cfg, const char *key, const char *value);

/* Get the config file path (~/.c-agent/config.json) */
const char *config_path(void);

/* Free config strings */
void config_free(Config *cfg);

#endif /* CONFIG_H */
