#ifndef AGENT_H
#define AGENT_H

#include "api.h"
#include "context.h"
#include "config.h"
#include "tools.h"
#include "todo.h"
#include "mcp.h"
#include "skill.h"
#include "session.h"
#include <stdbool.h>
#include <pthread.h>

/*
 * Agent types for multi-model routing:
 *
 *   AGENT_DEFAULT  - main agent, uses config.model
 *   AGENT_PLANNER  - planning/reasoning sub-agent, uses config.reasoning_model
 *                    with thinking mode enabled (CoT)
 *   AGENT_EXPLORER - fast exploration sub-agent, uses config.fast_model
 *                    no thinking overhead, optimized for speed
 */
typedef enum {
    AGENT_DEFAULT,
    AGENT_PLANNER,
    AGENT_EXPLORER
} AgentType;

typedef struct Agent Agent;

struct Agent {
    ApiConfig     api_cfg;
    Context       ctx;
    ToolRegistry  tools;
    TodoList      todos;
    McpManager    mcp;          /* MCP server connections */
    SkillManager  skills;       /* Skills system */
    Session       session;      /* Session persistence */
    Config       *config;       /* points to global config */
    char         *workspace;    /* working directory (absolute path) */
    AgentType     type;
    bool          is_sub_agent;
    int           max_rounds;   /* max tool-call rounds per turn */
    volatile bool interrupted;  /* set by Ctrl+C handler */
};

/* Create and destroy */
void agent_init(Agent *agent, Config *cfg, AgentType type);
void agent_free(Agent *agent);

/* Process a single user message: returns assistant reply (caller frees) */
char *agent_process(Agent *agent, const char *user_input);

/* Interrupt current processing */
void agent_interrupt(Agent *agent);

/* Sub-agent tool executor */
char *tool_spawn_sub_agent_exec(const char *args_json, void *userdata);

#endif /* AGENT_H */
