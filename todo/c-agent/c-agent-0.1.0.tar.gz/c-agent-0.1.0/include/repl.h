#ifndef REPL_H
#define REPL_H

#include "agent.h"
#include "config.h"

/* Start the interactive REPL. Blocks until /quit or EOF. */
void repl_run(Agent *agent, Config *cfg);

#endif /* REPL_H */
