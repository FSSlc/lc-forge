#ifndef UTIL_H
#define UTIL_H

#include <stddef.h>
#include <stdbool.h>

/* ---------- memory ---------- */
void *xmalloc(size_t n);
void *xrealloc(void *p, size_t n);
char *xstrdup(const char *s);

/* ---------- dynamic string buffer ---------- */
typedef struct {
    char  *data;
    size_t len;
    size_t cap;
} StrBuf;

void   strbuf_init(StrBuf *sb);
void   strbuf_free(StrBuf *sb);
void   strbuf_append(StrBuf *sb, const char *s, size_t n);
void   strbuf_appendf(StrBuf *sb, const char *fmt, ...)
           __attribute__((format(printf, 2, 3)));
void   strbuf_appends(StrBuf *sb, const char *s);
void   strbuf_reset(StrBuf *sb);
char  *strbuf_detach(StrBuf *sb);          /* caller frees */

/* ---------- logging ---------- */
typedef enum { LOG_DEBUG, LOG_INFO, LOG_WARN, LOG_ERROR } LogLevel;

void log_set_level(LogLevel lv);
void log_msg(LogLevel lv, const char *fmt, ...)
         __attribute__((format(printf, 2, 3)));

#define LOG_DEBUG(...) log_msg(LOG_DEBUG, __VA_ARGS__)
#define LOG_INFO(...)  log_msg(LOG_INFO,  __VA_ARGS__)
#define LOG_WARN(...)  log_msg(LOG_WARN,  __VA_ARGS__)
#define LOG_ERROR(...) log_msg(LOG_ERROR, __VA_ARGS__)

/* ---------- platform helpers ---------- */
const char *get_shell_path(void);
const char *get_home_dir(void);
bool        is_termux(void);

/* ---------- ANSI colors ---------- */
#define CLR_RESET   "\033[0m"
#define CLR_BOLD    "\033[1m"
#define CLR_DIM     "\033[2m"
#define CLR_RED     "\033[31m"
#define CLR_GREEN   "\033[32m"
#define CLR_YELLOW  "\033[33m"
#define CLR_BLUE    "\033[34m"
#define CLR_MAGENTA "\033[35m"
#define CLR_CYAN    "\033[36m"

#endif /* UTIL_H */
