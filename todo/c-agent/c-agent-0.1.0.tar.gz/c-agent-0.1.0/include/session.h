#ifndef SESSION_H
#define SESSION_H

#include "context.h"
#include <stdio.h>
#include <stddef.h>

typedef struct {
    char *session_id;      /* "20260222_143021_a3f" */
    char *file_path;       /* full JSONL file path */
    FILE *fp;              /* append-mode file handle */
} Session;

/* lifecycle */
void session_init(Session *s);
void session_free(Session *s);
int  session_create(Session *s, const char *workspace);

/* append messages (real-time flush) */
void session_append_user(Session *s, const char *content);
void session_append_assistant(Session *s, const char *content,
                              const char *reasoning_content,
                              ToolCall *tcs, int n_tcs);
void session_append_tool(Session *s, const char *tool_call_id,
                         const char *content);

/* restore */
int  session_load_into_ctx(const char *file_path, Context *ctx);

/* list & find */
void session_list_print(const char *workspace);
int  session_find_latest(const char *workspace, char *out_path, size_t sz);
int  session_find_by_id(const char *workspace, const char *id,
                        char *out_path, size_t sz);

#endif /* SESSION_H */
