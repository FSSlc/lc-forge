# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build & Run

```bash
make                                    # Build (output: ./c-agent)
make clean && make                      # Clean rebuild
./c-agent                               # Interactive REPL
./c-agent -e "prompt"                   # Single-shot execution
./c-agent --telegram                    # Telegram bot mode
./c-agent -d                            # Debug logging
```

Requires: C11 compiler, libcurl, libedit, pthreads. No test suite exists.

Termux (Android): `pkg install clang libcurl libedit make` then `make`. The `$PREFIX` env var is auto-detected in the Makefile to add include/lib paths.

## Architecture

### Core Loop

The agent is a tool-use loop: **user message → LLM API (streaming SSE) → tool calls → execute tools → results back to context → repeat** until no more tool calls or max rounds (25) reached. This lives in `agent_process()` in `src/agent.c`.

### Agent Types

Three types share the same `Agent` struct but differ in model and behavior:

- **AGENT_DEFAULT** — main agent, has all tools including `spawn_sub_agent`, MCP, skills, session persistence
- **AGENT_PLANNER** — sub-agent with CoT thinking enabled (`enable_thinking: true`), uses `reasoning_model`
- **AGENT_EXPLORER** — fast sub-agent, uses `fast_model`, no thinking overhead

Sub-agents run in pthreads via `tool_spawn_sub_agent_exec()`. They get a fresh context and cannot spawn further sub-agents.

### Tool System

Tools are function pointers registered in a `ToolRegistry` (max 64). Each tool has a name, JSON Schema for parameters, an exec function `char *(*ToolExecFn)(const char *args_json, void *userdata)`, and optional userdata.

**To add a new tool:**
1. Write the exec function (parse args with cJSON, return malloc'd result string)
2. Register it in `register_builtin_tools()` in `src/tools.c` or during agent init in `src/agent.c`

Built-in tools: `bash` (fork/exec with timeout), `read_file`, `write_file`, `edit_file` (search & replace), `grep_search` (popen grep), `list_files` (opendir). TODO tools (`todo_create/update/list`) and skill tools are registered with the agent pointer as userdata.

### Context Management

`Context` (`src/context.c`) holds the message history. Messages have roles: SYSTEM, USER, ASSISTANT (with optional tool_calls array), TOOL (with tool_call_id). When context exceeds 80% of `max_context_tokens`, oldest non-system messages are truncated. Token estimation is chars/4.

### API Layer

`src/api.c` talks to the DeepSeek-compatible API. Main agent uses streaming (`api_chat_stream` with SSE callbacks for real-time output). Sub-agents use non-streaming (`api_chat`). SSE parsing is in `src/sse.c`.

### Configuration

Loaded in order (later overrides earlier): `~/.c-agent/config.json` → env vars (`DEEPSEEK_API_KEY`, `DEEPSEEK_BASE_URL`, `DEEPSEEK_MODEL`, `TELEGRAM_BOT_TOKEN`) → CLI flags. Config paths use `get_home_dir()` from `src/util.c` which handles Termux/Android correctly.

### Key Conventions

- Memory: use `xmalloc()`, `xrealloc()`, `xstrdup()` (abort on OOM)
- Strings: `StrBuf` for dynamic building, `strbuf_detach()` to hand off ownership (caller frees)
- Tool results: always return a malloc'd string; caller frees
- Shell paths: never hardcode `/bin/sh`; use `get_shell_path()` which checks `$SHELL`, `$PREFIX/bin/sh`, then fallbacks
- Home dir: never hardcode; use `get_home_dir()` which checks `$HOME`, `getpwuid()`, `$PREFIX/home`, then `/tmp`
- Logging: `LOG_DEBUG/INFO/WARN/ERROR` macros
- JSON: cJSON library vendored in `vendor/cjson/`

### File Layout

- `include/` — one header per module defining public types and functions
- `src/` — implementations. `tool_*.c` files each implement one tool executor
- `vendor/cjson/` — embedded cJSON library
- Config dir at runtime: `~/.c-agent/` (config.json, sessions/, skills/, mcp.json)

### Session & Persistence

Sessions are JSONL files in `~/.c-agent/sessions/` with ID format `YYYYMMDD_HHMMSS_XXX`. Messages are appended incrementally. Only the main agent (not sub-agents) writes sessions.

### MCP Integration

MCP servers are configured in `.c-agent/mcp.json` (global or workspace). Servers are spawned as child processes, communicated with via JSON-RPC over stdin/stdout pipes. Their tools are auto-discovered and registered in the ToolRegistry with `mcp__<server>__<tool>` naming.

### Telegram Bot

Long-polling mode (`src/telegram.c`). Dangerous commands (rm, sudo, kill, etc.) require user confirmation via inline reply with 60s timeout. Messages over 4096 chars are auto-split at newline boundaries.
