# c-agent

A pure-C AI Agent. Runs in your terminal, reads/writes files, executes commands, searches code, and manages tasks — all from a single lightweight binary with zero runtime dependencies beyond libcurl.

## Features

- **Interactive REPL** with line editing and command history (libedit)
- **Tool-augmented AI** — bash, file read/write/edit, grep, directory listing
- **Multi-model routing** — default, planner (CoT reasoning), and explorer (fast) sub-agents
- **TODO planning** — create, track, and update task lists during complex work
- **Session persistence** — auto-saved JSONL sessions with resume support
- **MCP support** — connect external tool servers via Model Context Protocol
- **Skills system** — install and invoke reusable prompt skills from Git repos
- **Telegram bot mode** — remote control via Telegram with dangerous command confirmation
- **Context management** — automatic truncation with token estimation

## Build

Requires: C11 compiler, libcurl, libedit, pthreads.

```bash
# macOS (dependencies pre-installed)
make

# Ubuntu/Debian
sudo apt install libcurl4-openssl-dev libedit-dev
make

# Termux (Android)
pkg install clang libcurl libedit make
make
```

## Quick Start

```bash
# Set your API key
export DEEPSEEK_API_KEY=sk-your-key-here

# Run interactive REPL
./c-agent

# Execute a single prompt
./c-agent -e "explain this codebase"

# Use a custom workspace
./c-agent -C /path/to/project
```

## Configuration

Config file: `~/.c-agent/config.json`

```json
{
  "api_key": "sk-...",
  "base_url": "https://api.deepseek.com",
  "model": "deepseek-chat",
  "reasoning_model": "deepseek-chat",
  "fast_model": "deepseek-chat",
  "max_tokens": 8192,
  "temperature": 0.0,
  "max_context_tokens": 128000,
  "max_tool_rounds": 25,
  "telegram_bot_token": "123456:ABC-DEF"
}
```

Environment variables (override config file):

| Variable | Description |
|---|---|
| `DEEPSEEK_API_KEY` | API key |
| `DEEPSEEK_BASE_URL` | API base URL |
| `DEEPSEEK_MODEL` | Model name |
| `TELEGRAM_BOT_TOKEN` | Telegram bot token |

You can also set config at runtime:

```
/config set api_key sk-your-key-here
/config set model deepseek-chat
```

## CLI Options

```
Usage: c-agent [options]

Options:
  -C, --workspace DIR   Set workspace directory (default: cwd)
  -k, --api-key KEY     DeepSeek API key
  -m, --model MODEL     Model name (default: deepseek-chat)
  -u, --base-url URL    API base URL
  -e, --execute CMD     Execute a single prompt and exit
  -t, --telegram        Run as Telegram bot (long polling)
  -d, --debug           Enable debug logging
  -h, --help            Show this help
```

## REPL Commands

| Command | Description |
|---|---|
| `/help` | Show help |
| `/quit` | Exit |
| `/clear` | Clear conversation & start new session |
| `/sessions` | List recent sessions |
| `/resume [id]` | Resume a session (default: latest) |
| `/todo` | Show current TODO list |
| `/context` | Show context stats (messages, tokens) |
| `/config` | Show current configuration |
| `/config set <key> <value>` | Set a config value |
| `/mcp` | Show MCP server status |
| `/skills` | Show available skills |
| `/skill install <url>` | Install skill from Git repo |
| `/skill remove <name>` | Remove a skill |
| `/<skill-name>` | Invoke a skill |

## Telegram Bot Mode

Control c-agent remotely via Telegram. Uses long polling (no public IP needed).

### Setup

1. Create a bot with [@BotFather](https://t.me/BotFather) on Telegram, get the token
2. Configure the token:
   ```bash
   export TELEGRAM_BOT_TOKEN=123456:ABC-DEF
   # or add to ~/.c-agent/config.json
   ```
3. Start the bot:
   ```bash
   ./c-agent --telegram
   ```

### Telegram Commands

| Command | Description |
|---|---|
| `/help` | Show help |
| `/sessions` | List recent sessions |
| `/resume [id]` | Resume a session |
| `/clear` | Clear conversation & new session |
| `/status` | Show model, workspace, context usage |

Send any text message to chat with the agent.

### Dangerous Command Confirmation

When the agent tries to execute potentially dangerous commands (`rm`, `sudo`, `kill -9`, `mkfs`, `reboot`, etc.), you'll receive a confirmation prompt:

```
Warning: Dangerous command detected:
`rm -rf /tmp/build`

Reply 'y' to confirm, anything else to cancel (60s timeout).
```

### Signal Handling

- **First Ctrl+C** during agent processing: interrupts the current task, notifies the Telegram user
- **Ctrl+C** when idle (or second press): stops the bot cleanly

## Termux (Android)

c-agent 可以在 Android 手机上通过 [Termux](https://termux.dev) 运行，让你随时随地使用 AI Agent。

### 安装步骤

1. 从 [F-Droid](https://f-droid.org/packages/com.termux/) 或 [GitHub Releases](https://github.com/termux/termux-app/releases) 安装 Termux

2. 安装依赖并编译：
   ```bash
   pkg update && pkg upgrade
   pkg install clang libcurl libedit make git
   git clone https://github.com/coder-brzhang/c-agent.git
   cd c-agent
   make
   ```

3. 配置并运行：
   ```bash
   export DEEPSEEK_API_KEY=sk-your-key-here
   ./c-agent
   ```

### 注意事项

- Termux 的 `$PREFIX` 环境变量（通常为 `/data/data/com.termux/files/usr`）会被自动识别，编译时会自动添加正确的头文件和库路径
- Shell 路径会自动从 `$SHELL` 或 `$PREFIX/bin/sh` 获取，无需手动配置
- 配置文件位于 `~/.c-agent/config.json`，与其他平台一致
- 建议安装 `termux-api` 包以获得更好的系统集成（剪贴板等）
- 如需后台运行 Telegram bot 模式，可配合 `termux-services` 或 `nohup` 使用：
  ```bash
  nohup ./c-agent --telegram &
  ```

## Project Structure

```
c-agent/
  include/         Header files
    agent.h          Agent struct, init/process/free
    api.h            API config, chat calls (streaming + non-streaming)
    config.h         Configuration loading/saving
    context.h        Conversation context management
    tools.h          Tool registry and execution
    telegram.h       Telegram bot integration
    repl.h           Interactive REPL
    session.h        Session persistence
    mcp.h            MCP server management
    skill.h          Skills system
    todo.h           TODO list tracking
    util.h           Utilities (StrBuf, logging, memory)
  src/             Implementation
    main.c           CLI entry point
    agent.c          Agent core loop + sub-agent spawning
    api.c            DeepSeek API client (SSE streaming)
    config.c         Config file + env var loading
    repl.c           Interactive REPL with libedit
    telegram.c       Telegram bot (long polling, command handling)
    tool_bash.c      Bash tool (fork/exec with timeout)
    tool_read.c      File read tool
    tool_write.c     File write tool
    tool_edit.c      File edit tool (search & replace)
    tool_grep.c      Grep tool (regex search)
    tool_list.c      Directory listing tool
    session.c        JSONL session persistence
    mcp.c            MCP protocol implementation
    skill.c          Skills discovery and management
    todo.c           TODO list implementation
    tools.c          Tool registry
    context.c        Context window management
    sse.c            SSE parser
    util.c           Utility functions
  vendor/cjson/    cJSON library (JSON parsing)
  Makefile         Build configuration
```

## License

Non-commercial use is free. Commercial use requires a separate license from the author. See [LICENSE](LICENSE) for details.
